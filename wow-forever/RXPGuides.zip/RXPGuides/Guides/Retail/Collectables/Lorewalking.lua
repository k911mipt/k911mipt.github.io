local L = GetLocale() if L and RXP.enabledLocale[L] then return end

--Xal'atath
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Miscellaneous
#subgroup Lorewalking
#name a) Xal'atath
#displayname Xal'atath
#next ab) Ethereals

step
    .chromieon
    .goto 84,56.27,17.32 << Alliance
    .goto 85,40.84,80.17 << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Chromie|r
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Stormwind and ask her to return you to the present timeline. << Alliance
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Orgrimmar and ask her to return you to the present timeline. << Horde
    .skipgossipid 51903
    .target Chromie
step
    #completewith LorewalkingCampaignEnd
    +Click on the |cRXP_PICK_Ask a Question|r button in the "Active Items Frame" to talk to the Lorewalker if needed.
    *To stop the campaign, click on |cRXP_PICK_Exit Lorewalking|r in the Lorewalking panel.
    .macro Ask a Question,2056011 >>/cast spell:1242675
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 84,64.24,16.10,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Stormwind|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 85,54.24,56.59,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Orgrimmar|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    #label LoreWalkingPrepStart
    .goto 85,54.19,56.75,-1 << Horde
    .goto 84,64.24,16.10,-1 << Alliance
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .accept 84371 >>Accept Lorewalking: The Blade and the High Priest
    .skipgossipid 124311
    .choose 6403389
    .timer 39,RP
    .target Lorewalker Cho
step
    #arrowtext Wait for the roleplay
    .goto 85,54.19,56.75,-1 << Horde
    .goto 84,64.24,16.10,-1 << Alliance
    .goto 2339,49.6,31.63,-1
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 84371,1 --1/1 Talk to Lorewalker Cho to learn about the Legion invasion
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.19,56.75,-1 << Horde
    .goto 84,64.24,16.10,-1 << Alliance
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
    .complete 84371,2 --1/1 Talk to Lorewalker Cho to learn of the High Priest's journey
    -- .skipgossipid 124811
    -- .skipgossipid 124812
    .skipgossipid 124809
    .target Lorewalker Cho
step
    .isOnQuest 84371 --Lorewalking: The Blade and the High Priest
    .zone 18 >> Enter Tirisfal Glades
step
    #completewith next
    #label Blade in Twilight
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r
    .accept 40710 >>Accept Blade in Twilight
    .target Alonsus Faol
step
    #arrowtext Leave the vehicle
    #completewith Blade in Twilight
    .goto 18,12.82,59.21
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alonsus Faol|r
    #requires Blade in Twilight
    .goto 18,12.79,59.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alonsus Faol|r
    .accept 40710 >>Accept Blade in Twilight
    .target Alonsus Faol
step
    .isOnQuest 40710 --Blade in Twilight
    .goto 18,13.47,57.59
    #title |cFFFCDC00Follow the Arrow|r
    .complete 40710,1 --1/1 Go to the marked location in Tirisfal Glades
step
    #arrowtext Click\n|cRXP_PICK_Notes|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 18,13.47,57.59
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r
    .scenario 2221,1
step
    #arrowtext Click\n|cRXP_PICK_Notes|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 18,13.2,55.46
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r |cRXP_WARN_in the tent|r.
    .scenario 2221,2
step
    #arrowtext Click\n|cRXP_PICK_Notes|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 18,13.91,55.4
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Notes|r
    .scenario 2221,3
step
    .isOnQuest 40710 --Blade in Twilight
    #completewith next
    #hidewindow
    #label Tomb
    #title |cFFFCDC00Follow the Arrow|r
    .scenario 2031,1
step
    #arrowtext Enter the Tomb at the bottom of the lake
    .isOnQuest 40710 --Blade in Twilight
    #completewith Tomb
    .goto 20,37.32,13.37,10,0
    .goto 20,36.24,17.16,10,0
    .goto 20,34.22,22.72,10,0
    .goto 20,34.92,28.92,10 >>Enter the Tomb |cRXP_WARN_at the bottom of the lake|r.
step
    .isOnQuest 40710 --Blade in Twilight
    #requires Tomb
    #title |cFFFCDC00Follow the Arrow|r
    .scenario 2031,1
step
    .isOnQuest 40710 --Blade in Twilight
    #completewith next
    #label Twilight Shadowcaster
    >>Kill |cRXP_ENEMY_Twilight Shadowcaster|r and |cRXP_ENEMY_Twilight Bladetwister|r.
    .scenario 2032,1
    .mob Twilight Shadowcaster
    .mob Twilight Bladetwister
step
    .isOnQuest 40710 --Blade in Twilight
    #hidewindow
    #completewith Twilight Shadowcaster
    .goto 20,37.18,43.08,30 >>Follow the Arrow
    .timer 30,RP
step
    #arrowtext Kill\n|cRXP_ENEMY_Twilight Shadowcaster|r and |cRXP_ENEMY_Twilight Bladetwister|r
    .isOnQuest 40710 --Blade in Twilight
    #requires Twilight Shadowcaster
    .goto 20,37.18,43.08
    >>Kill |cRXP_ENEMY_Twilight Shadowcaster|r and |cRXP_ENEMY_Twilight Bladetwister|r.
    .scenario 2032,1
step
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,38.03,47.62
    #title |cFFFCDC00Follow the Arrow|r
    .scenario 2048,1
step
    #arrowtext Kill\n|cRXP_ENEMY_Twilight Ritualists|r
    .isOnQuest 40710 --Blade in Twilight
    #loop
    .goto 20,40.04,51.38,15,0
    .goto 20,40.17,57.68,15,0
    .goto 20,34.97,58.57,15,0
    .goto 20,34.83,51.15,15,0
    >>Kill the four |cRXP_ENEMY_Twilight Ritualists|r
    .scenario 2086,1
    .mob Twilight Ritualist
    .mob Flesh Spawn
step
    #arrowtext Kill\n|cRXP_ENEMY_Amassing Darkness|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,37.4,53,10,0
    .goto 20,37.49,54.93
    >>Kill the |cRXP_ENEMY_Amassing Darkness|r
    .scenario 2171,1
    .mob Amassing Darkness
step
    #arrowtext |cFFFCDC00Follow the arrow|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,37.64,66.51,10,0
    .goto 20,39.85,79.51,10,0
    .goto 20,42.73,84.43,20,0
    .goto 20,47.8,75.48
    >>Kill the |cRXP_ENEMY_enemies|r on the way to the prison chamber
    .scenario 2089,1
    .mob Twilight Bladetwister
    .mob Borgoth the Master Reaver
    .mob Flesh Spawn
    .mob Void Tendril
step
    #completewith next
    #label Twilight Deacon
    .isOnQuest 40710 --Blade in Twilight
    >>Kill |cRXP_ENEMY_Twilight Deacon Farthing|r
    .scenario 2099,1
    .mob Twilight Deacon Farthing
step
    #arrowtext |cFFFCDC00Mind your step|r
    #completewith Twilight Deacon
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,51.71,74.95,10,0
    .goto 20,56.16,75.11,15 >>|cRXP_WARN_Cross the bridge|r
step
    #arrowtext Kill\n|cRXP_ENEMY_Twilight Deacon Farthing|r
    #requires Twilight Deacon
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,58.79,75.17,10,0
    .goto 20,58.61,76.46
    >>Kill |cRXP_ENEMY_Twilight Deacon Farthing|r
    .scenario 2099,1
    .timer 15,RP
    .mob Twilight Deacon Farthing
step
    #arrowtext Click\n|cRXP_PICK_Xal'atath (Blade in Twilight)|r
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,58.61,76.46
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath (Blade in Twilight)|r
    .scenario 2115,1
step
    .isOnQuest 40710 --Blade in Twilight
    .goto 20,58.61,76.46
    .cast 201904 >>Use the |cRXP_WARN_ExtraActionButton|r
    .timer 10,RP
step
    #arrowtext Wait for the roleplay
    #label LoreWalkingPrepEnd
    .goto 20,58.79,76.87
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 40710,2 --1/1 Stop the Ritual and acquire the Blade
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 20,58.79,76.87
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 40710 >>Turn in Blade in Twilight
    .complete 84371,3 --Follow the High Priest's journey and acquire Xal'atath
    .turnin 84371 >>Turn in Lorewalking: The Blade and the High Priest
    .accept 84779 >>Accept Lorewalking: The Blade's Gambit
    .timer 12,RP
    .target Lorewalker Cho
step
    .isOnQuest 84779 --Lorewalking: The Blade's Gambit
    .zone 20 >> Enter Stormsong Valley
step
    #arrowtext Wait for the roleplay
    .goto 20,58.79,76.87
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 84779,1 --1/1 Talk to Lorewalker Cho to learn of Xal'atath's gambit
    .target Lorewalker Cho
step << Horde
    #completewith next
    #label Every Little Death Helps H
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .accept 54118 >>Accept Every Little Death Helps
step << Horde
    #arrowtext Leave the vehicle
    #completewith Every Little Death Helps H
    .goto 862,78.07,36.72
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step << Alliance
    #completewith next
    #label Every Little Death Helps A
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .accept 54114 >>Accept Every Little Death Helps
step << Alliance
    #arrowtext Leave the vehicle
    #completewith Every Little Death Helps A
    .goto 942,34.18,31.8
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step << Horde
    #arrowtext Click\n|cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    #requires Every Little Death Helps H
    .goto 862,78.07,36.72
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .accept 54118 >>Accept Every Little Death Helps
step << Alliance
    #arrowtext Click\n|cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    #requires Every Little Death Helps A
    .goto 942,34.14,31.76
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .accept 54114 >>Accept Every Little Death Helps
step << Horde
    #arrowtext Kill\n|cRXP_ENEMY_Darktide forces|r
    #loop
    .goto 862,80.36,35.86,35,0
    .goto 862,78.93,39.23,45,0
    .goto 862,78.07,37.13,40,0
    >>Kill the |cRXP_ENEMY_Darktide forces|r (7 enemies)
    .complete 54118,1 --1/1 Xal'atath fed
    .mob Darktide Champion
    .mob Darktide Sorceress
    .mob Darktide Witch
    .mob Darktide Marauder
step << Alliance
    #arrowtext Kill\n|cRXP_ENEMY_Darktide forces|r
    #loop
    .goto 942,34.44,32.35,15,0
    .goto 942,33.56,32.94,15,0
    .goto 942,32.46,32.04,15,0
    .goto 942,31.39,31.68,15,0
    .goto 942,30.97,33.71,15,0
    .goto 942,32.71,34.5,15,0
    >>Kill the |cRXP_ENEMY_Darktide forces|r
    .complete 54114,1 --1/1 Xal'atath fed
    .mob Darktide Champion
    .mob Darktide Sorceress
    .mob Darktide Witch
    .mob Darktide Marauder
step << Horde
    #arrowtext Click\n|cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .goto 862,78.07,36.72
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .turnin 54118 >>Turn in Every Little Death Helps
    .accept 54058 >>Accept Unintended Consequences
    .target Xal'atath, Blade of the Black Empire
step << Alliance
    #arrowtext Click\n|cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .goto 942,34.1,31.91
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on |cRXP_PICK_Xal'atath, Blade of the Black Empire|r
    .turnin 54114 >>Turn in Every Little Death Helps
    .accept 54058 >>Accept Unintended Consequences
    .target Xal'atath, Blade of the Black Empire
step
    #completewith next
    #label Void Stone
    #hidewindow
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 54058,1 --1/1 Void Stone found
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    #completewith Void Stone
    .goto 942,34.09,31.96 << Alliance
    .goto 862,78.01,36.70 << Horde
    .vehicle >>Click on the |cRXP_PICK_Serpent (Mishi)|r
    .timer 50,RP
    .target Mishi
step
    #arrowtext Wait for the roleplay
    #requires Void Stone
    .goto 876,25.86,64.65
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 54058,1 --1/1 Void Stone found
step
    #arrowtext Kill\n|cRXP_ENEMY_Deep Watchers|r and |cRXP_ENEMY_Inanis|r
    .goto 896,20.13,35.85
    >>Kill the |cRXP_ENEMY_Deep Watchers|r and |cRXP_ENEMY_Inanis|r.
    .complete 54058,2 --1/1 Stop the ritual
    .mob Deep Watcher
    .mob Inanis
step
    #arrowtext Click\n|cRXP_PICK_Void Stone|r
    .goto 896,20.13,35.85
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Stone|r
    .complete 54058,3 --1/1 Void Stone activated
step
    .goto 896,20.13,35.85
    >>Use the |T1386548:0|t|cRXP_WARN_ExtraActionButton|r
    .complete 54058,4 --1/1 Void Stone activated
    .timer 22,RP
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xal'atath|r
    .goto 896,19.92,36.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xal'atath|r |cRXP_WARN_after the roleplay|r
    .turnin 54058 >>Turn in Unintended Consequences
    .target Xal'atath
    .accept 53761 >>Accept The Pirate's Treasure
step
    #completewith next
    #label Pirate's Den
    #hidewindow
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53761,1 --1/1 Pirate's Den found
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    #completewith Pirate's Den
    .goto 896,19.88,36.42
    .vehicle >>Click on the |cRXP_PICK_Serpent (Mishi)|r
    .timer 37,RP
    .target Mishi
step
    #arrowtext Wait for the roleplay
    #requires Pirate's Den
    .goto 876,61.79,80.08
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53761,1 --1/1 Pirate's Den found
step
    #arrowtext Kill\n|cRXP_ENEMY_Lieutenant Elsbeth Wavecutter|r
    #loop
    .goto 895,75.09,78.47,10,0
    .goto 895,74.88,78.81,20,0
    >>Kill |cRXP_ENEMY_Lieutenant Elsbeth Wavecutter|r. Loot her for the |T2010761:0|t[|cRXP_LOOT_Skeleton Key|r].
    .complete 53761,2 --1/1 Skeleton Key
    .mob Lieutenant Elsbeth Wavecutter
step
    #arrowtext Click\n|cRXP_PICK_Chest|r
    .goto 895,74.9,78.91
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Chest|r
    .complete 53761,3 --1/1 Trident of Deep Ocean
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xal'atath|r
    .goto 895,75.04,77.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xal'atath|r
    .turnin 53761 >>Turn in The Pirate's Treasure
    .target Xal'atath
    .accept 53762 >>Accept The Tempest Crown
step
    #completewith next
    #label Toatana's Cave
    #hidewindow
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53762,1 --1/1 Toatana's Cave found
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    #completewith Toatana's Cave
    .goto 895,75.07,77.54
    .vehicle >>Click on the |cRXP_PICK_Serpent (Mishi)|r
    .timer 50,RP
    .target Mishi
step
    #arrowtext Wait for the roleplay
    #requires Toatana's Cave
    .goto 864,51.94,13.7,10,0
    .goto 864,52.35,14.19,15,0
    >>|cRXP_WARN_Wait for the roleplay. Enter the Cave|r.
    .complete 53762,1 --1/1 Toatana's Cave found
step
    #arrowtext Kill\n|cRXP_ENEMY_Toatana|r
    .goto 864,52.35,14.19,15,0
    .goto 864,53.46,13.13
    >>Kill |cRXP_ENEMY_Toatana|r. Loot it for the |T2481336:0|t[|cRXP_LOOT_Tempest Caller|r].
    .complete 53762,2 --1/1 Toatana slain
    .complete 53762,3 --1/1 Retrieve the Tempest Caller
    .mob Toatana
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xal'atath|r
    #loop
    .goto 864,53.02,13.68,15,0
    .goto 864,52.55,14.2,10,0
    .goto 864,52.08,14.09,10,0
    .goto 864,51.93,13.68,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xal'atath|r
    .turnin 53762 >>Turn in The Tempest Crown
    .target Xal'atath
    .accept 54126 >>Accept Twist the Knife
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xal'atath|r
    #loop
    .goto 864,53.02,13.68,15,0
    .goto 864,52.55,14.2,10,0
    .goto 864,52.08,14.09,10,0
    .goto 864,51.93,13.68,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xal'atath|r |cRXP_WARN_next to you or at the entrance|r
    .turnin 53762 >>Turn in The Tempest Crown
    .target Xal'atath
    .accept 53763 >>Accept Twist the Knife
step
    #completewith next
    #label Xal'atath found
    #hidewindow
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53763,1 << Horde --1/1 Xal'atath found
    .complete 54126,1 << Alliance--1/1 Xal'atath found
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    #completewith Xal'atath found
    .goto 864,51.81,13.32
    .vehicle >>Click on the |cRXP_PICK_Serpent (Mishi)|r
    .timer 45,RP
    .target Mishi
step << Horde
    #requires Xal'atath found
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53763,1 --1/1 Xal'atath found
step <<Alliance
    #requires Xal'atath found
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 54126,1 --1/1 Xal'atath found
step << Alliance
    #arrowtext Click\n|cRXP_PICK_Void Stone|r
    .goto 1363,28.18,54.29
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Stone|r
    .complete 54126,3 --1/1 Void Stone placed
step << Alliance
    #arrowtext Click\n|cRXP_PICK_Trident|r
    .goto 1363,27.94,53.25
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trident|r
    .complete 54126,4 --1/1 Trident of Deep Ocean placed
step << Alliance
    #arrowtext Click\n|cRXP_PICK_Tempest Caller|r
    .goto 1363,27.93,52.68
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tempest Caller|r
    .complete 54126,5 --1/1 Tempest Caller placed
    .timer 10,RP
step << Horde
    #arrowtext Click\n|cRXP_PICK_Void Stone|r
    .goto 1363,27.97,54.57
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Stone|r
    .complete 53763,3 --1/1 Void Stone placed
step << Horde
    #arrowtext Click\n|cRXP_PICK_Trident|r
    .goto 1363,27.94,53.25
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Trident|r
    .complete 53763,4 --1/1 Trident of Deep Ocean placed
step << Horde
    #arrowtext Click\n|cRXP_PICK_Tempest Caller|r
    .goto 1363,27.89,52.20
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Tempest Caller|r
    .complete 53763,5 --1/1 Tempest Caller placed
    .timer 10,RP
step << Horde
    #arrowtext Wait for the roleplay
    .goto 1363,28.44,54.53
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 53763,6 --1/1 Gift received
step << Alliance
    #arrowtext Wait for the roleplay
    .goto 1363,28.44,54.53
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 54126,6 --1/1 Gift received
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 54126 >>Turn in Twist the Knife
    .complete 84779,2 --Aid Xal'atath across Kul Tiras and Zandalar
    .target Lorewalker Cho
    .turnin 84779 >>Turn in Lorewalking: The Blade's Gambit
    .accept 84782 >>Accept Lorewalking: The Blade's Past
    .timer 8, RP
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 53763 >>Turn in Twist the Knife
    .complete 84779,2 --Aid Xal'atath across Kul Tiras and Zandalar
    .target Lorewalker Cho
    .turnin 84779 >>Turn in Lorewalking: The Blade's Gambit
    .accept 84782 >>Accept Lorewalking: The Blade's Past
    .timer 8, RP
step
    #arrowtext Wait for the roleplay
    .goto 85,54.35,56.66,-1
    .goto 84,64.24,16.10,-1
    .goto 2339,49.6,31.63,-1
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 84782,1 --1/1 Talk to Lorewalker Cho to learn of Xal'atath's distant past
    .target Lorewalker Cho
step
    .isOnQuest 84782 --Lorewalking: The Blade's Past
    .zone 2381 >>Enter Ny'alotha
step
    #completewith next
    #label The Blade's Past
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xithixxin|r
    .turnin 84782 >>Turn in Lorewalking: The Blade's Past
    .target Xithixxin
    .accept 85871 >>Accept Lorewalking: The Blade's Forces
    .disablecheckbox
    .accept 84784 >>Accept Lorewalking: The Blade's Nemeses
    .disablecheckbox
step
    #arrowtext Leave the vehicle
    #completewith The Blade's Past
    .goto 2381,52.58,72.86
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xithixxin|r
    #requires The Blade's Past
    .goto 2381,52.58,72.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xithixxin|r
    .turnin 84782 >>Turn in Lorewalking: The Blade's Past
    .target Xithixxin
    .accept 85871 >>Accept Lorewalking: The Blade's Forces
    .accept 84784 >>Accept Lorewalking: The Blade's Nemeses
step
    #completewith C'Thun
    *Use |T236171:0|t[Dark Leap] for movement and to stun enemies.
    *Use |T425954:0|t[Breath of Shadow] on Cooldown; |cRXP_WARN_ however, prioritize using it for AoE when possible.|r.
    *Use |T537022:0|t[Reach of N'Zoth] when |T425954:0|t[Breath of Shadow] is on cooldown.
    *Use |T135913:0|t[Strength of the Deep] to apply a healing-over-time effect to yourself.
    >>Kill |cRXP_ENEMY_Xal'atath's forces|r
    .complete 85871,1 --Xal'atath's forces slain (100%)
    .mob Shadowshaper
    .mob Shadowlasher
step
    #arrowtext Click\n|cRXP_PICK_Obelisk|r
    .goto 2381,56.94,67.69,15,0
    .goto 2381,56.30,62.53,15,0
    .goto 2384,52.44,19.41,15,0
    .goto 2384,44.76,32.85,15,0
    .goto 2384,53.27,63.71
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r
    .complete 84784,1 --1/1 Yogg-Saron summoned
step
    #completewith next
    #hidewindow
    #label Y'Shaarj summoned
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r
    .complete 84784,2 --1/1 Y'Shaarj summoned
step
    #arrowtext Use [Path of the Chosen]
    #completewith Y'Shaarj summoned
    .goto 2384,53.08,50.65
    .cast 471456 >>Use |T1386548:0|t[Path of the Chosen] (6)
step
    #requires Y'Shaarj summoned
    #completewith next
    #hidewindow
    #label Y'Shaarj summoned2
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r
    .complete 84784,2 --1/1 Y'Shaarj summoned
step
    #arrowtext Use [Path of the Chosen]
    #requires Y'Shaarj summoned
    #completewith next
    .goto 2381,59.93,53.62
    .cast 466734 >>Use |T1386548:0|t[Path of the Chosen] (6)
step
    #arrowtext Click\n|cRXP_PICK_Obelisk|r
    #requires Y'Shaarj summoned2
    .goto 2383,36.95,50.3
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r
    .complete 84784,2 --1/1 Y'Shaarj summoned
step
    #completewith next
    #label CThunSummonedA
    #hidewindow
    .complete 84784,3 --1/1 C'Thun summoned
step
    #arrowtext Use [Path of the Chosen]
    #completewith CThunSummonedA
    .goto 2383,32.41,46.45
    .cast 466734 >>Use |T1386548:0|t[Path of the Chosen] (6)
step
    #arrowtext Click\n|cRXP_PICK_Obelisk|r
    #requires CThunSummonedA
    #label C'Thun
    .goto 2381,52.2,45.53,20,0
    .goto 2381,48.71,46.58,20,0
    .goto 2382,81.44,91.38,20,0
    .goto 2381,42.14,38.97,20,0
    .goto 2381,41.8,37.57,20,0
    .goto 2382,66.83,74.22,20,0
    .goto 2382,58.06,60.72
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Obelisk|r
    .complete 84784,3 --1/1 C'Thun summoned
step
    #arrowtext Kill\n|cRXP_ENEMY_Xal'atath's forces|r
    #loop
    .goto 2381,42.3,38.13,8,0
    .goto 2381,42.76,40.14,8,0
    .goto 2381,49.44,48.52,30,0
    .goto 2381,52.05,45.49,30,0
    .goto 2381,57.05,54.05,30,0
    .goto 2381,57.39,61.12,30,0
    .goto 2381,50.77,53.24,30,0
    .goto 2381,47.21,53.9,30,0
    *Use |T236171:0|t[Dark Leap] for movement and to stun enemies.
    *Use |T425954:0|t[Breath of Shadow] on Cooldown; |cRXP_WARN_ however, prioritize using it for AoE when possible.|r.
    *Use |T537022:0|t[Reach of N'Zoth] when |T425954:0|t[Breath of Shadow] is on cooldown.
    *Use |T135913:0|t[Strength of the Deep] to apply a healing-over-time effect to yourself.
    >>Kill |cRXP_ENEMY_Xal'atath's forces|r
    .complete 85871,1 --Xal'atath's forces slain (100%)
    .mob Shadowshaper
    .mob Shadowlasher
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Xithixxin|r
    .goto 2381,52.62,72.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Xithixxin|r
    .turnin 84784 >>Turn in Lorewalking: The Blade's Nemeses
    .turnin 85871 >>Turn in Lorewalking: The Blade's Forces
    .accept 84789 >>Accept Lorewalking: The Blade's Downfall
    .target Xithixxin
step
    #completewith next
    #label Descend to the Annex of Prophecy
    .complete 84789,1 --1/1 Descend to the Annex of Prophecy
step
    #arrowtext Use [Path of the Chosen]
    #completewith Descend to the Annex of Prophecy
    .goto 2379,50.97,28.05
    *Spam cast |T236171:0|t[Dark Leap] (3) for movement.
    .cast 466734 >>Use |T1386548:0|t[Path of the Chosen] (6)
step
    #requires Descend to the Annex of Prophecy
    #title |cFFFCDC00Follow the Arrow|r
    .goto 2379,50.97,77.46
    *Spam cast |T236171:0|t[Dark Leap] (3) for movement.
    .complete 84789,1 --1/1 Descend to the Annex of Prophecy
step
    #arrowtext Use [Darktide]
    .goto 2379,50.96,77.53
    >>Use |T237561:0|t[Darktide] (1).
    .complete 84789,2 --1/1 Xal'atath defeated
    .mob Xal'atath
step
    #label LorewalkingCampaignEnd
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.24,16.10,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 84789 >>Turn in Lorewalking: The Blade's Downfall
    .target Lorewalker Cho
]])
--Ethereals
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Miscellaneous
#subgroup Lorewalking
#name ab) Ethereals
#displayname Ethereals
#next ac) The Lich King

step
    .chromieon
    .goto 84,56.27,17.32 << Alliance
    .goto 85,40.84,80.17 << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Chromie|r
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Stormwind and ask her to return you to the present timeline. << Alliance
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Orgrimmar and ask her to return you to the present timeline. << Horde
    .skipgossipid 51903
    .target Chromie
step
    #completewith LorewalkingCampaignEnd
    +Click on the |cRXP_PICK_Ask a Question|r button in the "Active Items Frame" to talk to the Lorewalker if needed.
    *To stop the campaign, click on |cRXP_PICK_Exit Lorewalking|r in the Lorewalking panel.
    .macro Ask a Question,2056011 >>/cast spell:1242675
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 84,64.24,16.10,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Stormwind|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 85,54.24,56.59,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Orgrimmar|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 84,64.24,16.10,-1 <<Alliance
    .goto 85,54.28,56.56,-1 <<Horde
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .accept 85027 >>Accept Lorewalking: The Protectorate
    .timer 39,RP
    .skipgossipid 124311
    .choose 6403387
    .target Lorewalker Cho
step
    #arrowtext Wait for the roleplay
    .goto 84,64.24,16.10,-1 <<Alliance
    .goto 85,54.28,56.56,-1 <<Horde
    .goto 2339,49.62,31.52,-1
    >>|cRXP_WARN_Wait for the roleplay|r.
    .complete 85027,1 --1/1 Talk to Lorewalker Cho to learn about the Ethereals
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho |r
    .goto 84,64.24,16.10,-1 <<Alliance
    .goto 85,54.28,56.56,-1 <<Horde
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho |r
    .complete 85027,2 --1/1 Talk to Lorewalker Cho to learn about the Protectorate
    .skipgossipid 124637
    .target Lorewalker Cho
step
    .isOnQuest 85027 --Lorewalking: The Protectorate
    .zone 109 >> Enter Netherstorm
step
    #completewith next
    #label The Ethereum
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
    .accept 10339 >>Accept The Ethereum
    .target Commander Ameer
step
    #arrowtext Leave the vehicle
    #completewith The Ethereum
    .goto 109,59.50,32.39
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Commander Ameer|r
    #requires The Ethereum
    .goto 109,59.50,32.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Commander Ameer|r
    .accept 10339 >>Accept The Ethereum
    .target Commander Ameer
step
    #arrowtext Kill\n|cRXP_ENEMY_Ethereum forces|r and |cRXP_ENEMY_Captain Zovax|r
    #loop
    .goto 109,57.21,33.42,40,0
    .goto 109,56.98,36.09,40,0
    .goto 109,56.76,40.61,40,0
    .goto 109,55.24,40.77,40,0
    .goto 109,58.03,36.11,40,0
    >>Kill the |cRXP_ENEMY_Ethereum forces|r and |cRXP_ENEMY_Captain Zovax|r
    .complete 10339,1 --5/5 Ethereum Assassin slain
    .mob +Ethereum Assassin
    .complete 10339,2 --5/5 Ethereum Shocktrooper slain
    .mob +Ethereum Shocktrooper
    .complete 10339,3 --2/2 Ethereum Researcher slain
    .mob +Ethereum Researcher
    .complete 10339,4 --1/1 Captain Zovax slain
    .mob +Captain Zovax
-- step
--     #completewith next
--     #label Ethereum
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r
--     .turnin 10339 >>Turn in The Ethereum
--     .accept 10384 >>Accept Ethereum Data
--     .disablecheckbox
-- step
--     #completewith Ethereum
--     .goto 109,56.82,38.70
--     .cast 3365 >>Click on the |cRXP_PICK_Ethereum Transponder Zeta|r
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Image of Commander Ameer|r
    .goto 109,56.82,38.70
    *|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Transponder Zeta|r if necessary,
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Image of Commander Ameer|r
    .turnin 10339 >>Turn in The Ethereum
    .accept 10384 >>Accept Ethereum Data
step
    #arrowtext Click\n|cRXP_PICK_Ethereum Data Cell|r
    .goto 109,55.77,39.89
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Data Cell|r.
    .complete 10384,1 --1/1 Ethereum Data Cell
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Image of Commander Ameer|r
    .goto 109,56.82,38.70
    *|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Transponder Zeta|r if necessary.
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r.
    .turnin 10384 >>Turn in Ethereum Data
    .target Image of Commander Ameer
    .accept 10385 >>Accept Potential for Brain Damage = High
step
    #hidewindow
    #completewith Ethereum Relay Data
    #loop
    .goto 109,56.49,41.09,40,0
    .goto 109,55.99,42.73,40,0
    .goto 109,54.56,41.68,40,0
    .goto 109,55.89,38.84,40,0
    .goto 109,57.06,35.45,40,0
    .goto 109,57.98,36.36,40,0
    +1
step
    .isOnQuest 10385 --Potential for Brain Damage = High
    .aura 35409
    >>Kill any |cRXP_ENEMY_Ethereums|r. Loot them for an |T134729:0|t[|cRXP_LOOT_Ethereum Essence|r]. |cRXP_WARN_Use it.|r
    .collect 29482,1
    .cast 35409 >>Use [Ethereum Essence|r].
    .use 29482
    .mob Ethereum Assassin
    .mob Ethereum Shocktrooper
    .mob Ethereum Researcher
    .mob Captain Zovax
step
    #label Ethereum Relay Data
    .aura -35409
    >>Kill the |cRXP_ENEMY_Ethereum Relays|r. Loot them for the |T134139:0|t[|cRXP_LOOT_Ethereum Relay Data|r].
    .complete 10385,2 --12/12 Ethereum Relay Data
    .mob Ethereum Relay
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Image of Commander Ameer|r
    .goto 109,56.82,38.71
    *|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Transponder Zeta|r if necessary.
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r.
    .turnin 10385 >>Turn in Potential for Brain Damage = High
    .accept 10406 >>Accept Delivering the Message
    .timer 110,RP
    .target Image of Commander Ameer
step
    >>Escort and Protect |cRXP_FRIENDLY_Protectorate Demolitionist|r.
    .complete 10406,1 --Sabotage
    .target Protectorate Demolitionist
    .mob Ethereum Archon
    .mob Ethereum Overlord
    .mob Ethereum Nexus-Stalker
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Image of Commander Ameer|r
    .goto 109,56.82,38.71
    *|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Transponder Zeta|r if necessary.
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r.
    .target Image of Commander Ameer
    .turnin 10406 >>Turn in Delivering the Message
    .accept 10408 >>Accept Nexus-King Salhadaar
step
    #arrowtext Use [Protectorate Disruptor]\non |cRXP_ENEMY_Nexus-King Salhadaar|r
    #completewith next
    .goto 109,53.64,42.37,5,0
    .goto 109,53.7,42.02,5,0
    .goto 109,53.32,42.31,5,0
    .goto 109,53.73,42.87,5,0
    >>Use |T133002:0|t[Protectorate Disruptor] |cRXP_WARN_next to each power conduit to activate the |cRXP_ENEMY_Nexus-King Salhadaar|r.|r
    *|cRXP_WARN_Ignore this step if he's already active|r.
    .complete 10408,1 --3/3 Salhadaar's Power Conduits disrupted (Optional)
    .timer 17,RP
    .use 29618
step
    #arrowtext Kill\n|cRXP_ENEMY_Nexus-King Salhadaar|r
    .goto 109,53.64,42.37
    >>Kill |cRXP_ENEMY_Nexus-King Salhadaar|r.
    .complete 10408,2 --1/1 Nexus-King Salhadaar slain
    .mob Nexus-King Salhadaar
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Image of Commander Ameer|r
    .goto 109,56.83,38.68
    *|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Ethereum Transponder Zeta|r if necessary.
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Image of Commander Ameer|r.
    .turnin 10408 >>Turn in Nexus-King Salhadaar
    .complete 85027,3 --Aid the Protectorate against Nexus-King Salhadaar
    .target Image of Commander Ameer
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho to learn about Dimensius|r
    .goto 109,56.83,38.68
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho to learn about Dimensius|r
    .complete 85027,4 --1/1 Talk to Lorewalker Cho to learn about Dimensius
    .skipgossipid 134099
    .target Lorewalker Cho to learn about Dimensius
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Professor Dabiri|r
    .goto 109,60.11,31.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
    .accept 10437 >>Accept Recipe for Destruction
    .target Professor Dabiri
step
    #arrowtext Kill\n|cRXP_ENEMY_Voidshrieker|r and |cRXP_ENEMY_Unstable Voidwraiths|r
    #loop
    .goto 109,60.75,37.3,30,0
    .goto 109,60.67,39.56,30,0
    .goto 109,61.91,37.21,30,0
    .goto 109,62.9,34.94,30,0
    .goto 109,61.62,34.21,30,0
    .goto 109,65.45,38.5,30,0
    .goto 109,65.92,42.03,30,0
    .goto 109,64.41,42.03,30,0
    .goto 109,60.84,43.11,30,0
    .goto 109,59.32,41.12,30,0
    >>Kill |cRXP_ENEMY_Voidshrieker|r and |cRXP_ENEMY_Unstable Voidwraiths|r. Loot them for the |T132776:0|t[|cRXP_LOOT_Fragments of Dimensius|r].
    .complete 10437,1 --4/4 Fragment of Dimensius
    .mob Voidshrieker
    .mob Unstable Voidwraith
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Professor Dabiri|r
    .goto 109,60.12,31.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
    .turnin 10437 >>Turn in Recipe for Destruction
    .complete 85027,5 --Help Professor Dabiri prepare to attack Dimensius
    .target Professor Dabiri
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Professor Dabiri|r
    .goto 109,60.12,31.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
    .accept 10439 >>Accept Dimensius the All-Devouring
    .target Professor Dabiri
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Captain Saeed|r
    .goto 109,60.64,32.08
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Captain Saeed|r
    .complete 10439,1 --1/1 Speak to Captain Saeed
    .skipgossipid 33088
step
    #completewith next
    #label Dimensius the All-Devouring
    >>Kill |cRXP_ENEMY_Dimensius the All-Devouring|r
    .complete 10439,3 --1/1 Dimensius the All-Devouring slain
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Captain Saeed|r
    #completewith next
    #completewith Dimensius the All-Devouring
    .goto 109,60.78,39.22,20,0
    .gossipoption 33644 >>Talk to |cRXP_FRIENDLY_Captain Saeed|r |cRXP_WARN_[2]|r.
    *|cRXP_WARN_Someone may have already spoken to him; if so, just move on|r.
    .target Captain Saeed
step
    #hidewindow
    #completewith Dimensius the All-Devouring
    .goto 109,61.33,39.81,10 >>Follow the Arrow
step
    #arrowtext Kill\n|cRXP_ENEMY_Dimensius the All-Devouring|r
    #requires Dimensius the All-Devouring
    #loop
    .goto 109,62.50,40.82,10,0
    .goto 109,60.78,39.22,20,0
    >>Kill |cRXP_ENEMY_Dimensius the All-Devouring|r
    .complete 10439,3 --1/1 Dimensius the All-Devouring slain
    .mob Dimensius the All-Devouring
step
    #completewith next
    #label Professor Dabiri
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
    .turnin 10439 >>Turn in Dimensius the All-Devouring
    .target Professor Dabiri
step
    #arrowtext Exit the building
    #completewith Professor Dabiri
    .goto 109,60.88,39.26,10 >>Exit the building
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Professor Dabiri|r
    #requires Professor Dabiri
    .goto 109,60.11,31.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Professor Dabiri|r
    .turnin 10439 >>Turn in Dimensius the All-Devouring
    .target Professor Dabiri
    .complete 85027,6 --Aid the Protectorate forces against Dimensius the All-Devouring
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 109,60.11,31.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85027 >>Turn in Lorewalking: The Protectorate
    .accept 85029 >>Accept Lorewalking: Locus-Walker
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 109,60.11,31.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85029,1 --1/1 Talk to Lorewalker Cho to learn about void ethereals
    .skipgossipid 124639
    .target Lorewalker Cho
step
    .isOnQuest 85029 --Lorewalking: Locus-Walker
    .zone 882 >>Enter Argus
step
    #completewith next
    #label Throwing Shade
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
    .accept 47203 >>Accept Throwing Shade
    .target Alleria Windrunner
step
    #arrowtext Leave the vehicle
    #completewith Throwing Shade
    .goto 882,35.34,59.55
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    #requires Throwing Shade
    #label Throwing Shade
    .goto 882,35.34,59.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
    .accept 47203 >>Accept Throwing Shade
    .target Alleria Windrunner
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    .goto 882,35.33,59.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r |cRXP_WARN_after the roleplay|r.
    .accept 47203 >>Accept Throwing Shade
    .target Alleria Windrunner
step
    .goto 882,36.83,52.64
    #title |cFFFCDC00Follow the Arrow|r
    .complete 47203,1 --1/1 Meet Alleria in Umbra Hollows
    .timer 19,Roleplay
step
    #arrowtext Click\n|cRXP_PICK_Void Tear|r
    .goto 882,37.11,52.36
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Tear|r.
    .complete 47203,2 --1/1 Enter the Void Tear
step
    #arrowtext |cFFFCDC00Avoid the Void Effusions|r
    .goto 882,37.11,52.36,0
    .goto 882,39.66,48.19
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dismantled Portal|r.
    .complete 47203,3 --1/1 Dismantled Portal examined
step
    #arrowtext |cFFFCDC00Avoid the Void Effusions|r
    .goto 882,35.51,43.67
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Image of Saprish|r.
    .complete 47203,4 --1/1 Image of Saprish examined
step
    #arrowtext |cFFFCDC00Avoid the Void Effusions/Voidcasters|r
    .goto 882,36.06,38.67
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voidforge|r.
    .complete 47203,5 --1/1 Voidforge examined
step
    #arrowtext |cFFFCDC00Avoid the Void Effusions/Voidcasters|r
    .goto 882,32.11,37.79
    >>Follow the Arrow
    .complete 47203,6 --1/1 Meet Alleria and Locus-Walker
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
    .turnin 47203 >>Turn in Throwing Shade
    .accept 47217 >>Accept Sources of Darkness
    .goto 882,31.87,37.47
    .target +Alleria Windrunner
    .accept 47218 >>Accept The Shadowguard Incursion
    .goto 882,31.93,37.33
    .target +Locus-Walker
step
    #completewith SourcesOfDarknessA
    >>Kill the |cRXP_ENEMY_Shadowguard forces|r.
    .complete 47218,1 --15/15 Shadowguard Ethereals slain
    .mob Enthralled Voidstalker
    .mob Shadowguard Phaseblade
    .mob Shadowguard Adept
step
    #arrowtext Harversters deactivated (1/5) |cFFFCDC00(Read Note)|r
    .goto 882,32.07,34.9,15,0
    .goto 882,31.67,34.4
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvesters|r.
    *|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
    .complete 47217,1,1 --1/5 Void Harvesters deactivated
step
    #arrowtext Harversters deactivated (2/5) |cFFFCDC00(Read Note)|r
    .goto 882,28.36,34.24
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvesters|r.
    *|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
    .complete 47217,1,2 --2/5 Void Harvesters deactivated
step
    #arrowtext Harversters deactivated (3/5) |cFFFCDC00(Read Note)|r
    .goto 882,25.59,32.15
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvesters|r.
    *|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
    .complete 47217,1,3 --3/5 Void Harvesters deactivated
step
    #arrowtext Harversters deactivated (4/5) |cFFFCDC00(Read Note)|r
    .goto 882,24.65,33.37
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvesters|r.
    *|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
    .complete 47217,1,4 --4/5 Void Harvesters deactivated
step
    #arrowtext Harversters deactivated (5/5) |cFFFCDC00(Read Note)|r
    #label SourcesOfDarknessA
    .goto 882,25.06,35.76
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvesters|r.
    *|cRXP_WARN_NOTE:|r The order is hardcoded. If you do the quest in a different order then the waypoint will be wrong.
    .complete 47217,1 --5/5 Void Harvesters deactivated
step
    #arrowtext Kill\n|cRXP_ENEMY_Shadowguard forces|r
    #loop
    .goto 882,23.26,41.08,40,0
    .goto 882,27.67,38.10,35,0
    .goto 882,29.15,32.40,35,0
    .goto 882,25.26,32.01,35,0
    >>Kill the |cRXP_ENEMY_Shadowguard forces|r.
    .complete 47218,1 --15/15 Shadowguard Ethereals slain
    .mob Enthralled Voidstalker
    .mob Shadowguard Phaseblade
    .mob Shadowguard Adept
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Locus-Walker|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Locus-Walker|r.
    .turnin 47217 >>Turn in Sources of Darkness
    .goto 882,31.88,37.48
    .target +Alleria Windrunner
    .turnin 47218 >>Turn in The Shadowguard Incursion
    .accept 47219 >>Accept A Vessel Made Ready
    .timer 19,Void Tear Spawn
    .goto 882,31.93,37.33
    .target +Locus-Walker
step
    #arrowtext Click\n|cRXP_PICK_Void Tear|r
    .goto 882,31.94,37.03
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Tear|r.
    .complete 47219,1 --1/1 Enter the Void Tear
step
    #arrowtext Kill\n|cRXP_ENEMY_Shadowguard Abyss Caller|r and |cRXP_ENEMY_Nhal'atoth|r
    .goto 882,26.68,44.99
    >>Kill the |cRXP_ENEMY_Shadowguard Abyss Caller|r and |cRXP_ENEMY_Nhal'atoth|r.
    .complete 47219,2 --1/1 Defeat Nhal'athoth
    .mob Shadowguard Abyss Caller
    .mob Nhal'atoth
step
    #arrowtext Click\n|cRXP_PICK_Heart of Nhal'atoth|r
    .goto 882,26.68,44.99
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Heart of Nhal'atoth|r.
    .complete 47219,3 --1/1 Heart of Nhal'athoth
    .timer 15,Alleria Roleplay
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    .goto 882,28.44,47.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r.
    .turnin 47219 >>Turn in A Vessel Made Ready
    .timer 5,Alleria Roleplay
    .target Alleria Windrunner




-
step
    .goto 882,37.13,52.32
    #title |cFFFCDC00Follow the Arrow|r
    .complete 47203,1 --1/1 Meet Alleria in Umbra Hollows
    .timer 20,RP
step
    #arrowtext Click\n|cRXP_PICK_Void Tear|r
    .goto 882,37.04,52.31
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Tear|r |cRXP_WARN_after the roleplay|r.
    .complete 47203,2 --1/1 Enter the Void Tear
step
    #completewith Voidforge
    +|cRXP_WARN_Avoid the circles around |cRXP_ENEMY_Void Effusions|r and stay away from the |cRXP_ENEMY_Shadowguards|r|r
step
    #arrowtext Click\n|cRXP_PICK_Dismantled Portal|r
    .goto 882,37.82,50.88,15,0
    .goto 882,39.63,48.21
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Dismantled Portal|r.
    .complete 47203,3 --1/1 Dismantled Portal examined
step
    #arrowtext Click\n|cRXP_PICK_Image of Saprish|r
    .goto 882,39.07,47.22,10,0
    .goto 882,37.51,45.44,15,0
    .goto 882,35.55,43.71
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Image of Saprish|r.
    .complete 47203,4 --1/1 Image of Saprish examined
step
    #arrowtext Click\n|cRXP_PICK_Voidforge|r
    #label Voidforge
    .goto 882,35.32,41.43,10,0
    .goto 882,36.02,38.72
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Voidforge|r.
    .complete 47203,5 --1/1 Voidforge examined
step
    .goto 882,33.35,39.58,15,0
    .goto 882,31.87,37.47
    #title |cFFFCDC00Follow the Arrow|r
    .complete 47203,6 --1/1 Meet Alleria and Locus-Walker
    .timer 15,RP
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    .goto 882,31.87,37.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
    .turnin 47203 >>Turn in Throwing Shade
    .accept 47217 >>Accept Sources of Darkness
    .target Alleria Windrunner
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Locus-Walker|r
    .goto 882,31.94,37.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Locus-Walker|r
    .accept 47218 >>Accept The Shadowguard Incursion
    .target Locus-Walker
step
    #completewith Void Harvesters
    >>Kill |cRXP_ENEMY_Shadowguards|r
    .complete 47218,1 --15/15 Shadowguard ethereals slain
    .mob Shadowguard Siphoner
    .mob Shadowguard Phaseblade
    .mob Shadowguard Adept
step
    #arrowtext Click\n|cRXP_PICK_Void Harvester|r
    .goto 882,32.07,34.9,15,0
    .goto 882,31.67,34.4
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvester|r
    .complete 47217,1,1 --5/5 Void Harvesters deactivated
step
    #arrowtext Click\n|cRXP_PICK_Void Harvester|r
    .goto 882,28.33,34.24
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvester|r
    .complete 47217,1,2 --5/5 Void Harvesters deactivated
step
    #arrowtext Click\n|cRXP_PICK_Void Harvester|r
    .goto 882,25.59,32.15
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvester|r
    .complete 47217,1,3 --5/5 Void Harvesters deactivated
step
    #arrowtext Click\n|cRXP_PICK_Void Harvester|r
    .goto 882,24.67,33.4
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvester|r
    .complete 47217,1,4 --5/5 Void Harvesters deactivated
step
    #arrowtext Click\n|cRXP_PICK_Void Harvester|r
    #label Void Harvesters
    .goto 882,25.07,35.76
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Harvester|r
    .complete 47217,1,5 --5/5 Void Harvesters deactivated
step
    #arrowtext Kill\n|cRXP_ENEMY_Shadowguards|r
    #loop
    .goto 882,27.16,39.85,40,0
    .goto 882,25.7,42.24,40,0
    .goto 882,23.38,39.49,40,0
    .goto 882,24.62,35.32,40,0
    >>Kill |cRXP_ENEMY_Shadowguards|r
    .complete 47218,1 --15/15 Shadowguard ethereals slain
    .mob Shadowguard Siphoner
    .mob Shadowguard Phaseblade
    .mob Shadowguard Adept
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Locus-Walker|r
    .goto 882,31.91,37.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r and |cRXP_FRIENDLY_Locus-Walker|r
    .turnin 47217 >>Turn in Sources of Darkness
    .target +Alleria Windrunner
    .turnin 47218 >>Turn in The Shadowguard Incursion
    .accept 47219 >>Accept A Vessel Made Ready
    .timer 20,RP
    .target +Locus-Walker
step
    #arrowtext Click\n|cRXP_PICK_Portal|r
    .goto 882,31.92,37.03
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Portal|r |cRXP_WARN_after the roleplay|r.
    .complete 47219,1 --1/1 Enter the Void Tear
step
    #arrowtext Kill\n|cRXP_ENEMY_Shadowguard Abyss Callers|r and |cRXP_ENEMY_Nhal'athoth|r
    .goto 882,27.29,44.85,15,0
    .goto 882,26.82,45.88,15,0
    .goto 882,26.53,43.99,15,0
    .goto 882,26.6,44.94
    >>Kill the |cRXP_ENEMY_Shadowguard Abyss Callers|r and |cRXP_ENEMY_Nhal'athoth|r.
    .complete 47219,2 --1/1 Defeat Nhal'athoth
    .timer 10,RP
step
    #arrowtext Click\n|cRXP_PICK_Heart of Nhal'athoth|r
    .goto 882,26.6,44.94
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Heart of Nhal'athoth|r |cRXP_WARN_after the roleplay|r.
    .complete 47219,3 --1/1 Heart of Nhal'athoth
    .mob Shadowguard Abyss Caller
    .mob Nhal'athoth
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Alleria Windrunner|r
    #label A Vessel Made Ready
    .goto 882,28.43,47.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Alleria Windrunner|r
    .turnin 47219 >>Turn in A Vessel Made Ready
    .target Alleria Windrunner
    .complete 85029,2 --Aid Locus-Walker in teaching Alleria to master the Void
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 882,28.43,47.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85029 >>Turn in Lorewalking: Locus-Walker
    .target Lorewalker Cho
    .accept 85028 >>Accept Lorewalking: The Brokers
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 882,28.43,47.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85028,1 --1/1 Talk to Lorewalker Cho
    .skipgossipid 124635
    .target Lorewalker Cho
step
    #completewith next
    #label The Al'ley Cat of Oribos
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Host Ta'rela|r
    .accept 63976 >>Accept The Al'ley Cat of Oribos
    .target Host Ta'rela
step
    #arrowtext Leave the vehicle
    #completewith The Al'ley Cat of Oribos
    .goto 2381,52.58,72.86
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Host Ta'rela|r
    #requires The Al'ley Cat of Oribos
    .goto 1670,67.50,50.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Host Ta'rela|r
    .accept 63976 >>Accept The Al'ley Cat of Oribos
    .target Host Ta'rela
step
    #completewith next
    #label Al'ley Cat of Oribos
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .turnin 63976 >>Turn in The Al'ley Cat of Oribos
    .target Al'dalil
step
    #hidewindow
    #completewith Al'ley Cat of Oribos
    .goto 1670,69.38,42.87,10,0
    .goto 1672,57.5,27.72,10 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Al'dalil|r
    #requires Al'ley Cat of Oribos
    .goto 1672,56.72,31.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .turnin 63976 >>Turn in The Al'ley Cat of Oribos
    .accept 63977 >>Accept Insider Trading
    .accept 63979 >>Accept Things Best Kept Dark
    .target Al'dalil
step
    #completewith next
    #label Cartel Ta
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overseer Ta'readon|r
    .complete 63977,4 --1/1 Cartel Ta spoken to
    .target Overseer Ta'readon
step
    #hidewindow
    #completewith Cartel Ta
    .goto 1670,70.67,40.41,10,0
    .goto 1670,65.54,49.48,10,0
    .goto 1670,62.26,51.5,10,0
    .goto 1670,60.5,62.23,10,0
    .goto 1670,64.37,68.31,40 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Overseer Ta'readon|r
    #requires Cartel Ta
    .goto 1670,64.37,68.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Overseer Ta'readon|r
    .complete 63977,4 --1/1 Cartel Ta spoken to
    .skipgossipid 54344
    .target Overseer Ta'readon
step
    #completewith next
    #label Cartel Ba
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Emissary Ba'hask|r
    .complete 63977,1 --1/1 Cartel Ba spoken to
    .target Emissary Ba'hask
step
    #completewith Cartel Ba
    #hidewindow
    .goto 1670,54.69,73.83,10,0
    .goto 1670,50.28,73.85,20,0
    .goto 1670,47.36,73.16,20 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Emissary Ba'hask|r
    #requires Cartel Ba
    .goto 1670,47.70,72.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Emissary Ba'hask|r
    .complete 63977,1 --1/1 Cartel Ba spoken to
    .skipgossipid 51187
    .target Emissary Ba'hask
step
    #completewith next
    #label Cartel Zo
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zo'sorg|r
    .complete 63977,2 --1/1 Cartel Zo spoken to
    .target Zo'sorg
step
    #hidewindow
    #completewith Cartel Zo
    .goto 1670,44.81,70.91,10,0
    .goto 1670,36.99,60.16,10,0
    .goto 1670,34.48,57.49,30 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Zo'sorg|r
    #requires Cartel Zo
    .goto 1670,34.48,57.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zo'sorg|r
    .complete 63977,2 --1/1 Cartel Zo spoken to
    .skipgossipid 53363
    .target Zo'sorg
step
    #completewith next
    #label Cartel Au
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Au'brak|r
    .complete 63977,3 --1/1 Cartel Au spoken to
    .target Foreman Au'brak
step
    #hidewindow
    #completewith Cartel Au
    .goto 1670,35.59,54.03,10,0
    .goto 1670,37.48,41.83,10,0
    .goto 1670,40.37,32.59,50 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Foreman Au'brak|r
    #requires Cartel Au
    .goto 1670,40.37,32.59
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Foreman Au'brak|r
    .complete 63977,3 --1/1 Cartel Au spoken to
    .skipgossipid 54347
    .target Foreman Au'brak
step
    #completewith next
    #label Shipping Manifest
    #hidewindow
    .complete 63979,1 --1/1 Cartel So Shipping Manifest
step
    #completewith next
    .cast 3365 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
step
    #hidewindow
    #completewith Shipping Manifest
    .goto 1670,51.68,24.95,10,0
    .goto 1670,51.11,17.5,10,0
    .goto 1670,48.04,15.84,10,0
    .goto 1670,38.31,22.55,10,0
    .goto 1670,38.53,25.27,30 >>Follow the Arrow
step
    #requires Shipping Manifest
    #completewith next
    #label Shipping Manifest2
    >>Kill |cRXP_ENEMY_So'danah|r. Loot them for |T2178827:0|t[|cRXP_LOOT_Cartel So Shipping Manifest|r].
    .complete 63979,1 --1/1 Cartel So Shipping Manifest
    .mob So'danah
step
    #arrowtext Click\n|cRXP_PICK_Scroll|r
    #requires Shipping Manifest
    #completewith Shipping Manifest2
    .goto 1670,38.53,25.28
    .cast 3365 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Scroll|r.
step
    #arrowtext Kill\n|cRXP_ENEMY_So'danah|r
    #requires Shipping Manifest2
    .goto 1670,38.22,23.39
    >>Kill |cRXP_ENEMY_So'danah|r. Loot them for |T2178827:0|t[|cRXP_LOOT_Cartel So Shipping Manifest|r].
    .complete 63979,1 --1/1 Cartel So Shipping Manifest
step
    #completewith Insider Trading2
    #label Insider Trading
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .turnin 63977 >>Turn in Insider Trading
    .turnin 63979 >>Turn in Things Best Kept Dark
    .target Al'dalil
step
    #completewith next
    .goto 1670,35.04,18.87
    .deathskip >> Jump off the platform --deathskip doesnt work because we dont manually rez at spirt healer maybe
step
    #hidewindow
    #completewith Insider Trading
    .goto 1670,76.91,50.29,40 >>Follow the Arrow
step
    #hidewindow
    #requires Insider Trading
    #label Insider Trading2
    #completewith Insider Trading
    .goto 1670,72.65,47.65,10,0
    .goto 1670,68.15,45.72,10,0
    .goto 1672,57.37,27.76,10 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Al'dalil|r
    #requires Insider Trading
    .goto 1672,56.70,31.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .turnin 63977 >>Turn in Insider Trading
    .target Al'dalil
    .turnin 63979 >>Turn in Things Best Kept Dark
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Al'dalil|r
    .goto 1672,56.70,31.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .accept 63980 >>Accept Seeking Smugglers
    .target Al'dalil
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho about the Night Market (Optional)|r
    .goto 1672,56.57,29.62
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho about the Night Market (Optional)|r
    .complete 85028,3 --1/1 Talk to Cho about the Night Market (Optional)
    .target Cho about the Night Market (Optional)
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ta'nla at the Night Market|r
    .goto 1672,56.46,29.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'nla at the Night Market|r
    .complete 85028,4 --Speak with Ta'nla at the Night Market
    .skipgossipid 124638
    .target Ta'nla at the Night Market
step
    .isOnQuest 63980 --Seeking Smugglers
    .zone 1525 >>Enter Revendreth
step
    #completewith next
    #label Seeking Smugglers
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'nla the Identifier|r
    .turnin 63980 >>Turn in Seeking Smugglers
    .target Ta'nla the Identifier
step
    #arrowtext Leave the vehicle
    #completewith Seeking Smugglers
    .goto 1525,51.34,82.71
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ta'nla the Identifier|r
    #requires Seeking Smugglers
    .goto 1525,51.34,82.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'nla the Identifier|r
    .turnin 63980 >>Turn in Seeking Smugglers
    .target Ta'nla the Identifier
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ta'nla the Identifier|r
    .goto 1525,51.34,82.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'nla the Identifier|r
    .accept 63982 >>Accept Above My Station
    .target Ta'nla the Identifier
step
    #title |cFFFCDC00Enter the portal|r
    .goto 1525,50.97,81.90
    .complete 63982,1 --Portal to Transfer Station Ta taken
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    .goto 1533,32.51,32.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    .turnin 63982 >>Turn in Above My Station
    .target Bounty Hunter Ta'oku
    .accept 63983 >>Accept Dead Drop
step
    #arrowtext |cFFFCDC00Enter the repository|r
    .goto 1533,36.94,31.63,20,0
    .goto 1533,37.37,29.99,20,0
     .goto 1533,36.98,31.47
    >>|cRXP_WARN_Enter the Underground Structure|r
    .complete 63983,1 --Export party found
step
    #arrowtext Defeat\n|cRXP_ENEMY_Prototype Aquilon|r
    .goto 1533,37.37,29.99
    >>Defeat the |cRXP_ENEMY_Prototype Aquilon|r
    .complete 63983,2 --1/1 Prototype Aquilon subdued
    .mob Prototype Aquilon
step
    #completewith next
    #label chat Instructions
    #hidewindow
    >>|cRXP_WARN_Follow the in chat Instructions (5 times)|r
    *|T237290:0|t[Press Buttons] = any text with button in it.
    *|T2909707:0|t[Pull Lever] = any text with lever in it.
    *|T2437249:0|t[Bonk Head] = any text with whack, bonk, strike, or hit in it.
    .complete 63983,3 --1/1 Prototype Aquilon returned
step
    #arrowtext Click\n|cRXP_PICK_Prototype Aquilon|r
    #completewith chat Instructions
    .goto 1533,37.37,29.99
    .vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Prototype Aquilon|r
    .timer 60,RP
    .mob Prototype Aquilon
step
    #requires chat Instructions
    >>|cRXP_WARN_Follow the in chat Instructions (5 times)|r
    *|T237290:0|t[Press Buttons] = any text with button in it.
    *|T2909707:0|t[Pull Lever] = any text with lever in it.
    *|T2437249:0|t[Bonk Head] = any text with whack, bonk, strike, or hit in it.
    .complete 63983,3 --1/1 Prototype Aquilon returned
-- step
--     #completewith next
--     #label in Dead Drop
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
--     .turnin 63983 >>Turn in Dead Drop
--     .target Bounty Hunter Ta'oku
-- step
--     #completewith in Dead Drop
--     .goto 1533,32.52,32.36
--     .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    -- #requires in Dead Drop
    .goto 1533,32.52,32.36
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    .turnin 63983 >>Turn in Dead Drop
    .target Bounty Hunter Ta'oku
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    .goto 1533,32.52,32.36
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Bounty Hunter Ta'oku|r
    .accept 63984 >>Accept Coins for the Ferryman
    .target Bounty Hunter Ta'oku
step
    #completewith next
    #label SerpentA
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'meri|r
    .turnin 63984 >>Turn in Coins for the Ferryman
    .accept 63985 >>Accept The Veiled Market
    .target Ta'meri
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    #completewith SerpentA
    .goto 1533,32.98,32.30
    .vehicle >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Serpent (Mishi)|r
    .timer 15,RP
-- step
--     .goto 1533,32.98,32.30
--     >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Serpent|r
--     .complete 85028,2 --1/1 Ride Mishi to the Tazavesh Ferry -- had an issue with it loading
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ta'meri|r
    #requires SerpentA
    .goto 1670,29.83,66.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'meri|r
    .turnin 63984 >>Turn in Coins for the Ferryman
    .accept 63985 >>Accept The Veiled Market
    .target Ta'meri
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ta'meri|r
    .goto 1670,29.83,66.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ta'meri|r
    .complete 63985,1 --1/1 Barge taken to Tazavesh
    .skipgossipid 51818
    .timer 60,RP
step
    #completewith next
    #label Bouncer spoken to
    #hidewindow
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 63985,2 --1/1 Bouncer spoken to
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Zo'mezal|r
    #completewith Bouncer spoken to
    .goto 2016,84.15,47.3
    .gossipoption 52184 >>Talk to |cRXP_FRIENDLY_Zo'mezal|r |cRXP_WARN_after the roleplay|r
    .timer 45,RP
step
    #arrowtext |cFFFCDC00Follow the arrow|r
    #requires Bouncer spoken to
    .goto 2016,86.69,48.49
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 63985,2 --1/1 Bouncer spoken to
    .target Zo'mezal
    .target Ta'meri
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Al'dalil|r
    .goto 2016,86.69,48.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Al'dalil|r
    .turnin 63985 >>Turn in The Veiled Market
    .target Al'dalil
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 2016,86.67,48.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85028,10 --1/1 Ask Lorewalker Cho about Ve'nari
    .skipgossipid 124632
    .target Lorewalker Cho
step
    .isOnQuest 85028 --Lorewalking: The Brokers
    .zone 1961 >>Enter Korthia
step
    #completewith next
    #label Ease of Passage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ve'nari|r
    .accept 63855 >>Accept Ease of Passage
    .target Ve'nari
step
    #arrowtext Leave the vehicle
    #completewith Ease of Passage
    .goto 1961,65.98,23.12
    .exitvehicle >>|cRXP_WARN_Leave the vehicle|r
    .macro Leave Vehicle,6656430 >>/leavevehicle
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ve'nari|r
    #requires Ease of Passage
    .goto 1961,65.91,22.91
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ve'nari|r
    .accept 63855 >>Accept Ease of Passage
    .target Ve'nari
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ve'nari|r
    .goto 1961,65.91,22.91
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ve'nari|r
    .complete 63855,1 --1/1 Speak with Ve'nari
    .skipgossipid 54169
    .timer 18,RP
    .target Ve'nari
step
    .goto 1961,64.96,23.69
    #title |cFFFCDC00Follow the Arrow|r
    *|cRXP_WARN_Wait for the roleplay|r
    .complete 63855,2 --1/1 Suitable location found
step
    #arrowtext Click\n|cRXP_PICK_Animaflow Teleporter|r
    .goto 1961,64.96,23.69
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Animaflow Teleporter|r
    .complete 63855,3 --1/1 Anima signature imprinted
step
    #arrowtext Click\n|cRXP_PICK_Bag|r
    .goto 1961,66.02,23.05
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Bag|r
    .complete 63855,4 --1/1 Ve'nari's bag collected
step
    #arrowtext Click\n|cRXP_PICK_Serpent (Mishi)|r
    .goto 1961,65.65,23.34
    >>Click on the |cRXP_PICK_Serpent (Mishi)|r
    .complete 85028,12 --1/1 Ride Mishi to Ve'nari's Refuge (Optional)
    .timer 40,RP
step
    #completewith next
    #label Ease of Passage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ve'nari|r |cRXP_WARN_after the roleplay|r
    .turnin 63855 >>Turn in Ease of Passage
    .target Ve'nari
    .accept 63895 >>Accept Grab Bag
    .disablecheckbox
step
    #completewith Ease of Passage
    #hidewindow
    .goto 1543,46.63,42.04,10,0
    .goto 1543,46.91,41.7,20 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Ve'nari|r
    #requires Ease of Passage
    .goto 1543,46.91,41.7
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Ve'nari|r
    .turnin 63855 >>Turn in Ease of Passage
    .target Ve'nari
    .accept 63895 >>Accept Grab Bag
step
    #arrowtext Click\n|cRXP_PICK_Transferral Augmentor|r
    .goto 1543,46.91,41.54
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Transferral Augmentor|r
    .complete 63895,1 --1/1 Transferral Augmentor used
step
    #completewith next
    #hidewindow
    #label TransferSuccessful
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Transferral Augmentor|r
    .complete 63895,2 --1/1 Transfer successful
step
    #completewith TransferSuccessful
    .goto 1543,46.9,41.54
    .isOnQuest 63895 --Grab Bag
    .aura -351792 >>|cRXP_WARN_You can cancel the slowfall effect by right-clicking it to drop down quicker.|r
step
    #arrowtext Click\n|cRXP_PICK_Transferral Augmentor|r
    #requires TransferSuccessful
    .goto 1543,46.9,41.54
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Transferral Augmentor|r
    .complete 63895,2 --1/1 Transfer successful
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Projection of Ve'nari|r
    .goto 1543,61.65,59.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Projection of Ve'nari|r
    .turnin 63895,1 >>Turn in Grab Bag
    .target Projection of Ve'nari
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 1543,61.67,59.1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85028,14 --1/1 Thank Lorewalker Cho
    .skipgossipid 125268
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 84,64.19,16.26,-1
    .goto 85,54.35,56.66,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85028 >>Turn in Lorewalking: The Brokers
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Om'rajula|r
    .goto 84,63.85,15.72,-1
    .goto 85,54.35,56.66,-1
    .goto 2339,49.33,31.16,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Om'rajula|r
    .accept 85035 >>Accept Locus-Walker, Telogrus Ranger
    .target Om'rajula
step
    #arrowtext Click\n|cRXP_PICK_Void Portal|r
    .goto 85,53.96,57.10 << Horde
    .goto 84,63.85,15.72 << Alliance
    .goto 2339,49.33,31.16,-1
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Portal|r
    .complete 85035,1 --1/1 Portal taken to Telogrus Rift
step
    #arrowtext Kill\n|cRXP_ENEMY_Shadowguard Voidguards|r and |cRXP_ENEMY_Shadowguard Phaseblades|r
    .goto 971,26.35,27.90
    >>Kill |cRXP_ENEMY_Shadowguard Voidguards|r and |cRXP_ENEMY_Shadowguard Phaseblades|r (2 at a time)
    *|cRXP_WARN_they are not immediately present|r
    .complete 85035,2 --6/6 Ethereal assassins slain
    .mob Shadowguard Phaseblade
    .mob Shadowguard Voidguard
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Locus-Walker|r
    .goto 971,27.49,28.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Locus-Walker|r
    .turnin 85035 >>Turn in Locus-Walker, Telogrus Ranger
    .accept 85036 >>Accept Veni Vidi Ve'nari
    .target Locus-Walker
    .timer 20,RP
step
    #arrowtext Wait for the roleplay
    .goto 971,27.66,27.56
    >>|cRXP_WARN_Wait for the roleplay|r
    .complete 85036,1 --1/1 Witness the Conversation between Ve'nari and Locus-Walker
step
    #arrowtext Click\n|cRXP_PICK_Void Portal|r
    .goto 971,27.93,27.62
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Void Portal|r
    .complete 85036,2 --1/1 Return to Lorewalker Cho
    .timer 70,RP
step
    #label LorewalkingCampaignEnd
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_after the roleplay|r
    .turnin 85036 >>Turn in Veni Vidi Ve'nari
    .target Lorewalker Cho
]])
--The Lich King
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Miscellaneous
#subgroup Lorewalking
#name ac) The Lich King
#displayname The Lich King
#next ad) The Elves of Quel'Thalas

step
    .chromieon
    .goto 84,56.27,17.32 << Alliance
    .goto 85,40.84,80.17 << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Chromie|r
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Stormwind and ask her to return you to the present timeline. << Alliance
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Orgrimmar and ask her to return you to the present timeline. << Horde
    .skipgossipid 51903
    .target Chromie
step
    #completewith LorewalkingCampaignEnd
    +Click on the |cRXP_PICK_Ask a Question|r button in the "Active Items Frame" to talk to the Lorewalker if needed.
    *To stop the campaign, click on |cRXP_PICK_Exit Lorewalking|r in the Lorewalking panel.
    .macro Ask a Question,2056011 >>/cast spell:1242675
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 84,64.24,16.10,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Stormwind|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 85,54.24,56.59,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Orgrimmar|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .accept 85884 >>Accept Lorewalking: The Prince Who Would Be King
    .skipgossipid 124311
    .choose 6403388
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85884,1 --1/1 Talk to Cho
    .skipgossipid 131596
    .skipgossipid 131598
    .target Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Uther Lightbringer|r
    .goto 2418,34.49,84.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Uther Lightbringer|r
    .accept 85862 >>Accept A Prince's Duty
    .target Uther Lightbringer
step
    #completewith next
    #label Train soldiers
    .goto 2418,44.89,81.69,10,0
    .goto 2418,48.21,77.71,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lordaeron Militia|r and defeat them.
    *|cRXP_WARN_Use|r |T236253:0|t[Training Strike] |cRXP_WARN_to deal damage|r.
    *|cRXP_WARN_Use|r |T135906:0|t[Expert Backhand] |cRXP_WARN_to stun the enemy|r.
    .complete 85862,1 --6/6 Train soldiers
step
    #completewith Train soldiers
    #hidewindow
    .goto 2418,48.06,70.12,30 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lordaeron Footsoldiers|r
    #requires Train soldiers
    .goto 2418,48.62,51.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lordaeron Footsoldiers|r and defeat them.
    *|cRXP_WARN_Use|r |T236253:0|t[Training Strike] |cRXP_WARN_to deal damage|r |cRXP_WARN_and|r |T135906:0|t[Expert Backhand] |cRXP_WARN_to stun the enemy|r.
    *|cRXP_WARN_You can talk to multiple at once; shortly after defeating one, talk to them again.|r.
    .complete 85862,1 --6/6 Train soldiers
    .skipgossipid 131459
    .target Lordaeron Militia
step
    #completewith next
    #label Muradin
    .goto 2418,50.4,36.66,15,0
    .goto 2418,53.73,34.9,15,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muradin|r.
    *|cRXP_WARN_Use|r |T135906:0|t[Expert Backhand] |cRXP_WARN_during his cast of|r |T135975:0|t[Storm Bolt] |cRXP_WARN_to interrupt the cast; move out of the void|r.
    .complete 85862,2 --1/1 Spar with Muradin
    .target Muradin
step
    #completewith Muradin
    #hidewindow
    .goto 2418,54.50,29.96,20 >>Follow the Arrow
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Muradin|r
    #requires Muradin
    .goto 2418,54.50,29.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Muradin|r.
    *|cRXP_WARN_Use|r |T135906:0|t[Expert Backhand] |cRXP_WARN_during his cast of|r |T135975:0|t[Storm Bolt] |cRXP_WARN_to interrupt the cast; move out of the void|r.
    .complete 85862,2 --1/1 Spar with Muradin
    .skipgossipid 131489
    .target Muradin Bronzebeard
    .mob Muradin Bronzebeard
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Terenas Menethil II|r
    .goto 2418,55.38,21.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Terenas Menethil II|r
    .turnin 85862 >>Turn in A Prince's Duty
    .target Terenas Menethil II
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 2418,55.38,21.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85884,3 --1/1 Talk to Cho
    .timer 160,RP
    .skipgossipid 131599
    .target Cho
step
    #completewith Coordinates
    +Player coordinates are unavailable, so the arrow cannot be displayed.
step
    >>|cRXP_WARN_Enter the gate of Stratholme and then wait for the Roleplay|r.
    .scenario 15174,1
step
    *|cRXP_WARN_He's going to enter the gates of stratholme shortly|r.
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthas|r
    .scenario 15805,1
    .timer 120,RP
    .skipgossipid 36217
    .target Arthas
step
    >>|cRXP_WARN_Follow |cRXP_FRIENDLY_Arthas|r and wait for the Roleplay|r.
    .complete 85884,4 --1/1 Witness the Culling of Stratholme
    .target Arthas
step
    #completewith next
    #label Arthas
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthas|r
    .scenario 15807,1
    .target Arthas
step
    #completewith Arthas
    .gossipoption 134404 >>Talk to |cRXP_FRIENDLY_Cho|r
step
    #requires Arthas
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Arthas|r
    .scenario 15807,1
    .timer 60,RP
    .skipgossipid 36273
    .target Arthas
step
    >>Follow |cRXP_FRIENDLY_Arthas|r and kill |cRXP_ENEMY_Mal'Ganis|r.
    *|cRXP_WARN_Wait for roleplay after|r.
    .complete 85884,5 --Confront Malganis
    .mob Mal'Ganis
step
    #label Coordinates
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85884,6 --1/1 Talk to Cho
    .skipgossipid 131600
    .target Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Orik Trueheart|r
    .goto 115,87.17,57.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orik Trueheart|r
    .accept 12291 >>Accept The Forgotten Tale
    .target Orik Trueheart
step
    #loop
    .goto 115,86.89,64.68,40,0
    .goto 115,86.84,67.57,40,0
    .goto 115,85.44,69.95,40,0
    .goto 115,84.08,66.37,40,0
    .goto 115,82.42,66.74,40,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Forgotten Rifleman|r  |cRXP_FRIENDLY_Forgotten Footman|r |cRXP_FRIENDLY_Forgotten Knight|r |cRXP_FRIENDLY_Forgotten Peasant|r
    .complete 12291,1 --1/1 Forgotten Peasant Questioned
    .mob +Forgotten Peasant
    .complete 12291,2 --1/1 Forgotten Rifleman Questioned
    .mob +Forgotten Rifleman
    .complete 12291,3 --1/1 Forgotten Knight Questioned
    .mob +Forgotten Knight
    .complete 12291,4 --1/1 Forgotten Footman Questioned
    .mob +Forgotten Footman
    .skipgossipid 37796
    .skipgossipid 37797
    .skipgossipid 35881
    .skipgossipid 34970
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Orik Trueheart|r
    .goto 115,87.17,57.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orik Trueheart|r
    .turnin 12291 >>Turn in The Forgotten Tale
    .accept 12301 >>Accept The Truth Shall Set Us Free
    .target Orik Trueheart
step
    #completewith next
    #label Orik's
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12301,1
step
    #arrowtext Use [Orik's Crystalline Orb]
    #completewith Orik's
    .goto 115,86.85,65.99
    .cast 48866 >>Use |T134334:0|t[Orik's Crystalline Orb]
    .timer 113,RP
    .use 37577
step
    #arrowtext Wait for the roleplay
    #requires Orik's
    .goto 115,86.97,65.58
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12301,1
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Orik Trueheart|r
    .goto 115,87.17,57.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Orik Trueheart|r
    .turnin 12301 >>Turn in The Truth Shall Set Us Free
    .accept 12305 >>Accept Parting Thoughts
    .target Orik Trueheart
step
    #completewith next
    #label Parting Thoughts
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zelig the Visionary|r
    .turnin 12305 >>Turn in Parting Thoughts
    .accept 12478 >>Accept Frostmourne Cavern
    .disablecheckbox
    .target Zelig the Visionary
step
    #arrowtext Enter the Tower
    #completewith Parting Thoughts
    .goto 115,78.99,47.41,10 >>Enter the Tower
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Zelig the Visionary|r
    #requires Parting Thoughts
    .goto 115,79.15,47.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zelig the Visionary|r
    .turnin 12305 >>Turn in Parting Thoughts
    .accept 12478 >>Accept Frostmourne Cavern
    .target Zelig the Visionary
step
    #completewith next
    #hidewindow
    #label Parting Thoughts2
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #arrowtext Leave the Tower
    #completewith Parting Thoughts2
    .goto 115,78.95,47.44,4 >>Leave the Tower
step
    #requires Parting Thoughts2
    #completewith next
    #hidewindow
    #label Parting Thoughts3
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #arrowtext Enter the Frostmourne Cavern
    #requires Parting Thoughts2
    #completewith Parting Thoughts3
    .goto 115,74.69,24.28,40,0
    .goto 115,74.7,22.98,10 >>Enter the Frostmourne Cavern
step
    #requires Parting Thoughts3
    #completewith next
    #hidewindow
    #label Parting Thoughts4
    .goto 115,75.06,20.26
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #requires Parting Thoughts3
    #completewith Parting Thoughts4
    .cast 49817 >>Use |T134334:0|t[Zelig's Scrying Orb]
    .timer 122,RP
    .use 37933
step
    #requires Parting Thoughts4
    #hidewindow
    #completewith next
    #label Parting Thoughts5
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #arrowtext Leave the Frostmourne Cavern
    #requires Parting Thoughts4
    #completewith Parting Thoughts5
    .goto 115,74.36,23.84,20 >>Leave the Frostmourne Cavern
step
    #requires Parting Thoughts5
    #completewith next
    #label Parting Thoughts6
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #arrowtext Go to the Questgiver
    #requires Parting Thoughts5
    #completewith Parting Thoughts6
    .goto 115,78.96,47.44,20 >>Go to the Questgiver
step
    #arrowtext Wait for the roleplay
    #requires Parting Thoughts6
    .goto 115,79.15,47.16
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 12478,1 --1/1 Secrets of the Past Revealed
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Zelig the Visionary|r
    .goto 115,79.15,47.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Zelig the Visionary|r
    .turnin 12478 >>Turn in Frostmourne Cavern
    .target Zelig the Visionary
    .complete 85884,8 --1/1 Learn about the Doomed Expedition
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1 <<Horde
    .goto 84,64.19,16.26,-1 <<Alliance
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85884 >>Turn in Lorewalking: The Prince Who Would Be King
    .accept 85885 >>Accept Lorewalking: No King Rules Forever
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 85,54.35,56.66,-1 <<Horde
    .goto 84,64.19,16.26,-1 <<Alliance
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85885,1 --1/1 Talk to Cho
    .timer 24,RP
    .skipgossipid 131573
step
    #arrowtext Wait for the roleplay
    .goto 85,54.35,56.66,-1 <<Horde
    .goto 84,64.19,16.26,-1 <<Alliance
    .goto 2339,49.6,31.63,-1
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 85885,2 --1/1 Learn about the Lich King's betrayal
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 85,54.35,56.66,-1 <<Horde
    .goto 84,64.19,16.26,-1 <<Alliance
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85885,3 --1/1 Talk to Cho
    .skipgossipid 132759
step
    #completewith next
    #label Memory of Muradin
    >>Enter Icecrown
    .accept 85875 >>Accept Ascent of the Lich King
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    #completewith Memory of Muradin
    .goto 85,54.35,56.66,-1 <<Horde
    .goto 84,64.19,16.26,-1 <<Alliance
    .goto 2339,49.6,31.63,-1
    .gossipoption 134404 >>Talk to |cRXP_FRIENDLY_Cho|r
step
    #requires Memory of Muradin
    .accept 85875 >>Accept Ascent of the Lich King
step
    #arrowtext Kill\n|cRXP_ENEMY_Memory of Muradin|r
    .goto 118,51.54,79.93
    >>Kill |cRXP_ENEMY_Memory of Muradin|r
    .complete 85875,1 --1/1 Banish the Memory of Muradin
    .mob Memory of Muradin
step
    #arrowtext Kill\n|cRXP_ENEMY_Memory of Muradin|r
    .goto 118,51.52,79.86
    >>Kill |cRXP_ENEMY_Memory of Muradin|r
    .complete 85875,1 --1/1 Banish the Memory of Muradin
    .mob Memory of Muradin
step
    #arrowtext Kill\n|cRXP_ENEMY_Memory of Jaina|r
    .goto 118,51.77,80.69
    >>Kill |cRXP_ENEMY_Memory of Jaina|r
    .complete 85875,2 --1/1 Banish the Memory of Jaina
    .mob Memory of Jaina
step
    #arrowtext Kill\n|cRXP_ENEMY_Memory of Uther|r
    .goto 118,52.01,81.44
    >>Kill |cRXP_ENEMY_Memory of Uther|r
    .complete 85875,3 --1/1 Banish the Memory of Uther
    .mob Memory of Uther
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Memory of Terenas|r
    .isOnQuest 85875 --Ascent of the Lich King
    .goto 118,52.34,82.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Memory of Terenas|r
    .turnin 85875,1 >>Turn in Ascent of the Lich King
    .target Memory of Terenas
step
    .complete 85885,4 --1/1 Witness the ascent of the Lich King
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 118,52.34,82.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85885,5 --1/1 Talk to Cho
    .skipgossipid 131603
    .target Cho
step
    *|cRXP_WARN_Walk forward a bit to spawn |cRXP_FRIENDLY_Lady Jaina Proudmoore|r behind you|r
    .gossipoption 37487 >>Talk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
    .timer 230,RP
    .target Lady Jaina Proudmoore
step
    >>Kill |cRXP_ENEMY_Waves|r and |cRXP_ENEMY_Falric|r
    .scenario 1057,1
    .mob Ghostly Priest
    .mob Spectral Footman
    .mob Tortured Rifleman
    .mob Phantom Mage
    .mob Falric
step
    >>Kill |cRXP_ENEMY_Waves|r and |cRXP_ENEMY_Marwyn|r
    .scenario 1057,2
    .mob Ghostly Priest
    .mob Spectral Footman
    .mob Tortured Rifleman
    .mob Phantom Mage
    .mob Marwyn
step
    *|cRXP_WARN_Walk through the hallway. You will encounter the |cRXP_ENEMY_Lich King|r and |cRXP_FRIENDLY_Jaina|r.
    *Fight the |cRXP_ENEMY_Lich King|r until |cRXP_FRIENDLY_Jaina|r freezes him, then follow her.|r
    .gossipoption 37662 >>Talk to |cRXP_FRIENDLY_Lady Jaina Proudmoore|r
    .timer 330,RP
    .target Lady Jaina Proudmoore
step
    >>Defeat the waves of enemies summoned by the |cRXP_ENEMY_Lich King|r.
    *Defeating the waves of enemies allows |cRXP_FRIENDLY_Jaina|r to progress
    *|cRXP_WARN_Don't let the Lich King reach |cRXP_FRIENDLY_Jaina|r|r.
    .complete 85885,6 --1/1 Help Jaina investigate the Halls of Reflection
    .mob Raging Ghoul
    .mob Risen Witch Doctor
    .mob Lumbering Abomination
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .complete 85885,7 --1/1 Talk to Cho
    .skipgossipid 131606
    .target Cho
step
    .accept 85878,1 >>Accept O' Thanagor
step
    >>Spam |T132291:0|t[Defile] ideally around as many npcs.
    *Use |T237532:0|t[Pain and Suffering] on cooldown.
    *Use |T135833:0|t[Remorseless Winter] on cooldown.
    .complete 85878,1 --1/1 Complete "O'Thanagor"
step
    #label LorewalkingCampaignEnd
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85878 >>Turn in O' Thanagor
    .turnin 85885 >>Turn in Lorewalking: No King Rules Forever
    .target Lorewalker Cho
]])
--The Elves of Quel'Thalas
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Miscellaneous
#subgroup Lorewalking
#name ad) The Elves of Quel'Thalas
#displayname The Elves of Quel'Thalas
#next ae) The Loa

step
    .chromieon
    .goto 84,56.27,17.32 << Alliance
    .goto 85,40.84,80.17 << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Chromie|r
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Stormwind and ask her to return you to the present timeline. << Alliance
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Orgrimmar and ask her to return you to the present timeline. << Horde
    .skipgossipid 51903
    .target Chromie
step
    #completewith LorewalkingCampaignEnd
    +Click on the |cRXP_PICK_Ask a Question|r button in the "Active Items Frame" to talk to the Lorewalker if needed.
    *To stop the campaign, click on |cRXP_PICK_Exit Lorewalking|r in the Lorewalking panel.
    .macro Ask a Question,2056011 >>/cast spell:1242675
step << Alliance
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 84,64.24,16.10,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Stormwind|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .isOnQuest 90705 --Lorewalking
    .goto 85,54.24,56.59,-1
    .goto 2339,49.62,31.52,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r |cRXP_WARN_in Dornogal or Orgrimmar|r.
    .accept 90705 >>Accept Lorewalking
    .turnin 90705 >>Turn in Lorewalking
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .accept 85252 >>Accept Lorewalking: Children of the Blood
    .skipgossipid 124311
    .choose 6403386
    .target Lorewalker Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 85,54.35,56.66,-1
    .goto 2339,49.6,31.63,-1
    .goto 84,64.19,16.26,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85252,1 --1/1 Talk to Cho
    .timer 8,RP
    .skipgossipid 131412
    .target Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
    .goto 95,46.31,31.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r
    .accept 53882 >>Accept Writing on the Wall
    .target Lor'themar Theron
step
    #completewith next
    #label First Flame
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lamp|r
    .complete 53882,1 --1/1 Light the First Flame
step
    #arrowtext Click\n|cRXP_PICK_Dragon|r
    #completewith First Flame
    .goto 95,46.41,32.86
    >>Click on the |cRXP_PICK_Dragon|r
    .complete 85252,3 --1/1 Ride Mishi (Optional)
    .mob Mishi
    .timer 27,RP
step
    #arrowtext Click\n|cRXP_PICK_Lamp|r
    #requires First Flame
    .goto 95,47.73,84.01
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Lamp|r
    .complete 53882,1 --1/1 Light the First Flame
step
    #include RestedXP Collectables\a) Blood Elf Heritage Armor@Writing on the Wall-Writing on the Wall2
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lor'themar Theron|r
    .goto 95,37.47,64.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r |cRXP_WARN_next to you|r
    .turnin 53735 >>Turn in The First to Fall
    .target Lor'themar Theron
    .accept 53737 >>Accept The Day Hope Died
step
    #completewith next
    #label Sylvanas' fall
    >>Use your [ExtraActionButton] on the illuminated spot.
    .complete 53737,1 --1/1 Light shed at Sylvanas' fall
step
    #arrowtext Click\n|cRXP_PICK_Dragon|r
    #completewith Sylvanas' fall
    .goto 95,37.49,64.54
    >>Click on the |cRXP_PICK_Dragon|r
    .complete 85252,5 --1/1 Ride Mishi (Optional)
    .timer 45,RP
step
    #arrowtext Use [ExtraActionButton]
    #requires Sylvanas' fall
    .goto 94,51.21,69.28
    >>Use your [ExtraActionButton] on the illuminated spot.
    .complete 53737,1 --1/1 Light shed at Sylvanas' fall
step
    #include RestedXP Collectables\a) Blood Elf Heritage Armor@TheDayHopeDiedStart-TheDayHopeDiedEnd
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lor'themar Theron|r |cRXP_WARN_next to you|r.
    .turnin 53737 >>Turn in The Day Hope Died
    .complete 85252,6 --1/1 Accompany Lor'themar
    .target Lor'themar Theron
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r |cRXP_WARN_next to you|r.
    .complete 85252,7 --1/1 Talk to Cho
    .skipgossipid 136429
    .target Cho
step
    #include RestedXP Collectables\a) Blood Elf Heritage Armor@SunwellStart1-SunwellEnd1
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85252 >>Turn in Lorewalking: Children of the Blood
    .target Lorewalker Cho
    .accept 85254 >>Accept Lorewalking: Children of the Void
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Cho|r
    .goto 85,54.35,56.66,-1
    .goto 84,64.19,16.26,-1
    .goto 2339,49.6,31.63,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r
    .complete 85254,1 --1/1 Talk to Cho
    .timer 8,RP
    .skipgossipid 131413
    .target Cho
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
    .goto 110,58.12,19.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
    .accept 49354 >>Accept Remember the Sunwell
    .complete 85254,2 --1/1 Accept "Remember the Sunwell" from Lady Liadrin
    .target Lady Liadrin
step
    #include RestedXP Collectables\a) Nightborne Unlock@RemembertheSunwellStart-RemembertheSunwellEnd
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lady Liadrin|r
    .goto 110,58.47,19.11
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lady Liadrin|r
    .turnin 49354 >>Turn in Remember the Sunwell
    .target Lady Liadrin
    .complete 85254,3 --1/1 Learn about Alleria's incident at the Sunwell
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Cho|r |cRXP_WARN_next to you|r.
    .complete 49787,1 --1/1 Travel to the Ghostlands
    .timer 8,RP
    .skipgossipid 136404
    .target Cho
step
    #include RestedXP Collectables\a) Void Elf Unlock@SanctumoftheMoonStart-SanctumoftheMoonEnd
step
    #arrowtext Click\n|cRXP_PICK_Dragon|r
    .isOnQuest 49787 --The Ghostlands
    .goto 95,46.5,56.74
    .vehicle >>Click on the |cRXP_PICK_Dragon|r
    .timer 35,RP
step
    #arrowtext Jump
    .goto 95,79.15,16.5,7,0
    .goto 95,79.65,17.52
    .isOnQuest 49787 --The Ghostlands
    .cast 258931 >>Jump and click on the |cRXP_PICK_Teleportation Console|r midair.
step
    #include RestedXP Collectables\a) Void Elf Unlock@SanctumoftheMoonStart2-SanctumoftheMoonEnd2
step
    #completewith next
    #label Telogrus Rift1
    .goto 84,52.05,13.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
    .turnin 48962 >>Turn in Telogrus Rift
    .target Lorewalker Cho
step
    #completewith Telogrus Rift1
    .cast 1242675 >>Use the macro in the "Active Items Frame" to talk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .macro Open Lorewalking,2056011>>/use ask a question
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    #requires Telogrus Rift1
    .goto 84,52.05,13.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r.
    .turnin 48962 >>Turn in Telogrus Rift
    .complete 85254,5 --1/1 Complete the Void Elf Quests
    .target Lorewalker Cho
step
    #label LorewalkingCampaignEnd
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lorewalker Cho|r
    .goto 972,27.94,24.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lorewalker Cho|r
    .turnin 85254 >>Turn in Lorewalking: Children of the Void
    .target Lorewalker Cho
]])
--The Loa
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Miscellaneous
#subgroup Lorewalking
#name ae) The Loa
#displayname The Loa
#next a) Xal'atath

step
    .chromieon
    .goto 84,56.27,17.32 << Alliance
    .goto 85,40.84,80.17 << Horde
    #arrowtext Talk to\n|cRXP_FRIENDLY_Chromie|r
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Stormwind and ask her to return you to the present timeline. << Alliance
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Chromie|r in Orgrimmar and ask her to return you to the present timeline. << Horde
    .skipgossipid 51903
    .target Chromie
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    .goto 84,64.30,16.20,-1 << Alliance
    .goto 85,54.30,56.60,-1 << Horde
    .goto 2339,49.70,31.50,-1
    .goto 2393,58.70,70.80,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r.
    .accept 92826 >>Accept Lorewalking: The Loa of Kings
    .skipgossipid 124311
    .choose 5420
    .choose 5419
    .timer 60,RP
    .target Li Li Stormstout::253727
step
    #completewith LorewalkingCampaignEnd
    +Click on the |cRXP_PICK_Ask a Question|r button in the "Active Items Frame" to talk to the Lorewalker if needed.
    *To stop the campaign, click on |cRXP_PICK_Exit Lorewalking|r in the Lorewalking panel.
    .macro Ask a Question,2056011 >>/cast spell:1242675
step
    #arrowtext Wait for the roleplay
    .goto 84,64.30,16.20,-1 << Alliance
    .goto 85,54.30,56.60,-1 << Horde
    .goto 2339,49.70,31.50,-1
    .goto 2393,58.70,70.80,-1
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 92826,1 --1/1 Listen to Li Li to learn about the loa
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    .goto 84,64.30,16.20,-1 << Alliance
    .goto 85,54.30,56.60,-1 << Horde
    .goto 2339,49.70,31.50,-1
    .goto 2393,58.70,70.80,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r.
    .complete 92826,2 --1/1 Talk to Li Li to learn about Rezan and King Rastakhan
    .skipgossipid 136652
    .target Li Li Stormstout::253727
step
    #completewith endzul
    +|cRXP_WARN_You can't skyride here|r
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_King Rastakhan|r
    .goto 1165,38.93,27.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan::129491|r at the start of the memory.
    .accept 49965 >>Accept The Warpack
    .target King Rastakhan::129491
step
    #completewith next
    #label Ride with the Warpack
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 49965,1 --1/1 Ride with the Warpack
    .target Wardruid Loti::134132
step
    #completewith Ride with the Warpack
    #arrowtext Click\n|cRXP_FRIENDLY_Wardruid Loti|r
    .goto 1165,38.83,27.04
    .vehicle >>Click on |cRXP_FRIENDLY_Wardruid Loti::134132|r
    .timer 80,RP
    .target Wardruid Loti::134132
step
    #requires Ride with the Warpack
    .goto 1165,38.83,27.04
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 49965,1 --1/1 Ride with the Warpack
    .target Wardruid Loti::134132
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Gonk|r
    .goto 862,49.27,44.36
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Gonk::129740|r.
    .turnin 49965 >>Turn in The Warpack
    .accept 49422 >>Accept Heretics
    .target Gonk::129740
step
    .goto 862/1642,1534.300,-1120.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Raptari Druid::131682|r.
    .accept 49424 >>Accept The Full Prophecy
    .target Raptari Druid::131682
step
    #arrowtext Kill\n|cRXP_ENEMY_Zul's followers|r
    #completewith LoaWordsRead
    >>Kill |cRXP_ENEMY_Zul's followers|r and destroy |cRXP_PICK_Skykiller Ballistae|r around the temple to fill the progress bar.
    .complete 49422,1 --Ruin wrought. (100%)
    .mob Skykiller Ballista::129540
    .mob Kao-Tien Battlemaster::129515
    .mob Disciple of Zul::129504
step
    #arrowtext Click\n|cRXP_PICK_Word of Zul III|r
    .goto 862,48.81,42.75
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Word of Zul|r on the temple wall.
    .complete 49424,3 --1/1 The Word of Zul III read
step
    #arrowtext Click\n|cRXP_PICK_Word of Zul II|r
    .goto 862,49.02,40.59
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Word of Zul II|r inside a house.
    .complete 49424,2 --1/1 The Word of Zul II read
step
    #arrowtext Click\n|cRXP_PICK_Word of Zul|r
    #label LoaWordsRead
    .goto 862,48.93,39.43
    >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Word of Zul|r.
    .complete 49424,1 --1/1 The Word of Zul I read
step
    #arrowtext Kill\n|cRXP_ENEMY_Zul's followers|r
    #loop
    .goto 862,49.7,38.47,40,0
    .goto 862,49.94,39.51,40,0
    .goto 862,49.84,40.79,40,0
    .goto 862,50.04,43.26,40,0
    .goto 862,49.08,42.76,40,0
    >>Kill |cRXP_ENEMY_Zul's followers|r and destroy |cRXP_PICK_Skykiller Ballistae|r.
    .complete 49422,1 --Ruin wrought. (100%)
    .mob Skykiller Ballista::129540
    .mob Kao-Tien Battlemaster::129515
    .mob Disciple of Zul::129504
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Wardruid Loti|r
    .goto 862,49.65,37.98
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Wardruid Loti::134132|r and |cRXP_FRIENDLY_Hexlord Raal::127222|r at the exit.
    .turnin 49424 >>Turn in The Full Prophecy
    .turnin 49422 >>Turn in Heretics
    .accept 49425 >>Accept City of Gold
    .target Wardruid Loti::134132s
    .target Hexlord Raal::127222
step
    #arrowtext Click\n|cRXP_FRIENDLY_Ata the Winglord|r
    .goto 862,49.65,37.89
    >>|TInterface/cursor/crosshair/interact.blp:20|tMount |cRXP_FRIENDLY_Ata the Winglord::127417|r.
    .complete 49425,1 --1/1 Ride Ata the Winglord
    .target Ata the Winglord::127417
step
    .goto 862,43.73,39.43
    >>Use the vehicle abilities to attack |cRXP_ENEMY_Zul's forces|r along the road.
    .complete 49425,2 --75/75 Forces of Zul slain
    .mob Disciple of Zul::129504
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Rezan|r
    .goto 862,43.73,39.43s
    *|cRXP_WARN_Do not leave vehicle|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Rezan::129492|r.
    .turnin 49425 >>Turn in City of Gold
    .accept 49426 >>Accept The King's Gambit
    .target Rezan::129492
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_King Rastakhan|r
    .goto 862,42.18,39.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan::129757|r
    .complete 49426,1 --1/1 March on Atal'Dazar
    .complete 49426,2 --1/1 Speak with King Rastakhan
    .skipgossipid 48457
    .target King Rastakhan::129757
step
    .goto 862,42.71,37.61
    >>Help |cRXP_FRIENDLY_King Rastakhan::129757|r reach safety.
    .complete 49426,3 --1/1 Get Rastakhan to safety
    .target King Rastakhan::129757
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_King Rastakhan|r
    .goto 862,42.71,37.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_King Rastakhan::129757|r after escaping.
    .turnin 49426 >>Turn in The King's Gambit
    .target King Rastakhan::129757
step
    #label endzul
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r.
    .turnin 92826 >>Turn in Lorewalking: The Loa of Kings
    .accept 92829 >>Accept Lorewalking: Death of the Drakkari Loa
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Witch Doctor Khufu|r
    .goto 121,59.51,58.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Khufu::28479|r.
    .accept 12628 >>Accept To Speak With Har'koa
    .target Witch Doctor Khufu::28479
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Har'koa|r
    .goto 121,63.70,70.40
    *|cRXP_WARN_You can skyride here|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Har'koa::28401|r at her altar.
    .turnin 12628 >>Turn in To Speak With Har'koa
    .accept 12632 >>Accept But First My Offspring
    .target Har'koa::28401
step
    #arrowtext Kill and Click\n|cRXP_ENEMY_Cursed Offspring of Har'koa|r
    #loop
    .goto 121,62.9,71.74,30,0
    .goto 121,62.67,74.68,30,0
    .goto 121,61.46,72.92,30,0
    .goto 121,61.75,70.4,30,0
    .goto 121,61.55,68.88,30,0
    .goto 121,60.22,67.99,30,0
    .goto 121,61.56,66.45,30,0
    .goto 121,63.99,67.18,30,0
    .goto 121,65.7,68.49,30,0
    .goto 121,64.39,69.74,30,0
    .goto 121,63.81,63.62,30,0
    .goto 121,66.85,70.08,30,0
    .goto 121,64.26,74.81,30,0
    >>Kill |cRXP_ENEMY_Cursed Offspring of Har'koa::28404|r around the altar.
    *Click on their corpses to revive them.
    .complete 12632,1 --7/7 Cursed Offspring of Har'koa resurrected
    .mob Cursed Offspring of Har'koa::28404
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Har'koa|r
    .goto 121,63.70,70.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Har'koa::28401|r.
    .turnin 12632 >>Turn in But First My Offspring
    .accept 12642 >>Accept Spirit of Rhunok
    .target Har'koa::28401
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Spirit of Rhunok|r
    .goto 121,53.40,39.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Spirit of Rhunok::28561|r at the Altar of Rhunok.
    .turnin 12642 >>Turn in Spirit of Rhunok
    .accept 12646 >>Accept My Prophet, My Enemy
    .target Spirit of Rhunok::28561
step
    #arrowtext Kill and Loot\n|cRXP_ENEMY_Prophet of Rhunok|r
    .goto 121,54.10,47.50
    >>Kill the |cRXP_ENEMY_Prophet of Rhunok::28442|r. Loot him for |TInterface/Icons/INV_Potion_31:0|t[|cRXP_LOOT_Arctic Bear God Mojo|r].
    .complete 12646,1 --1/1 Arctic Bear God Mojo
    .mob Prophet of Rhunok::28442
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Spirit of Rhunok|r
    .goto 121,53.40,39.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Spirit of Rhunok::28561|r.
    .turnin 12646 >>Turn in My Prophet, My Enemy
    .accept 12647 >>Accept An End to the Suffering
    .target Spirit of Rhunok::28561
step
    #arrowtext Kill and Loot\n|cRXP_ENEMY_Rhunok's Tormentor|r
    .goto 121,53.40,35.80
    >>Kill |cRXP_ENEMY_Rhunok's Tormentor::28575|r inside the altar building. Loot him for |TInterface/Icons/INV_Enchant_DustDream:0|t[|cRXP_LOOT_Tormentor's Incense|r].
    .complete 12647,1 --1/1 Tormentor's Incense
    .mob Rhunok's Tormentor::28575
step
    .goto 121,53.50,34.40
    >>Click on the |cRXP_PICK_Tormentor's Incense|r macro in the "Active Items Frame", then kill |cRXP_ENEMY_Rhunok::28416|r.
    *If you lose Rhunok's blessing, return to the |cRXP_FRIENDLY_Spirit of Rhunok::28561|r to receive it again.
    .complete 12647,2 --1/1 Rhunok slain
    .macro Tormentor's Incense,134400 >>/targetexact Rhunok\n/use item:38696
    .mob Rhunok::28416
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Spirit of Rhunok|r
    .goto 121,53.40,39.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to the |cRXP_FRIENDLY_Spirit of Rhunok::28561|r.
    .turnin 12647 >>Turn in An End to the Suffering
    .timer 10,RP
    .target Spirit of Rhunok::28561
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Har'koa|r
    .goto 121,60.25,57.74
    >>Wait for |cRXP_FRIENDLY_Li Li Stormstout::253727|r for the transition. Talk to |cRXP_FRIENDLY_Har'koa::28401|r there.
    .accept 12721 >>Accept Rampage
    .target Har'koa::28401
step
    .isQuestNotComplete 12721 --Rampage
    .isOnQuest 12721 --Rampage
    .goto 121,78.18,25.62
    .cast 52815 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
step
    .isQuestNotComplete 12721 --Rampage
    .isOnQuest 12721 --Rampage
    .goto 121,78.16,24.23
    .cast 52815 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
step
    .isQuestNotComplete 12721 --Rampage
    .isOnQuest 12721 --Rampage
    .goto 121,79.08,24.2
    .cast 52815 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
step
    .isQuestNotComplete 12721 --Rampage
    .isOnQuest 12721 --Rampage
    .goto 121,79.11,25.54
    .cast 52815 >>|TInterface/cursor/crosshair/interact.blp:20|tClick on the |cRXP_PICK_Pylon|r.
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Witch Doctor Khufu|r
    .goto 121,59.50,58.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Witch Doctor Khufu::28479|r in Zim'Torga.
    .complete 12721,1 --1/1 Akali unfettered from his chains
    .turnin 12721 >>Turn in Rampage
    .accept 12729 >>Accept The Gods Have Spoken
    .target Witch Doctor Khufu::28479
step
    #arrowtext Kill and Loot\n|cRXP_ENEMY_Guardian of Zim'Rhuk|r
    #loop
    .goto 121,59.26,48.9,40,0
    .goto 121,59.4,46.36,40,0
    .goto 121,60.85,44.2,40,0
    .goto 121,61.95,41.7,40,0
    .goto 121,59.56,41.49,40,0
    .goto 121,58.91,39.37,40,0
    .goto 121,58.13,44.35,40,0
    >>Kill |cRXP_ENEMY_Guardian of Zim'Rhuk::28597|r. Loot them for |TInterface/Icons/INV_Ore_Arcanite_02:0|t[|cRXP_LOOT_Unblemished Heart of the Guardian|r].
    *|cRXP_WARN_The dropchance is bad|r.
    .complete 12729,1 --1/1 Unblemished Heart of the Guardian
    .mob Guardian of Zim'Rhuk::28597
step
    #arrowtext Kill and Loot\n|cRXP_ENEMY_Altar Warden|r
    #loop
    .goto 121,68.63,56.11,30,0
    .goto 121,70.06,54.6,30,0
    .goto 121,72.46,55.6,30,0
    .goto 121,72.74,59.47,30,0
    .goto 121,70.74,62.26,30,0
    .goto 121,68.49,61.54,30,0
    >>Kill |cRXP_ENEMY_Altar Warden::28784|r. Loot them for |TInterface/Icons/Spell_Frost_Stun:0|t[|cRXP_LOOT_Gusty Essence of the Warden|r].
    *|cRXP_WARN_The dropchance is bad|r.
    .complete 12729,2 --1/1 Gusty Essence of the Warden
    .mob Altar Warden::28784
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Har'koa|r
    .goto 121,60.26,57.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Har'koa::28401|r in Zim'Torga.
    .turnin 12729 >>Turn in The Gods Have Spoken
    .accept 12730 >>Accept Convocation at Zol'Heb
    .target Har'koa::28401
step
    #arrowtext Kill\n|cRXP_ENEMY_Prophet of Akali|r
    .goto 121,77.60,36.60
    >>Use the |cRXP_PICK_Prophet of Akali Convocation|r inside the summoning circle.
    *Kill the |cRXP_ENEMY_Prophet of Akali::29028|r.
    .complete 12730,1 --1/1 Prophet of Akali summoned and defeated
    .use 39566
    .mob Prophet of Akali::29028
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Har'koa|r
    .goto 121,60.27,57.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Har'koa::28401|r in Zim'Torga.
    .turnin 12730 >>Turn in Convocation at Zol'Heb
    .target Har'koa::28401
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r
    .turnin 92829 >>Turn in Lorewalking: Death of the Drakkari Loa
    .accept 92831 >>Accept Lorewalking: The Blood Loa
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 92831,1 --1/1 Travel with Li Li to Atal'Hakkar
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    .goto 51,69.54,55.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r about Hakkar.
    .complete 92831,2 --1/1 Ask Li Li about Hakkar
    .timer 60,RP
    .skipgossipid 137513
    .target Li Li Stormstout::253727
step
    #arrowtext Wait for the roleplay
    >>|cRXP_WARN_Wait for the Roleplay|r.
    .complete 92831,3 --1/1 Listen to Li Li to learn about Hakkar
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lord Itharius|r
    .goto 51,69.48,54.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Itharius::46071|r.
    .accept 27704 >>Accept Legends of the Sunken Temple
    .target Lord Itharius::46071
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Mishi|r
    .goto 51,69.67,51.87,30,0
    .goto 51,69.14,53.65,30,0
    .goto 51,69.71,53.43,30,0
    .goto 51,70.1,50.83,30,0
    .goto 51,71.17,46.67,30,0
    .goto 51,74.85,45.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Mishi::260344|r and swim through the flooded passage, then follow the corridor to the Hall of Masks.
    *|cRXP_WARN_These quests take place outside the Sunken Temple instance portal.|r
    .complete 27704,1 --1/1 Hall of Masks found
    .skipgossipid 138730
    .target Mishi::260344
step
    .goto 51,74.85,45.61
    >>Complete the quest through the quest tracker and accept the follow-up.
    .turnin 27704 >>Turn in Legends of the Sunken Temple
    .accept 27705 >>Accept Step One: The Priestess
step
    #arrowtext Kill\n|cRXP_ENEMY_Priestess Udum'bra|r
    .goto 51,75.11,47.08,30,0
    .goto 51,77.59,48.47,30,0
    .goto 51,76.08,50.15,30,0
    .goto 51,75.5,51.81,30,0
    .goto 51,75.44,49.66,30,0
    .goto 51,74.78,49.28
    >>Kill |cRXP_ENEMY_Priestess Udum'bra::46424|r at the back of the chamber.
    .complete 27705,1 --1/1 Priestess Udum'bra slain
    -- .skipgossipid 138861
    .mob Priestess Udum'bra::46424
    .target Mishi::260348
step
    .goto 51,74.78,49.28
    >>Complete the quest through the quest tracker and accept the follow-up.
    .turnin 27705 >>Turn in Step One: The Priestess
    .accept 27768 >>Accept Step Two: The Bloodletter
step
    .goto 51,72.94,47.08,30,0
    .goto 51,77.21,47.79,30,0
    .goto 51,77.56,46.07
    >>Kill |cRXP_ENEMY_Gomora the Bloodletter::46623|r.
    *|cRXP_WARN_If you die before reaching him take rez sickness|r
    .complete 27768,1 --1/1 Gomora the Bloodletter slain
    .mob Gomora the Bloodletter::46623
    .target Mishi::260348
step
    .goto 51,77.56,46.07
    >>Complete the quest through the quest tracker and accept the follow-up.
    .turnin 27768 >>Turn in Step Two: The Bloodletter
    .accept 27773 >>Accept Step Three: Prophet
step
    #arrowtext Kill\n|cRXP_ENEMY_Jammal'an the Prophet|r
    .goto 51,77.34,48.7,30,0
    .goto 51,76.84,49.64,30,0
    .goto 51,78.99,50.49,30,0
    .goto 51,79.98,43.84
    >>Kill |cRXP_ENEMY_Jammal'an the Prophet::46656|r below.
    .complete 27773,1 --1/1 Jammal'an the Prophet defeated
    .mob Jammal'an the Prophet::46656
    .target Mishi::260349
step
    .goto 51,79.98,43.84
    >>Complete the quest through the quest tracker and accept the follow-up to return to |cRXP_FRIENDLY_Lord Itharius::46071|r.
    .turnin 27773 >>Turn in Step Three: Prophet
    .accept 27914 >>Accept Blessing of the Green Dragonflight
    .target Lord Itharius::46071
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Lord Itharius|r
    .goto 51,69.47,54.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Lord Itharius::46071|r.
    .turnin 27914 >>Turn in Blessing of the Green Dragonflight
    .target Lord Itharius::46071
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    *|cRXP_WARN_The arrow can't be displayed here|r
    >>Kill |cRXP_ENEMY_Hakkar the Soulflayer|r after the roleplay
    .complete 92831,5 --1/1 Hakkar the Soulflayer slain
    .mob Hakkar the Soulflayer::254242
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r
    .turnin 92831 >>Turn in Lorewalking: The Blood Loa
    .accept 92832 >>Accept Lorewalking: The Hash'ey
    .target Li Li Stormstout::253727
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Rokhan|r
    .goto 463,60.07,62.38
    >>Wait for the rolplay then Talk to |cRXP_FRIENDLY_Rokhan::223215|r at the trial site.
    .accept 77900 >>Accept The Loa Trials
    .target Rokhan::223215
    .target Li Li Stormstout::253727
step
    #include RestedXP Miscellaneous\a) Loa Trials@LorewalkingLoaStart-LorewalkingLoaEnd
step
--     #label LorewalkingCampaignEnd
    #arrowtext Talk to\n|cRXP_FRIENDLY_Li Li Stormstout|r
    .goto 463,58.52,65.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Li Li Stormstout::253727|r to finish the Loa story and collect your rewards.
    .turnin 92832 >>Turn in Lorewalking: The Hash'ey
    .target Li Li Stormstout::253727
]])
--War Within Recap
RXPGuides.RegisterGuide([[
#retail
#version 1
#group RestedXP Speed Leveling
#name a) War Within Recap
#internal

step
    .goto 2112,59.55,41.46
    .accept 72560 >>Accept Climbing
step
    .goto 2112,47.31,59.15
    .complete 93929,1 --Visit the Tome of History in Valdrakken
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Tome of History|r
    .goto 2112,46.38,60.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tome of History|r
    .turnin 93929 >>Turn in The War Within Recap
    .target Tome of History
    .accept 91843 >>Accept Recap: The Harbinger
    .complete 91843,1 --1/1 Consult the Tome of History to learn about the Harbinger
step
    #arrowtext Talk to\n|cRXP_FRIENDLY_Tome of History|r
    .goto 2112,46.27,60.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cRXP_FRIENDLY_Tome of History|r
    .turnin 91843 >>Turn in Recap: The Harbinger
    .target Tome of History
    .accept 91864 >>Accept Recap: Fractured Visions
]])
