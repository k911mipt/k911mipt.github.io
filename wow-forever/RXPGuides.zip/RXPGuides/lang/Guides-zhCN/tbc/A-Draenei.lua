if GetLocale() ~= "zhCN" then return end
RXPGuides.RegisterGuide([[
#tbc
#wotlk
#version 7
#group RestedXP 燃烧的远征 练级指南 (联盟)
<< Alliance
#name 1-12级 秘蓝岛
#subgroup RestedXP 联盟 1-20 级
#defaultfor Draenei
#next 12-20 秘蓝岛 (德莱尼)

step
    .goto Azuremyst Isle,82.96,43.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_麦格伦|r 对话
    .accept 9279 >> 接受任务 你活下来了！
    .target 麦格伦
step << Shaman/Warrior
	#completewith next
	.goto Azuremyst Isle,79.987,47.117
	.vendor >> |cRXP_WARN_猎杀 2-3只 |cRXP_ENEMY_峡谷蛾|r 或 |cRXP_ENEMY_暴躁的变异体|r 并获取可卖给商人的垃圾物品(价值 10 铜币以上)|r
    >>|cRXP_WARN_在里面的 |cRXP_FRIENDLY_欧洛克|r 处出售垃圾物品|r
    .mob 峡谷蛾
    .mob 暴躁的变异体
    .target 欧洛克
step << Shaman
    .goto Azuremyst Isle,79.278,49.126
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_费曼瓦尔|r 对话
	.train 8017 >>影袭 |T136086:0|t[石化武器]
    .target 费曼瓦尔
step << Warrior
    .goto Azuremyst Isle,79.587,49.446
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_库勒|r 对话
    .train 6673 >>学习 |T132333:0|t[战斗怒吼]
    .target 库勒
step << Priest/Mage
    #completewith next
    +|cRXP_WARN_击杀 |cRXP_ENEMY_峡谷蛾|r 和 |cRXP_ENEMY_暴躁的变异体|r，拾取它们的掉落，直到你拥有价值50铜币的可出售物品（包括你的护甲）|r
    .mob 峡谷蛾
    .mob 暴躁的变异体
step
    .goto Azuremyst Isle,80.419,45.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_普罗尼图斯|r 对话
    .turnin 9279 >> 交任务 你活下来了！
    .accept 9280 >> 接受任务 补充治疗水晶
    .target 普罗尼图斯
step << Priest/Mage
    .goto Azuremyst Isle,79.253,50.884
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_罗约什|r 对话
    .vendor >> |cRXP_WARN_出售垃圾物品|r
    >>|cRXP_BUY_购买10瓶|r |T132794:0|t[清凉的泉水]
    .collect 159,10 --Collect Refreshing Spring Water (x10)
    .target 罗约什
step
    .goto Azuremyst Isle,79.139,46.536
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_植物学家塔蕾克丝|r 对话
    .accept 10302 >> 接受任务 暴躁的变异体
    .target 植物学家塔蕾克丝
step
    #loop
    .goto Azuremyst Isle,80.14,41.70,0
    .goto Azuremyst Isle,75.27,43.70,0
    .goto Azuremyst Isle,73.4,51.4,0
    .goto Azuremyst Isle,80.14,41.70,50,0
    .goto Azuremyst Isle,75.27,43.70,50,0
    .goto Azuremyst Isle,73.4,51.4,50,0
    >>击杀 |cRXP_ENEMY_暴躁的变异体|r
    >>击杀 |cRXP_ENEMY_峡谷蛾|r，拾取它们的 |cRXP_LOOT_血|r
    >>|cRXP_WARN_优先击杀 |cRXP_ENEMY_暴躁的变异体|r，因为你会先交任务，之后再完成 |cRXP_ENEMY_峡谷蛾|r|r
    .complete 10302,1 --Kill Volatile Mutation (x8)
    .mob 暴躁的变异体
    .complete 9280,1 --Collect Vial of Moth Blood (x8)
    .mob 峡谷蛾
    .disablecheckbox
step
    #optional
    .isQuestComplete 9280
    .goto Azuremyst Isle,80.419,45.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_普罗尼图斯|r 对话
    .turnin 9280 >> 交任务 补充治疗水晶
    .accept 9409 >> 接受任务 紧急物资！
    .target 普罗尼图斯
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_植物学家塔蕾克丝|r 和 |cRXP_FRIENDLY_学徒维莎尔|r 对话
    .turnin 10302 >> 交任务 暴躁的变异体
    .accept 9293 >> 接受任务 必需的措施……
    .target 植物学家塔蕾克丝
    .goto Azuremyst Isle,79.139,46.536
    .accept 9799 >> 接受任务 跑腿采花
    .target 学徒维莎尔
    .goto Azuremyst Isle,79.071,46.624
step
    #completewith next
    >>击杀 |cRXP_ENEMY_峡谷蛾|r，拾取它们的 |cRXP_LOOT_血|r
    .complete 9280,1 --Collect Vial of Moth Blood (x8)
    .mob 峡谷蛾
step
    #loop
    .goto Azuremyst Isle,74.5,48.5,0
    .goto Azuremyst Isle,72.94,52.21,0
    .goto Azuremyst Isle,72.26,49.29,0
    .goto Azuremyst Isle,74.5,48.5,50,0
    .goto Azuremyst Isle,72.94,52.21,50,0
    .goto Azuremyst Isle,72.26,49.29,50,0
    >>击杀 |cRXP_ENEMY_变异的根须鞭笞者|r，拾取它们的 |cRXP_LOOT_鞭笞者样本|r
    >>拾取地上的 |cRXP_LOOT_被污染的花朵|r
    .complete 9293,1 --Collect Lasher Sample (x10)
    .complete 9799,1 --Collect Corrupted Flower (x3)
    .mob 变异的根须鞭笞者
step
    #loop
    .goto Azuremyst Isle,74.6,43.6,0
    .goto Azuremyst Isle,78.2,40.2,0
    .goto Azuremyst Isle,79.2,45.0,0
    .goto Azuremyst Isle,76.0,46.6,0
    .goto Azuremyst Isle,74.6,43.6,60,0
    .goto Azuremyst Isle,78.2,40.2,60,0
    .goto Azuremyst Isle,79.2,45.0,60,0
    .goto Azuremyst Isle,76.0,46.6,60,0
    >>击杀 |cRXP_ENEMY_峡谷蛾|r，拾取它们的 |cRXP_LOOT_血|r
    .complete 9280,1 --Collect Vial of Moth Blood (x8)
    .mob 峡谷蛾
step
    #optional
    .isQuestTurnedIn 9280
    #loop
    .goto Azuremyst Isle,74.5,48.5,0
    .goto Azuremyst Isle,72.9,52.2,0
    .goto Azuremyst Isle,72.2,49.2,0
    .goto Azuremyst Isle,74.6,43.6,0
    .goto Azuremyst Isle,78.2,40.2,0
    .goto Azuremyst Isle,79.2,45.0,0
    .goto Azuremyst Isle,76.0,46.6,0
    .goto Azuremyst Isle,74.5,48.5,50,0
    .goto Azuremyst Isle,72.9,52.2,50,0
    .goto Azuremyst Isle,72.2,49.2,50,0
    .goto Azuremyst Isle,74.6,43.6,60,0
    .goto Azuremyst Isle,78.2,40.2,60,0
    .goto Azuremyst Isle,79.2,45.0,60,0
    .goto Azuremyst Isle,76.0,46.6,60,0
	.xp 4-420 >>刷怪练级，直到距离4级还差420点经验（980/1400）
    .mob 变异的根须鞭笞者
    .mob 暴躁的变异体
    .mob 峡谷蛾
step
    #optional
    .isQuestAvailable 9280
    #loop
    .goto Azuremyst Isle,74.5,48.5,0
    .goto Azuremyst Isle,72.9,52.2,0
    .goto Azuremyst Isle,72.2,49.2,0
    .goto Azuremyst Isle,74.6,43.6,0
    .goto Azuremyst Isle,78.2,40.2,0
    .goto Azuremyst Isle,79.2,45.0,0
    .goto Azuremyst Isle,76.0,46.6,0
    .goto Azuremyst Isle,74.5,48.5,50,0
    .goto Azuremyst Isle,72.9,52.2,50,0
    .goto Azuremyst Isle,72.2,49.2,50,0
    .goto Azuremyst Isle,74.6,43.6,60,0
    .goto Azuremyst Isle,78.2,40.2,60,0
    .goto Azuremyst Isle,79.2,45.0,60,0
    .goto Azuremyst Isle,76.0,46.6,60,0
	.xp 4-500 >>刷怪练级，直到距离4级还差500点经验（900/1400）
    .mob 变异的根须鞭笞者
    .mob 暴躁的变异体
    .mob 峡谷蛾
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_植物学家塔蕾克丝|r 和 |cRXP_FRIENDLY_学徒维莎尔|r 对话
    .turnin 9293 >> 交任务 必需的措施……
    .accept 9294 >> 接受任务 净化湖水
    .target 植物学家塔蕾克丝
    .goto Azuremyst Isle,79.139,46.536
    .turnin 9799 >> 交任务 跑腿采花
    .target 学徒维莎尔
    .goto Azuremyst Isle,79.071,46.624
step
    .goto Azuremyst Isle,80.419,45.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_普罗尼图斯|r 对话
    .turnin 9280 >> 交任务 补充治疗水晶
    .accept 9409 >> 接受任务 紧急物资！
    .target 普罗尼图斯
step
	#completewith next
	.goto Azuremyst Isle,79.987,47.117
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧洛克|r 对话
	.vendor >> 把垃圾物品卖给商人
    .target 欧洛克
step << Mage
	.goto Azuremyst Isle,79.582,48.762
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_瓦拉图|r 对话
	.accept 9290 >> 接受任务 法师训练
	.turnin 9290 >> 交任务 法师训练
    .train 1459 >> 学习 |T135932:0|t[奥术智慧]
    .train 116 >> 学习 |T135846:0|t[寒冰箭]
    .target 瓦拉图
step << Paladin
    #loop
    .goto Azuremyst Isle,79.695,48.236,7,0
    .goto Azuremyst Isle,80.12,49.13,7,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_奥雷伦|r 对话
    >>|cRXP_FRIENDLY_奥雷伦|r |cRXP_WARN_可能会稍微巡逻|r
	.accept 9287 >> 接受任务 圣骑士训练
	.turnin 9287 >> 交任务 圣骑士训练
    .train 465 >>训练 |T135893:0|t[虔诚光环]
    .train 19740 >> 学习 |T135906:0|t[力量祝福]
    .train 20271 >> 学习 |T135959:0|t[审判]
    .target 奥雷伦
step
    #loop
    .goto Azuremyst Isle,80.25,48.46,10,0
    .goto Azuremyst Isle,80.01,49.42,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_扎尔杜|r 对话
    >>|cRXP_FRIENDLY_扎尔杜|r |cRXP_WARN_会稍微巡逻|r
    .turnin 9409 >> 交任务 紧急物资！
    .accept 9283 >> 接受任务 拯救幸存者！
    .accept 9291 >> 接受任务 牧师训练 << Priest
    .turnin 9291 >> 交任务 牧师训练 << Priest
    .train 1243 >> 学习 |T135987:0|t[真言术：韧] << Priest
    .train 2052 >> 学习 |T135929:0|t[次级治疗术] << Priest
    .train 589 >> 训练 |T136207:0|t[暗言术：痛] << Priest
    .target 扎尔杜
step << Shaman
    .goto Azuremyst Isle,79.278,49.126
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_费曼瓦尔|r 对话
    .accept 9421 >> 接受任务 萨满祭司训练
	.turnin 9421 >> 交任务 萨满祭司训练
    .accept 9449 >> 接受任务 大地的召唤
	.train 8042 >> 影袭 |T136026:0|t[大地震击]
    .target 费曼瓦尔
step << Shaman
    #completewith next
    .usespell 28880 >>|cRXP_WARN_如果你看到 |r德莱尼幸存者|cRXP_WARN_，对其施放|cRXP_FRIENDLY_ |T135923:0|t[纳鲁的祝福]|r|r
    .complete 9283,1 --Draenei Survivors Saved
    .unitscan 德莱尼幸存者
step << Shaman
    .goto Azuremyst Isle,71.788,40.241
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_峡谷之灵|r 对话
    .turnin 9449 >> 交任务 大地的召唤
    .accept 9450 >> 接受任务 大地的召唤
    .target 峡谷之灵
step << Shaman
    #loop
    .goto Azuremyst Isle,69.62,35.13,0
    .goto Azuremyst Isle,70.73,37.74,40,0
    .goto Azuremyst Isle,69.62,35.13,60,0
    >>击杀 |cRXP_ENEMY_躁动的大地之灵|r
    .complete 9450,1 --Kill Restless Spirit of Earth (x4)
    .mob 躁动的大地之灵
step << Shaman
    .goto Azuremyst Isle,71.788,40.241
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_峡谷之灵|r 对话
    .turnin 9450 >> 交任务 大地的召唤
    .accept 9451 >> 接受任务 大地的召唤
    .target 峡谷之灵
step << Shaman
    #completewith next
    .usespell 28880 >>|cRXP_WARN_如果你看到 |r德莱尼幸存者|cRXP_WARN_，对其施放|cRXP_FRIENDLY_ |T135923:0|t[纳鲁的祝福]|r|r
    .complete 9283,1 --Draenei Survivors Saved
    .unitscan 德莱尼幸存者
step << Shaman
    .goto Azuremyst Isle,79.278,49.126
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_费曼瓦尔|r 对话
    .turnin 9451 >> 交任务 大地的召唤
    .target 费曼瓦尔
step << Shaman
    .isQuestComplete 9283
    #optional
    #loop
    .goto Azuremyst Isle,80.25,48.46,10,0
    .goto Azuremyst Isle,80.01,49.42,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_扎尔杜|r 对话
    >>|cRXP_FRIENDLY_扎尔杜|r |cRXP_WARN_会稍微巡逻|r
    .turnin 9283 >> 交任务 拯救幸存者！
    .target 扎尔杜
step << Warrior
    .goto Azuremyst Isle,79.587,49.446
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_库勒|r 对话
    .accept 9289 >> 接受任务 战士训练
	.turnin 9289 >> 交任务 战士训练
    .train 100 >> 学习 |T132337:0|t[冲锋]
    .train 772 >> 学习 |T132155:0|t[撕裂]
    .target 库勒
step << Hunter
	.goto Azuremyst Isle,79.886,49.711
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_基尔尼|r 对话
	.accept 9288 >> 接受任务 猎人训练
	.turnin 9288 >> 交任务 猎人训练
    .train 1978 >>学习 |T132204:0|t[毒蛇钉刺]
    .target 基尔尼


--xx

step << Priest
	.goto Azuremyst Isle,79.254,50.887
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_罗约什|r 对话
    >>|cRXP_BUY_从他那里|r|cRXP_BUY_购买10瓶|r |T132794:0|t[清凉的泉水]
    .collect 159,10 --Collect Refreshing Spring Water (x15)
    .target 罗约什
    .xp >5,1

--xx


step << Shaman/Hunter
	#completewith next
	.goto Azuremyst Isle,79.188,50.928
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_姆拉|r 对话
	.vendor >> 把垃圾物品卖给商人
    >>|cRXP_BUY_从她那里|r购买 5 堆|cRXP_BUY_ |T132382:0|t[劣质箭] |r << Hunter
    .collect 2512,1000 << Hunter --Rough Arrow (1000)
    .target 姆拉
step
    .goto Azuremyst Isle,79.419,51.235
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_技师沙娜安|r 对话
    .accept 9305 >> 接受任务 备用零件
    .target 技师沙娜安
step
    .goto Azuremyst Isle,79.486,51.620
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官奥达尔|r 对话
    .accept 9303 >> 接受任务 疫苗
    .target 守备官奥达尔
step
    #completewith Owlkininoculated
    .usespell 28880 >>|cRXP_WARN_对|r |T135923:0|t[纳鲁的祝福]|cRXP_WARN_施放于|r|cRXP_FRIENDLY_德莱尼幸存者|r|cRXP_WARN_。他们分散在整个新手区域各处|r
    .complete 9283,1 --Draenei Survivors Saved
    .unitscan 德莱尼幸存者
    .subzoneskip 3559 -- Nestlewood Hills
step
    .goto Azuremyst Isle,77.390,58.779
	>>点击湖中的 |cRXP_PICK_受辐射的能量水晶|r
    .complete 9294,1 --Collect Disperse the Neutralizing Agent (x1)
step
    #completewith next
	.use 22962 >>|cRXP_WARN_对|r 木巢枭兽|cRXP_WARN_ |cRXP_ENEMY_引导|r |T132775:0|t[接种水晶] 持续 4 秒|r
    .complete 9303,1 --Nestlewood Owlkin inoculated (x6)
    .mob 木巢枭兽
step
    .goto Azuremyst Isle,80.92,58.89,20,0
    .goto Azuremyst Isle,82.27,59.43,30,0
    .goto Azuremyst Isle,82.93,61.46,30,0
    .goto Azuremyst Isle,85.49,68.25,50,0
    .goto Azuremyst Isle,88.33,62.21
	>>拾取地上的 |cRXP_LOOT_发射器零件|r
    .complete 9305,1 --Collect Emitter Spare Part (x4)
step
    #label Owlkininoculated
    .goto Azuremyst Isle,80.92,58.89,20,0
    .goto Azuremyst Isle,82.27,59.43,30,0
    .goto Azuremyst Isle,82.93,61.46,30,0
    .goto Azuremyst Isle,85.49,68.25,50,0
    .goto Azuremyst Isle,88.33,62.21
	.use 22962 >>|cRXP_WARN_对|r 木巢枭兽|cRXP_WARN_ |cRXP_ENEMY_引导|r |T132775:0|t[接种水晶] 持续 4 秒|r
    .complete 9303,1 --Nestlewood Owlkin inoculated (x6)
    .mob 木巢枭兽
step
	#completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
    >>如果需要，站在附近的篝火上承受额外伤害
step
    .goto Azuremyst Isle,79.139,46.536
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_植物学家塔蕾克丝|r 对话
    .turnin 9294 >> 交任务 净化湖水
    .target 植物学家塔蕾克丝
step
	#completewith SpareParts
	.goto Azuremyst Isle,79.987,47.117
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧洛克|r 对话
	.vendor >> 把垃圾物品卖给商人
    .target 欧洛克
step
    .isQuestComplete 9283
    #optional
    #loop
    .goto Azuremyst Isle,80.25,48.46,10,0
    .goto Azuremyst Isle,80.01,49.42,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_扎尔杜|r 对话
    >>|cRXP_FRIENDLY_扎尔杜|r |cRXP_WARN_会稍微巡逻|r
    .turnin 9283 >> 交任务 拯救幸存者！
    .target 扎尔杜
step
    #label SpareParts
    .goto Azuremyst Isle,79.419,51.235
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_技师沙娜安|r 对话
    .turnin 9305 >> 交任务 备用零件
    .target 技师沙娜安
step
    .goto Azuremyst Isle,79.486,51.620
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官奥达尔|r 对话
    .turnin 9303 >> 交任务 疫苗
    .accept 9309 >> 接受任务 失踪的斥候
    .target 守备官奥达尔
step
    #completewith SurveyorCandress
    .usespell 28880 >>|cRXP_WARN_对一名|r |cRXP_WARN_德莱尼幸存者|r |cRXP_FRIENDLY_施放|r |T135923:0|t[纳鲁的祝福] |cRXP_WARN_。他们分散在整个新手区域各处|r
    .complete 9283,1 --Draenei Survivors Saved
    .unitscan 德莱尼幸存者
step
    .goto Azuremyst Isle,71.998,60.856
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图兰|r 对话
    .turnin 9309 >> 交任务 失踪的斥候
    .accept 10303 >> 接受任务 血精灵
    .target 图兰
step
    .goto Azuremyst Isle,69.420,64.608
    >>击杀 |cRXP_ENEMY_血精灵斥候|r
    .complete 10303,1 --Kill Blood Elf Scout (x10)
    .mob 血精灵斥候
step
    .goto Azuremyst Isle,71.998,60.856
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图兰|r 对话
    .turnin 10303 >> 交任务 血精灵
    .accept 9311 >> 接受任务 血精灵间谍
    .target 图兰
step
    #label SurveyorCandress
    .goto Azuremyst Isle,69.271,65.772
    >>击杀 |cRXP_ENEMY_测量员卡蒂瑞丝|r。拾取 |T132319:0|t[|cRXP_LOOT_血精灵计划书|r]
    .use 24414 >>|cRXP_WARN_使用|r |T132319:0|t[|cRXP_LOOT_血精灵计划书|r] |cRXP_WARN_来开始任务|r
    .complete 9311,1 --Kill Surveyor Candress (x1)
    .collect 24414,1,9798,1 -- Blood Elf Plans
    .accept 9798 >> 接受任务 血精灵计划书
    .mob 测量员卡蒂瑞丝
step
    #loop
    .goto Azuremyst Isle,71.8,55.8,0
    .goto Azuremyst Isle,77.6,56.0,0
    .goto Azuremyst Isle,74.8,43.4,0
    .goto Azuremyst Isle,80.2,42.6,0
    .goto Azuremyst Isle,71.8,55.8,80,0
    .goto Azuremyst Isle,77.6,56.0,80,0
    .goto Azuremyst Isle,74.8,43.4,80,0
    .goto Azuremyst Isle,80.2,42.6,80,0
    >>|cRXP_WARN_对|r |T135923:0|t[纳鲁的祝福]|cRXP_WARN_施放于|r|cRXP_FRIENDLY_德莱尼幸存者|r|cRXP_WARN_。他们分散在整个新手区域各处|r
    .complete 9283,1 --Draenei Survivors Saved
    .unitscan 德莱尼幸存者
step
    #optional
    .isQuestAvailable 9283
    .goto Azuremyst Isle,69.420,64.608
    .xp 6-1450 >>刷 |cRXP_ENEMY_血精灵斥候|r，直到距离6级还差1450点经验（1350/2800）。在最后几只怪时让自己的生命值降低一些，接下来要进行自杀跳过
    .mob 血精灵斥候
step
    #optional
    .isQuestTurnedIn 9283
    .goto Azuremyst Isle,69.420,64.608
    .xp 6-1230 >>刷 |cRXP_ENEMY_血精灵斥候|r，直到距离6级还差1230点经验（1570/2800）。在最后几只怪时让自己的生命值降低一些，接下来要进行自杀跳过
    .mob 血精灵斥候
step
	#completewith BloodElfSpy
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    #loop
    .goto Azuremyst Isle,80.25,48.46,0
    .goto Azuremyst Isle,80.25,48.46,10,0
    .goto Azuremyst Isle,80.01,49.42,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_扎尔杜|r 对话
    >>|cRXP_FRIENDLY_扎尔杜|r |cRXP_WARN_会稍微巡逻|r
    .turnin 9283 >> 交任务 拯救幸存者！
    .target 扎尔杜
step
    #label BloodElfSpy
    .goto Azuremyst Isle,79.488,51.622
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官奥达尔|r 对话
    .turnin 9311 >> 交任务 血精灵间谍
    .turnin 9798 >> 交任务 血精灵计划书
    .accept 9312 >> 接受任务 图像发射器
    .target 守备官奥达尔
step
    .goto Azuremyst Isle,79.422,51.234
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_技师沙娜安|r 对话
    .turnin 9312 >> 交任务 图像发射器
    .accept 9313 >> 接受任务 前往碧蓝岗哨
    .target 技师沙娜安
step
    .goto Azuremyst Isle,64.497,54.037
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_埃文|r 对话
    .accept 9314 >> 接受任务 碧蓝岗哨的消息
    .target 埃文
step
    .goto Azuremyst Isle,61.052,54.248
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_迪泰娜|r 对话
    .accept 9452 >> 接受任务 美味的红钳鱼
    .target 迪泰娜
step
    .isOnQuest 9452
    .goto Azuremyst Isle,62.38,51.93,40,0
    .goto Azuremyst Isle,61.87,41.62,60 >> |cRXP_WARN_沿着河向北游|r
    .use 23654 >>|cRXP_WARN_沿途看到|r |T134325:0|t[德莱尼渔网] |cRXP_WARN_时对|r |cRXP_PICK_红钳鱼鱼群|r |cRXP_WARN_使用。到达河流上游后跳过此步骤，稍后会完成|r
	.collect 23614,10 -- Red Snapper (10)
    .disablecheckbox
step
	#completewith next
    >>|cRXP_WARN_留意一下|r |cRXP_FRIENDLY_年幼的德莱尼人|r
    >>|cRXP_WARN_趁他们战斗时，对他们施放|r |T135923:0|t[纳鲁的赐福] |cRXP_WARN_，然后接任务|r
	.accept 9612 >> 接受任务 非常感谢！
	.unitscan 年幼的德莱尼人
step
    .goto Azuremyst Isle,53.9,34.4
    >>击杀 |cRXP_ENEMY_感染的夜行豹幼崽|r，拾取 |T134072:0|t[|cRXP_LOOT_微微发光的水晶|r]
    .use 23678 >>|cRXP_WARN_使用|r |T134072:0|t[|cRXP_LOOT_微微发光的水晶|r] |cRXP_WARN_来开始任务|r
	.collect 23678,1,9455,1 -- Faintly Glowing Crystal (1)
    .accept 9455 >> 接受任务 奇怪的发现
    .mob 感染的夜行豹幼崽
step
	#completewith NightstalkerCleanUp
    .goto Azuremyst Isle,56.1,39.3
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
    >>|cRXP_WARN_确保死在靠山一侧的池塘附近|r
step
    #completewith NightstalkerCleanUp
    .subzone 3576 >> 前往碧蓝岗哨
step
    .goto Azuremyst Isle,48.391,51.771
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_学者法蒂玛|r 对话
    .accept 9463 >> 接受任务 医疗材料
    .target 学者法蒂玛
step
	.isOnQuest 9612
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
	.turnin 9612 >> 交任务 非常感谢！
    .turnin 9455 >> 交任务 奇怪的发现
    .accept 9456 >> 接受任务 清理夜行豹……
    .target 大主教梅内莱厄斯
step
    #label NightstalkerCleanUp
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9455 >> 交任务 奇怪的发现
    .accept 9456 >> 接受任务 清理夜行豹……
    .target 大主教梅内莱厄斯
step
    .goto Azuremyst Isle,48.7,50.2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_技师戴维恩|r 对话
    .turnin 9313 >> 交任务 前往碧蓝岗哨
    .target 技师戴维恩
step
    .goto Azuremyst Isle,48.4,49.3
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_看护员谢尔兰|r 对话
    .turnin 9314 >> 交任务 碧蓝岗哨的消息
    .target 看护员谢尔兰
step
	.goto Azuremyst Isle,48.336,49.144
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_看护员谢尔兰|r 对话
    .home >> 将你的炉石绑定到碧蓝岗哨
    .target 看护员谢尔兰
    .subzoneskip 3576,1
step << Priest
    .goto Azuremyst Isle,48.603,49.285
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古安|r 对话
    .accept 9586 >> 接受任务 帮助塔瓦拉
    .train 591 >>影袭 |T135924:0|t[惩击]
    .train 17 >>影袭 |T135940:0|t[真言术：盾]
    .target 古安
step << Mage
    .goto Azuremyst Isle,49.868,49.949
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塞米德|r 对话
    .train 143 >> 学习 |T135812:0|t[火球术]
    .train 2136 >>学习 |T135807:0|t[火焰冲击]
    .target 塞米德
step << Hunter
    .goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
    .train 3044 >> 训练 |T132218:0|t[奥术射击]
    .train 1130 >> 训练 |T132212:0|t[猎人印记]
    .target 艾克提恩
step << Shaman
    .goto Azuremyst Isle,49.579,53.107
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳贝克|r 对话
    >>|cRXP_BUY_购买并装备一把|r |T135145:0|t[学徒短杖]
    .collect 2495,1 --Walking Stick (1)
    .target 纳贝克
    .money <0.0480
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.20
step << Shaman
    #sticky
    .equip 16,2495 >> |cRXP_WARN_装备|r |T135145:0|t[学徒短杖]
    .use 2495
    .itemcount 2495,1
step << Paladin
    .goto Azuremyst Isle,49.579,53.107
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳贝克|r 对话
    >>|cRXP_BUY_购买并装备一梗|r |T133053:0|t[木槌棒]
    .collect 2493,1 --Collect Wooden Mallet (1)
    .target 纳贝克
    .money <0.0666
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.00
step << Paladin
    #sticky
    .equip 16,2493 >> |cRXP_WARN_装备买来的|r |T133053:0|t[木槌棒]
    .use 2493
    .itemcount 2493,1
step << Warrior
    .goto Azuremyst Isle,49.579,53.107
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳贝克|r 对话
    >>|cRXP_BUY_Buy a|r |T135321:0|t[Gladius] |cRXP_BUY_if you can afford it|r (NOT TRANSLATED IN :zhCN YET)
    .collect 2488,1 --Collect Gladius (1)
    .target 纳贝克
    .money <0.0536
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.8
step << Warrior
    +|cRXP_WARN_装备|r |T135321:0|t[步兵剑]
    .use 2488
    .itemcount 2488,1
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.8
step << Warrior/Paladin
    .goto Azuremyst Isle,48.957,51.062
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_杜尔维|r 对话
    .train 2575 >>学习 |T134708:0|t[采矿]
    .target 杜尔维
step << Warrior/Paladin
    .goto Azuremyst Isle,48.767,52.403
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_其兹|r 对话
    >>|cRXP_BUY_从他那里|r|cRXP_BUY_购买一把|r |T134708:0|t[矿工锄]
    .collect 2901,1 --Mining Pick (1)
    .target 其兹
    .train 2575,3 --Mining
step << Warrior/Paladin
    #optional
    #completewith SGrain
    .cast 2580 >> |cRXP_WARN_施放|r |T136025:0|t[寻找矿物]
    .usespell 2580
    .train 2575,3 --Mining
step
	#completewith level8
    >>|cRXP_WARN_留意一下|r |cRXP_FRIENDLY_年幼的德莱尼人|r
    >>|cRXP_WARN_趁他们战斗时，对他们施放|r |T135923:0|t[纳鲁的赐福] |cRXP_WARN_，然后接任务|r
	.accept 9612 >> 接受任务 非常感谢！
	.unitscan 年幼的德莱尼人
step
    #completewith LeavesTree
    >>击杀 |cRXP_ENEMY_根须诱捕者|r。拾取他们的 |cRXP_LOOT_枝条|r
    >>击杀 |cRXP_ENEMY_月痕雄鹿|r。拾取他们的 |cRXP_LOOT_嫩腰肉|r
    .complete 9463,1 -- Root Trapper (6)
    .mob 根须诱捕者
    .collect 23676,6,9454,1 -- Moongraze Stag Tenderloin (6)
    .mob 月痕雄鹿
step << Priest
    .goto Azuremyst Isle,56.224,48.879
    .usespell 2052 >>|cRXP_WARN_对|r塔瓦拉|cRXP_WARN_|r施放|cRXP_FRIENDLY_ |T135929:0|t[次级治疗] (等级 2) |r
    .complete 9586,1 --Heal Tavara
    .target 塔瓦拉
step
    .goto Azuremyst Isle,47.038,70.206
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 对话
    .accept 9506 >> 接受任务 第三类接触
    .target 海军上将奥德修斯
step
    .goto Azuremyst Isle,46.681,70.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_"曲奇"米维克索斯|r 对话
    .accept 9512 >> 接受任务 曲奇的大餐
    .target “曲奇”米维克索斯 <厨师>
step << Warrior/Paladin
    .goto Azuremyst Isle,46.355,71.192
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_铁匠卡里普索|r 对话
    >>|cRXP_WARN_这将使你能够制作 |r|T135248:0|t[劣质磨刀石]|cRXP_WARN_ 和|r |T135255:0|t[劣质平衡石]|cRXP_WARN_，它们可使你的近战伤害提高 2 点|r
    .train 2018 >> 学习 |T136241:0|t[锻造]
    .target 铁匠卡里普索
    .train 2575,3 --Mining
step
    .goto Azuremyst Isle,58.607,66.372
	>>拾取小笼子上的 |cRXP_LOOT_航海地图|r
    .complete 9506,2 --Collect Nautical Map (x1)
step
    .goto Azuremyst Isle,59.578,67.648
	>>拾取小箱子上的 |cRXP_LOOT_航海罗盘|r
    .complete 9506,1 --Collect Nautical Compass (x1)
step
    #loop
    .goto Azuremyst Isle,57.0,69.2,0
    .goto Azuremyst Isle,50.8,69.4,0
    .goto Azuremyst Isle,46.0,75.6,0
    .goto Azuremyst Isle,57.0,69.2,70,0
    .goto Azuremyst Isle,50.8,69.4,70,0
    .goto Azuremyst Isle,46.0,75.6,70,0
	>>击杀 |cRXP_ENEMY_迅捷的螃蟹|r。拾取他们的 |cRXP_LOOT_螃蟹肉|r
    .complete 9512,1 --Collect Skittering Crawler Meat (x6)
    .mob 迅捷的螃蟹
step
    .goto Azuremyst Isle,46.681,70.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_"曲奇"米维克索斯|r 对话
    .turnin 9512 >> 交任务 曲奇的大餐
    .target “曲奇”米维克索斯 <厨师>
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 和 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .turnin 9506 >> 交任务 第三类接触
    .accept 9530 >> 接受任务 天才的方案！
    .target 海军上将奥德修斯
    .goto Azuremyst Isle,47.038,70.206
    .accept 9513 >> 接受任务 夺回废墟
    .target 女祭司基琳·伊尔蒂娜
    .goto Azuremyst Isle,47.131,70.289
step
    .goto Azuremyst Isle,47.243,69.998
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_考古学家阿达曼特·铁心|r 对话
    .accept 9523 >> 接受任务 贵重物品，小心轻放
    .target 考古学家阿达曼特·铁心
step
    #label LeavesTree
    #loop
    .goto Azuremyst Isle,51.5,66.0,0
    .goto Azuremyst Isle,40.0,69.2,0
    .goto Azuremyst Isle,51.5,66.0,50,0
    .goto Azuremyst Isle,49.2,61.9,50,0
    .goto Azuremyst Isle,40.0,69.2,50,0
	>>拾取地上的 a |cRXP_LOOT_刳心巨树|r
    >>拾取地上的 |cRXP_LOOT_落叶堆|r
    .complete 9530,1 --Collect Hollowed Out Tree (x1)
    .complete 9530,2 --Collect Pile of Leaves (x5)
step
    #loop
    .goto Azuremyst Isle,51.5,66.0,0
    .goto Azuremyst Isle,40.0,69.2,0
    .goto Azuremyst Isle,51.5,66.0,50,0
    .goto Azuremyst Isle,49.2,61.9,50,0
    .goto Azuremyst Isle,40.0,69.2,50,0
    >>击杀 |cRXP_ENEMY_根须诱捕者|r。拾取他们的 |cRXP_LOOT_枝条|r
    >>击杀 |cRXP_ENEMY_月痕雄鹿|r。拾取他们的 |cRXP_LOOT_嫩腰肉|r
    .complete 9463,1 -- Root Trapper (6)
    .mob 根须诱捕者
    .collect 23676,6,9454,1 -- Moongraze Stag Tenderloin (6)
    .mob 月痕雄鹿
step
    .goto Azuremyst Isle,47.038,70.206
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 对话
    .turnin 9530 >> 交任务 天才的方案！
    .accept 9531 >> 接受任务 间谍之树
    .target 海军上将奥德修斯
step
    #label level8
	.xp 8-950 >> 刷怪练级，直到距离8级还差950点经验（3550/4500）
    >>|cRXP_WARN_尽量在碧蓝岗哨附近完成|r
step
	#completewith next
    .goto Azuremyst Isle,49.780,51.938
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
    >>|cRXP_WARN_如果你已经离碧蓝岗哨很近了，就跳过这一步|r
    .subzoneskip 3576
step
	.goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
	.accept 9454 >> 接受任务 狩猎月痕鹿
    .turnin 9454 >> 交任务 狩猎月痕鹿
    .accept 10324 >> 接受任务 狩猎月痕鹿
    .target 艾克提恩
step << Hunter
    .goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
    .train 5116 >> 训练 |T135860:0|t[震荡射击]
    .train 14260 >> 训练 |T132223:0|t[猛禽一击]
    .target 艾克提恩
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_学者法蒂玛|r 和 |cRXP_FRIENDLY_丹达尔|r 对话
    .turnin 9463 >> 交任务 医疗材料
    .target 学者法蒂玛
    .goto Azuremyst Isle,48.390,51.770
    .accept 9473 >> 接受任务 备选方案的备选方案
    .target 丹达尔
    .goto Azuremyst Isle,48.392,51.482
step
    #optional
    .isOnQuest 9612
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9612 >> 交任务 非常感谢！
    .target 大主教梅内莱厄斯
step << Shaman
    .goto Azuremyst Isle,48.053,50.419
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图伦|r 对话
    .trainer >> 训练你的职业技能
    .target 图伦
    .subzoneskip 3576,1
step
    .goto Azuremyst Isle,48.9,51.1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_杜尔维|r 对话
    .accept 10428 >> 接受任务 失踪的渔夫
    .target 杜尔维
step
    .goto Azuremyst Isle,49.365,51.086
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_译码者奥鲁恩|r 对话
    .accept 9538 >> 接受任务 学外语……
    .target 译码者奥鲁恩
step
	.use 23818 >>|cRXP_WARN_使用|r |T133741:0|t[止松熊怪语言入门]
    .complete 9538,1 --Stillpine Furbolg Language Primer Read
step
    .goto Azuremyst Isle,49.439,50.977
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿基达图腾|r 对话
    .turnin 9538 >> 交任务 学外语……
    .accept 9539 >> 接受任务 库欧图腾
    .target 阿基达图腾
step << Priest
    .goto Azuremyst Isle,48.603,49.285
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古安|r 对话
    .turnin 9586 >> 交任务 帮助塔瓦拉
    .trainer >> 训练你的职业技能
    .target 古安
step << Paladin
    .goto Azuremyst Isle,48.356,49.558
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图拉丝|r 对话
    .trainer >> 训练你的职业技能
    .target 图拉丝
    .subzoneskip 3576,1
step << Mage
    .goto Azuremyst Isle,49.868,49.949
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塞米德|r 对话
    .trainer >> 训练你的职业技能
    .target 塞米德
    .subzoneskip 3576,1
step << Warrior
    .goto Azuremyst Isle,50.023,50.515
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_鲁安达|r 对话
    .train 772 >> 学习 |T132155:0|t[撕裂]
    .target 鲁安达
    .subzoneskip 3576,1
step
	#completewith AncientRelics
    >>|cRXP_WARN_留意一下|r |cRXP_FRIENDLY_年幼的德莱尼人|r
    >>|cRXP_WARN_趁他们战斗时，对他们施放|r |T135923:0|t[纳鲁的赐福] |cRXP_WARN_，然后接任务|r
	.accept 9612 >> 接受任务 非常感谢！
	.unitscan 年幼的德莱尼人
step
	#completewith TotemofTikti
    >>击杀 |cRXP_ENEMY_感染的夜行豹幼崽|r
	>>击杀 |cRXP_ENEMY_月痕巨鹿|r，拾取它们的 |cRXP_LOOT_兽皮|r
    .complete 9456,1 --Kill Infected Nightstalker Runt (x8)
    .mob 感染的夜行豹幼崽
	.complete 10324,1 -- Moongraze Buck Hide (6)
    .mob 月痕巨鹿
step
	.goto Azuremyst Isle,49.9,45.9,100,0
    .goto Azuremyst Isle,55.233,41.643
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_库欧图腾|r 对话
    .turnin 9539 >> 交任务 库欧图腾
    .accept 9540 >> 接受任务 提克提图腾
    .target 库欧图腾
step
    #completewith next
    .goto Azuremyst Isle,54.531,40.493,10 >> |cRXP_WARN_沿着山边小心下落|r
step
    #loop
    .goto Azuremyst Isle,51.9,32.4,0
    .goto Azuremyst Isle,44.2,37.5,0
    .goto Azuremyst Isle,51.9,32.4,60,0
    .goto Azuremyst Isle,44.2,37.5,60,0
	>>拾取地上的 |cRXP_LOOT_碧蓝金鱼草|r
    .complete 9473,1 --Collect Azure Snapdragon Bulb (x5)
step
    #label TotemofTikti
    .goto Azuremyst Isle,64.475,39.772
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_提克提图腾|r 对话
    .turnin 9540 >> 交任务 提克提图腾
    .accept 9541 >> 接受任务 尤尔图腾
    .timer 30,尤尔图腾剧情演出
    .target 提克提图腾
step
    .isOnQuest 9541
    .goto Azuremyst Isle,63.64,40.09
    .aura 30430 >> |cRXP_WARN_跟随|r |cRXP_FRIENDLY_止松先祖提克提|r|cRXP_WARN_。他会为你施加|r |T132107:0|t[毒蛇的拥抱] |cRXP_WARN_，使你的游泳速度提高150%，并获得水下呼吸效果|r
step
    .goto Azuremyst Isle,63.2,68.0
    .use 23654 >>|cRXP_WARN_使用|r |T134325:0|t[德莱尼渔网]|cRXP_WARN_对|r|cRXP_PICK_红钳鱼鱼群|r
    >>|cRXP_WARN_如果有 |cRXP_ENEMY_鱼人|r 从鱼群中刷出，立刻游走！施放任何敌对法术都会导致你失去|r |T132107:0|t[毒蛇的拥抱] |cRXP_WARN_增益效果|r
    .complete 9452,1 --Collect Red Snapper (x10)
step
    .goto Azuremyst Isle,61.052,54.248
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_迪泰娜|r 对话
    .turnin 9452 >> 交任务 美味的红钳鱼
    .accept 9453 >> 接受任务 找到艾克提恩！
    .target 迪泰娜
step
    .goto Azuremyst Isle,63.116,67.880
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与水底下的 |cRXP_FRIENDLY_尤尔图腾|r 对话
    .turnin 9541 >> 交任务 尤尔图腾
    .accept 9542 >> 接受任务 瓦克图腾
    .timer 71,瓦克图腾剧情演出
    .target 尤尔图腾
step
    .isOnQuest 9542
    .goto Azuremyst Isle,60.971,69.354
    .aura 30448 >> |cRXP_WARN_跟随|r |cRXP_FRIENDLY_止松先祖尤尔|r|cRXP_WARN_。他会为你施加|r |T132142:0|t[森林之影] |cRXP_WARN_，使你获得移动速度提高和隐身效果|r
step
    #completewith next
    .goto Azuremyst Isle,28.115,62.391,30 >> |cRXP_WARN_前往秘蓝岛西部|r
step
    .goto Azuremyst Isle,28.115,62.391
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_瓦克图腾|r 对话
    .turnin 9542 >> 交任务 瓦克图腾
    .accept 9544 >> 接受任务 阿基达的预言
    .target 瓦克图腾
step
    .aura -30448
    +|cRXP_WARN_点掉|r |T132142:0|t[森林之影] |cRXP_WARN_buff|r
step
    #loop
    .goto Azuremyst Isle,27.43,63.24,0
    .goto Azuremyst Isle,27.87,66.78,0
    .goto Azuremyst Isle,25.04,67.67,0
    .goto Azuremyst Isle,27.43,63.24,70,0
    .goto Azuremyst Isle,27.87,66.78,70,0
    .goto Azuremyst Isle,25.04,67.67,70,0
	>>击杀 |cRXP_ENEMY_刺臂熊怪|r、|cRXP_ENEMY_刺臂唤风者|r 和 |cRXP_ENEMY_刺臂巨熊怪|r，拾取它们的 |cRXP_LOOT_刺臂钥匙|r
    >>打开 |cRXP_PICK_刺臂牢笼|r 来解救 |cRXP_FRIENDLY_止松俘虏|r
    .collect 23801,8,9544,1,-1 -- Bristlelimb Key
    .complete 9544,1 --Stillpine Captive Freed (x8)
step
    #loop
    .goto Azuremyst Isle,25.6,73.8,0
    .goto Azuremyst Isle,31.6,70.4,0
    .goto Azuremyst Isle,33.6,60.4,0
    .goto Azuremyst Isle,25.6,73.8,80,0
    .goto Azuremyst Isle,31.6,70.4,80,0
    .goto Azuremyst Isle,33.6,60.4,80,0
    >>击杀 |cRXP_ENEMY_感染的夜行豹幼崽|r
	>>击杀 |cRXP_ENEMY_月痕巨鹿|r，拾取它们的 |cRXP_LOOT_兽皮|r
    .complete 9456,1 --Kill Infected Nightstalker Runt (x8)
    .mob 感染的夜行豹幼崽
	.complete 10324,1 -- Moongraze Buck Hide (6)
    .mob 月痕巨鹿
step
    #completewith next
    >>拾取地上的 the |cRXP_LOOT_远古的圣物|r
    .complete 9523,1 --Collect Ancient Relic (x8)
step
    #loop
    .goto Azuremyst Isle,28.9,79.5,0
    .goto Azuremyst Isle,31.9,76.5,0
    .goto Azuremyst Isle,35.8,79.0,0
    .goto Azuremyst Isle,28.9,79.5,55,0
    .goto Azuremyst Isle,31.9,76.5,55,0
    .goto Azuremyst Isle,35.8,79.0,55,0
    >>击杀 |cRXP_ENEMY_怒鳞纳迦|r、|cRXP_ENEMY_怒鳞侍从|r 和 |cRXP_ENEMY_怒鳞海妖|r，拾取 |T134462:0|t[|cRXP_LOOT_写满符文的石板|r]
    .use 23759 >>|cRXP_WARN_使用|r |T134462:0|t[|cRXP_LOOT_写满符文的石板|r] |cRXP_WARN_来开始任务|r
    .collect 23759,1,9514 --Collect Rune Covered Tablet (x1)
    .accept 9514>> 写满符文的石板
    .complete 9513,1 --Kill Wrathscale Myrmidon (x5)
    .mob 怒鳞侍从
    .complete 9513,2 --Kill Wrathscale Naga (x5)
    .mob 怒鳞纳迦
    .complete 9513,3 --Kill Wrathscale Siren (x5)
    .mob 怒鳞海妖
step
    #label AncientRelics
    #loop
    .goto Azuremyst Isle,28.9,79.5,0
    .goto Azuremyst Isle,31.9,76.5,0
    .goto Azuremyst Isle,35.8,79.0,0
    .goto Azuremyst Isle,28.9,79.5,55,0
    .goto Azuremyst Isle,31.9,76.5,55,0
    .goto Azuremyst Isle,35.8,79.0,55,0
    >>拾取地上的 the |cRXP_LOOT_远古的圣物|r
    .complete 9523,1 --Collect Ancient Relic (x8)
step
    #completewith next
    .subzone 3579 >> 游往叛徒湾
step
    .isOnQuest 9531
    .goto Azuremyst Isle,18.473,84.349
    .cast 30298 >> |cRXP_WARN_在娜迦旗帜处|r使用|cRXP_WARN_ |T132288:0|t[树伪装工具包]|r
    .timer 73,间谍之树剧情表演
    .use 23792
step
    >>|cRXP_WARN_等待剧情演出完成|r
    .complete 9531,1 -- The Traitor Uncovered
step
    +|cRXP_WARN_点掉|r |T132288:0|t[大树伪装] |cRXP_WARN_buff|r
    .aura -30298
step
    .goto Azuremyst Isle,16.587,94.450
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_库雷|r 对话
    .turnin 10428 >> 交任务 失踪的渔夫
    .accept 9527 >> 接受任务 遗体
    .target 库雷
step
    .goto Azuremyst Isle,13.209,89.742
	>>击杀 |cRXP_ENEMY_枭兽|r，拾取它们的 |cRXP_LOOT_库雷的家人的遗体|r
    .complete 9527,1 --Collect Remains of Cowlen's Family (x1)
    .mob 变异的枭兽
    .mob 疯乱的枭兽
    .mob 狂乱的枭兽
step
    .goto Azuremyst Isle,16.587,94.450
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_库雷|r 对话
    .turnin 9527 >> 交任务 遗体
    .target 库雷
step
	#completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    .goto Azuremyst Isle,47.243,69.998
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_考古学家阿达曼特·铁心|r 对话
    .turnin 9523 >> 交任务 贵重物品，小心轻放
    .target 考古学家阿达曼特·铁心
step
    .goto Azuremyst Isle,47.038,70.206
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 对话
    .turnin 9531 >> 交任务 间谍之树
    .accept 9537 >> 接受任务 绳侏儒以法
    .target 海军上将奥德修斯
step
    .goto Azuremyst Isle,47.131,70.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .turnin 9513 >> 交任务 夺回废墟
    .target 女祭司基琳·伊尔蒂娜
step -- to avoid long RP incase turned in in above step
    .goto Azuremyst Isle,47.131,70.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .turnin 9514 >> 交任务 写满符文的石板
    .target 女祭司基琳·伊尔蒂娜
step
    #completewith next
    .goto Azuremyst Isle,46.219,70.983
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_洛根·丹尼尔|r 对话
    .vendor >> |cRXP_WARN_剧情播放期间，出售垃圾物品|r << !Hunter
    >>|cRXP_BUY_在等待剧情结束时，向他购买更多组|r |T132382:0|t[劣质箭]|cRXP_BUY_|r << Hunter
    .collect 2512,1000 << Hunter --Rough Arrow (1000)
    .target 洛根·丹尼尔
step
    .goto Azuremyst Isle,47.131,70.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .accept 9515 >> 接受任务 督军斯雷提兹
    .target 女祭司基琳·伊尔蒂娜
step
    .goto Azuremyst Isle,50.2,70.6,40,0
    .goto Azuremyst Isle,45.7,73.2,40,0
    .goto Azuremyst Isle,50.2,70.6
    >>与在海滩巡逻的 |cRXP_FRIENDLY_工程师欧格林德|r 对话
    >>在简短的剧情结束后击杀 |cRXP_ENEMY_工程师"火花"欧格林德|r，拾取他掉落的 |cRXP_LOOT_叛徒的通讯|r
    .complete 9537,1 --Collect Traitor's Communication (x1)
    .skipgossip 17243
    .timer 18,"叛徒的通讯"剧情
    .unitscan 工程师欧格林德
step
    .goto Azuremyst Isle,47.038,70.206
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 对话
    .turnin 9537 >> 交任务 绳侏儒以法
    .accept 9602 >> 接受任务 邪恶的书信
    .target 海军上将奥德修斯
step << !Hunter
    .isOnQuest 9515
    .goto Azuremyst Isle,26.75,75.84
    .subzone 3569 >> Enter the Tides' Hollow cave (NOT TRANSLATED IN :zhCN YET)
step << !Hunter
    #completewith next
    .goto Azuremyst Isle,26.33,73.79,15 >> 跳下到下层
step << !Hunter
    >>击杀 |cRXP_ENEMY_督军斯雷提兹|r
    .goto Azuremyst Isle,24.98,74.10
    .complete 9515,1 -- Warlord Sriss'tiz slain 1/1
    .mob 督军斯雷提兹
step
    .goto Azuremyst Isle,49.9,51.9
    .xp 9+3070 >> 刷怪达到 3070+/6500xp
step
    #completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    .goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
    .turnin 9453 >> 交任务 找到艾克提恩！
    .turnin 10324 >> 交任务 狩猎月痕鹿
    .target 艾克提恩
step
    .goto Azuremyst Isle,49.367,51.082
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松部族的阿鲁古|r 对话
    .turnin 9544 >> 交任务 阿基达的预言
    .accept 9559 >> 接受任务 止松要塞
    .target 止松部族的阿鲁古
step
    .goto Azuremyst Isle,48.392,51.482
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_丹达尔|r 对话
    .turnin 9473 >> 交任务 备选方案的备选方案
    .target 丹达尔
step
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9456 >> 交任务 清理夜行豹……
    .turnin 9602 >> 交任务 邪恶的书信
    .accept 9623 >> 接受任务 成年
    .target 大主教梅内莱厄斯
step
    .isOnQuest 9612
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9612 >> 交任务 非常感谢！
    .target 大主教梅内莱厄斯
step << Shaman
    .goto Azuremyst Isle,48.053,50.419
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图伦|r 对话
    .accept 9464 >> 接受任务 火焰的召唤
    .trainer >> 训练你的职业技能
    .target 图伦
    .subzoneskip 3576,1
step << Hunter
    .goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
    .accept 9757 >> 接受任务 寻找女猎手凯拉·夜弓
    .trainer >> 训练你的职业技能
    .target 艾克提恩
step << Priest
    .goto Azuremyst Isle,48.603,49.285
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古安|r 对话
    .trainer >> 训练你的职业技能
    .target 古安
    .subzoneskip 3576,1
step << Paladin
    .goto Azuremyst Isle,48.356,49.558
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图拉丝|r 对话
    .trainer >> 训练你的职业技能
    .target 图拉丝
    .subzoneskip 3576,1
step << Mage
    .goto Azuremyst Isle,49.868,49.949
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塞米德|r 对话
    .trainer >> 训练你的职业技能
    .target 塞米德
    .subzoneskip 3576,1
step << Warrior
    .goto Azuremyst Isle,50.023,50.515
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_鲁安达|r 对话
    .trainer >> 训练你的职业技能
    .accept 9582 >> 接受任务 一人之力
    .target 鲁安达
step << Hunter
    .goto Azuremyst Isle,24.183,54.341
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女猎手凯拉·夜弓|r 对话
    .turnin 9757 >> 交任务 寻找女猎手凯拉·夜弓
    .accept 9591 >> 接受任务 驯服野兽
    .target 女猎手凯拉·夜弓
step << Hunter
    .goto Azuremyst Isle,20.7,65.1
	.use 23896 >> |cRXP_WARN_使用|r |T135139:0|t[驯服图腾] |cRXP_WARN_对水中的 |cRXP_ENEMY_带刺的螃蟹|r 使用|r
    .complete 9591,1 --Tame a Barbed Crawler
    .mob 带刺的螃蟹
step << Hunter
    .isOnQuest 9515
    .goto Azuremyst Isle,26.75,75.84
    .subzone 3569 >> Enter the Tides' Hollow cave (NOT TRANSLATED IN :zhCN YET)
step << Hunter
    #completewith next
    .goto Azuremyst Isle,26.33,73.79,15 >> 跳下到下层
step << Hunter
    >>击杀 |cRXP_ENEMY_督军斯雷提兹|r
    .goto Azuremyst Isle,24.98,74.10
    .complete 9515,1 -- Warlord Sriss'tiz slain 1/1
    .mob 督军斯雷提兹
step << Hunter
    .isOnQuest 9515
    .goto Azuremyst Isle,26.75,75.84,10 >> Exit the Tides' Hollow cave (NOT TRANSLATED IN :zhCN YET)
    .subzoneskip 3569,1
step << Hunter
    .goto Azuremyst Isle,24.183,54.341
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女猎手凯拉·夜弓|r 对话
    .turnin 9591 >> 交任务 驯服野兽
    .accept 9592 >> 接受任务 驯服野兽
    .target 女猎手凯拉·夜弓
step
    .goto The Exodar,81.488,51.449
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_象群管理者妥拉留斯|r 对话
    .turnin 9623 >> 交任务 成年
    .accept 9625 >> 接受任务 雷象可不是好玩的！
    .target 象群管理者妥拉留斯
step << Hunter
    .goto Azuremyst Isle,34.56,34.04,60,0
	.goto Azuremyst Isle,41.0,30.4,50,0
    .goto Azuremyst Isle,43.6,26.2
	.use 23897 >> |cRXP_WARN_使用|r |T135139:0|t[驯服图腾]|cRXP_WARN_对|r|cRXP_ENEMY_巨型林地陆行鸟|r
    .complete 9592,1 --Tame a Greater Timberstrider
    .mob 巨型林地陆行鸟
step << Hunter
    .goto Azuremyst Isle,24.183,54.341
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女猎手凯拉·夜弓|r 对话
    .turnin 9592 >> 交任务 驯服野兽
    .accept 9593 >> 接受任务 驯服野兽
    .target 女猎手凯拉·夜弓
step << Hunter
    .goto Azuremyst Isle,35.0,33.9,50,0
    .goto Azuremyst Isle,41.2,28.6
	.use 23898 >> |cRXP_WARN_使用|r |T135139:0|t[驯服图腾]|cRXP_WARN_对|r|cRXP_ENEMY_夜行豹|r
    .complete 9593,1 --Tame a Nightstalker
    .mob 逐夜
step << Hunter
    .goto Azuremyst Isle,24.183,54.341
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女猎手凯拉·夜弓|r 对话
    .turnin 9593 >> 交任务 驯服野兽
    .accept 9675 >> 接受任务 训练野兽
    .target 女猎手凯拉·夜弓
step << Hunter
    .isOnQuest 9675
    .goto Azuremyst Isle,24.6,49.0,20 >>从后门进入埃索达
step << Hunter
	.goto The Exodar,53.79,86.11,30,0
    .goto The Exodar,44.240,86.612
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_甘纳尔|r 对话
    .turnin 9675 >> 交任务 训练野兽
	.trainer >> 训练你的宠物技能
    .target 甘纳尔
step << Hunter
    #completewith next
    .destroy 2512 >> 摧毁你所有的 |T132382:0|t[劣质箭]
step << Hunter
	#completewith next
    .goto The Exodar,47.911,89.801
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾维尔琳|r 对话
    >>|cRXP_BUY_购买6组|r |T132382:0|t[锋利的箭]
    .collect 2515,1200
    .target 艾维尔琳
step << Hunter
	#completewith next
	.goto The Exodar,53.696,78.280,15 >> 沿着坡道向上，前往 |cRXP_FRIENDLY_韩迪尔|r
step << Hunter
    .goto The Exodar,53.362,85.753
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_韩迪尔|r 对话
    .train 202 >> 学习双手剑
    .target 韩迪尔
step << Hunter
	#completewith next
	.goto The Exodar,57.9,61.5,50,0
	.goto The Exodar,53.34,34.07,25,0
	.goto The Exodar,64.0,36.5,20,0
    .goto The Exodar,69.34,32.03,20,0
    .goto The Exodar,74.48,54.09,20 >>跳下去并离开埃索达
	-->> Alternatively you can do a logout skip on any brazier or by floating off of any ledge in the city
	--.link https://www.youtube.com/watch?v=WUWNGyQWJw8 >> |cRXP_WARN_Click here for video reference|r
step
    .goto Azuremyst Isle,44.762,23.906
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫多|r 对话
    .target 莫多
    .accept 9560 >> 接受任务 末日的野兽！
step
    .goto Azuremyst Isle,44.627,23.481
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古尔弗|r 对话
    .target 古尔弗
    .accept 9562 >> 接受任务 鱼人……
step
    .goto Azuremyst Isle,46.685,20.617
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松老酋长|r 对话
    .target 止松老酋长
    .turnin 9559 >> 交任务 止松要塞
step << Hunter
    .goto Azuremyst Isle,54.7,18.4
	.cast 1515 >> |cRXP_WARN_施放|r |T132164:0|t[驯服野兽] |cRXP_WARN_对|r |cRXP_ENEMY_成型的掠食者|r |cRXP_WARN_施放以驯服它|r
    .mob 成型的掠食者
step << Shaman
	#completewith next
	>>击杀 |cRXP_ENEMY_成型的掠食者|r，拾取它们的 |cRXP_LOOT_掠食者兽皮|r
    .complete 9560,1 --Collect Ravager Hide (x8)
    .mob 成型的掠食者
step << Shaman
    .goto Azuremyst Isle,59.534,17.951
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_坦普|r 对话
    .turnin 9464 >> 交任务 火焰的召唤
    .accept 9465 >> 接受任务 火焰的召唤
    .target 坦普
step
    #loop
    .goto Azuremyst Isle,54.6,23.8,0
    .goto Azuremyst Isle,55.6,18.2,0
    .goto Azuremyst Isle,53.0,11.6,0
    .goto Azuremyst Isle,54.6,23.8,70,0
    .goto Azuremyst Isle,55.6,18.2,70,0
    .goto Azuremyst Isle,53.0,11.6,70,0
	>>击杀 |cRXP_ENEMY_成型的掠食者|r，拾取它们的 |cRXP_LOOT_掠食者兽皮|r
    .complete 9560,1 --Collect Ravager Hide (x8)
    .mob 成型的掠食者
step << Warrior
    #completewith next
    .goto Azuremyst Isle,54.021,9.956
    .cast 30767 >> 点击 |cRXP_PICK_掠食者牢笼|r 来释放 |cRXP_ENEMY_死亡掠食者|r
step << Warrior
    .goto Azuremyst Isle,54.084,9.721
    >>击杀 |cRXP_ENEMY_死亡掠食者|r
    .complete 9582,1 --Kill Death Ravager (x1)
    .mob 死亡掠食者
step
    .goto Azuremyst Isle,44.762,23.906
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫多|r 对话
    .target 莫多
    .turnin 9560 >> 交任务 末日的野兽！
step
    .goto Azuremyst Isle,46.904,21.160
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松酋长|r 对话
    .target 止松酋长
    .accept 9573 >> 接受任务 欧莫鲁酋长
step
    .goto Azuremyst Isle,46.685,20.617
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松老酋长|r 对话
    .target 止松老酋长
    .accept 9565 >> 接受任务 搜索止松要塞
step
    .isOnQuest 9573,9565
    .goto Azuremyst Isle,45.391,18.194,20 >> 进入止松要塞洞穴
step
    #completewith next
    .isOnQuest 9573,9565
    .goto Azuremyst Isle,47.453,16.078,10 >> 前往洞穴的上层
step
	.goto Azuremyst Isle,47.394,14.121
    >>击杀 |cRXP_ENEMY_欧莫鲁酋长|r
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r << !Shaman
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r，拾取它们的 |cRXP_LOOT_仪式火炬|r << Shaman
    .complete 9573,1 --Kill Chieftain Oomooroo (x1)
    .mob 欧莫鲁酋长
    .complete 9573,2 --Kill Crazed Wildkin (x9)
    .disablecheckbox
    .mob 发狂的野枭兽
    .complete 9465,1 << Shaman --Collect Ritual Torch (x1)
    .disablecheckbox
    .mob 发狂的野枭兽
step
    #completewith next
    .isOnQuest 9573,9565
    .goto Azuremyst Isle,48.26,13.78,10 >> 跳下去并前往洞穴深处
step
    #completewith next
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r << !Shaman
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r，拾取它们的 |cRXP_LOOT_仪式火炬|r << Shaman
    .complete 9573,2 --Kill Crazed Wildkin (x9)
    .complete 9465,1 << Shaman --Collect Ritual Torch (x1)
    .mob 发狂的野枭兽
step
    .goto Azuremyst Isle,50.632,11.544
    >>点击 |cRXP_PICK_血色水晶|r
    >>|cRXP_WARN_尽量避免击杀 |cRXP_ENEMY_库肯|r，因为你很快还需要击杀他|r
    .turnin 9565 >> 交任务 搜索止松要塞
    .accept 9566 >> 接受任务 血水晶
step
    #completewith next
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r << !Shaman
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r，拾取它们的 |cRXP_LOOT_仪式火炬|r << Shaman
    >>|cRXP_WARN_You will finish this shortly if you haven't yet|r (NOT TRANSLATED IN :zhCN YET)
    .complete 9573,2 --Kill Crazed Wildkin (x9)
    .complete 9465,1 << Shaman --Collect Ritual Torch (x1)
    .mob 发狂的野枭兽
step
    .isOnQuest 9573,9566
    .goto Azuremyst Isle,45.391,18.194,12 >> 离开洞穴
step
    .goto Azuremyst Isle,46.685,20.617
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松老酋长|r 对话
    .target 止松老酋长
    .turnin 9566 >> 交任务 血水晶
step
    #optional
    .isQuestComplete 9573
    .goto Azuremyst Isle,46.904,21.160
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松酋长|r 对话
    .target 止松酋长
    .turnin 9573 >> 交任务 欧莫鲁酋长
step
    .goto Azuremyst Isle,46.972,22.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_启示者库尔兹|r 对话
    .target 启示者库尔兹
    .accept 9570 >> 接受任务 可怕的库肯
step
	.goto Azuremyst Isle,46.964,22.011
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_帕卡特·钢皮|r 对话
    .vendor >> |cRXP_BUY_购买一个|r |T133634:0|t[棕色小包]
    .target 帕卡特·钢皮
    .subzoneskip 3572,1
step
    .isOnQuest 9570,9573
    .goto Azuremyst Isle,45.391,18.194,20 >> 再次进入止松要塞洞穴
step
    #completewith next
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r << !Shaman
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r，拾取它们的 |cRXP_LOOT_仪式火炬|r << Shaman
    .complete 9573,2 --Kill Crazed Wildkin (x9)
    .complete 9465,1 << Shaman --Collect Ritual Torch (x1)
    .mob 发狂的野枭兽
step
    .goto Azuremyst Isle,48.26,13.78,10,0
    .goto Azuremyst Isle,49.9,12.8
	>>击杀 |cRXP_ENEMY_库肯|r，拾取他的 |cRXP_LOOT_毛皮|r
    .complete 9570,1 --Collect The Kurken's Hide (x1)
    .mob 库肯
step
    .goto Azuremyst Isle,47.394,14.121
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r << !Shaman
    >>击杀 |cRXP_ENEMY_发狂的野枭兽|r，拾取它们的 |cRXP_LOOT_仪式火炬|r << Shaman
    .complete 9573,2 --Kill Crazed Wildkin (x9)
    .complete 9465,1 << Shaman --Collect Ritual Torch (x1)
    .mob 发狂的野枭兽
step
    .isQuestComplete 9573
    .goto Azuremyst Isle,46.904,21.160
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松酋长|r 对话
    .target 止松酋长
    .turnin 9573 >> 交任务 欧莫鲁酋长
step
    .goto Azuremyst Isle,46.972,22.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_启示者库尔兹|r 对话
    .target 启示者库尔兹
    .turnin 9570 >> 交任务 可怕的库肯
    .accept 9571 >> 接受任务 库肯的毛皮
step << Shaman
    .goto Azuremyst Isle,46.685,20.617
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松老酋长|r 对话
    .accept 9622 >> 接受任务 警告你的人民
    .target 止松老酋长
step
	#label end
    .goto Azuremyst Isle,44.762,23.906
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫多|r 对话
    .target 莫多
    .turnin 9571 >> 交任务 库肯的毛皮
step << Shaman
    .goto Azuremyst Isle,59.534,17.951
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_坦普|r 对话
    .turnin 9465 >> 交任务 火焰的召唤
    .accept 9467 >> 接受任务 火焰的召唤
    .target 坦普
step << Shaman
    #completewith next
	.hs >> 炉石返回碧蓝岗哨，秘血岛
step << Shaman
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9622 >> 交任务 警告你的人民
    .target 大主教梅内莱厄斯
step << Shaman
    #completewith Wickerman
    .subzone 3639 >> 前往 银雾岛
step << Shaman
    #completewith Wickerman
    .use 24336 >>打开 |T133655:0|t[防火背包]，获取 |T135432:0|t[仪祭火炬]
    .complete 9467,2 --Collect Ritual Torch (x1)
step << Shaman
    #completewith Wickerman
    .goto Azuremyst Isle,11.442,82.273
    .cast 30212 >>点击|cRXP_PICK_火人像|r 以召唤 |cRXP_ENEMY_赫图尔|r
step << Shaman
    #label Wickerman
    .goto Azuremyst Isle,11.442,82.273
    >>击杀 |cRXP_ENEMY_赫图尔|r。拾取他的 |cRXP_LOOT_灰烬|r
    .complete 9467,1 --Collect Hauteur's Ashes (x1)
    .mob 赫图尔
step << Shaman
    #completewith next
    .cast 31613 >>|cRXP_WARN_使用|r |T134337:0|t[回归宝珠] |cRXP_WARN_传送回灰烬林地|r
    .use 24335
step << Shaman
    .goto Azuremyst Isle,59.534,17.951
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_坦普|r 对话
    .turnin 9467 >> 交任务 火焰的召唤
    .accept 9468 >> 接受任务 火焰的召唤
    .target 坦普
step
    #completewith next
    >>击杀 |cRXP_ENEMY_沙鳞鱼人|r, |cRXP_ENEMY_沙鳞先知|r 和 |cRXP_ENEMY_沙鳞猎手|r。拾取他们的 |cRXP_LOOT_止松谷物|r
    .complete 9562,1 --Collect Stillpine Grain (x5)
    .mob 沙鳞鱼人
    .mob 沙鳞先知
    .mob 沙鳞猎手
step
    #loop
    .goto Azuremyst Isle,33.7,26.1,0
    .goto Azuremyst Isle,34.6,25.0,0
    .goto Azuremyst Isle,34.6,20.2,0
    .goto Azuremyst Isle,34.6,15.2,0
    .goto Azuremyst Isle,33.7,26.1,50,0
    .goto Azuremyst Isle,34.6,25.0,50,0
    .goto Azuremyst Isle,34.6,20.2,50,0
    .goto Azuremyst Isle,34.6,15.2,50,0
    >>击杀 |cRXP_ENEMY_咕噜咕拉|r. 拾取以获得|T134350:0|t[|cRXP_LOOT_古尔弗的尊严|r]
    .use 23850 >> |cRXP_WARN_使用|r |T134350:0|t[|cRXP_LOOT_古尔弗的尊严|r] |cRXP_WARN_开始任务|r
    >>|cRXP_ENEMY_咕噜咕拉|r |cRXP_WARN_沿海岸巡逻|r
	.collect 23850,1,9564,1 --Gurf's Dignity (1)
    .accept 9564 >> 接受任务 古尔弗的尊严
	.unitscan 咕噜咕拉
step
    #loop
    .goto Azuremyst Isle,33.7,26.1,0
    .goto Azuremyst Isle,34.6,25.0,0
    .goto Azuremyst Isle,34.6,20.2,0
    .goto Azuremyst Isle,34.6,15.2,0
    .goto Azuremyst Isle,33.7,26.1,50,0
    .goto Azuremyst Isle,34.6,25.0,50,0
    .goto Azuremyst Isle,34.6,20.2,50,0
    .goto Azuremyst Isle,34.6,15.2,50,0
    >>击杀 |cRXP_ENEMY_沙鳞鱼人|r, |cRXP_ENEMY_沙鳞先知|r 和 |cRXP_ENEMY_沙鳞猎手|r。拾取他们的 |cRXP_LOOT_止松谷物|r
    .complete 9562,1 --Collect Stillpine Grain (x5)
    .mob 沙鳞鱼人
    .mob 沙鳞先知
    .mob 沙鳞猎手
step
    .goto Bloodmyst Isle,63.5,88.8
	.zone Bloodmyst Isle >> 前往 秘血岛
]])

RXPGuides.RegisterGuide([[
#tbc
#wotlk
#version 7
#group RestedXP 燃烧的远征 练级指南 (联盟)
<< Alliance
#name 12-20 秘蓝岛 (德莱尼)
#subgroup RestedXP 联盟 1-20 级
#defaultfor Draenei
#next 20-21 黑海岸 (德莱尼);21-23 灰谷 (德莱尼)

step
    .goto Bloodmyst Isle,63.426,88.787
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_奥纳尔|r 对话
    .target 奥纳尔
    .accept 9624 >> 接受任务 美味的点心
step
    .isOnQuest 9625
    .goto Bloodmyst Isle,63.036,87.905
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_雷象管理者沃克汉|r 对话
    .target 雷象管理者沃克汉
    .turnin 9625 >> 交任务 雷象可不是好玩的！
    .accept 9634 >> 接受任务 大战异型掠夺者
step
    .goto Bloodmyst Isle,63.036,87.905
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_雷象管理者沃克汉|r 对话
    .target 雷象管理者沃克汉
    .accept 9634 >> 接受任务 大战异型掠夺者
step
    #loop
    .goto Bloodmyst Isle,57.5,86.5,0
    .goto Bloodmyst Isle,63.5,83.8,0
    .goto Bloodmyst Isle,72.7,80.9,0
	.goto Bloodmyst Isle,60.1,91.6,60,0
    .goto Bloodmyst Isle,57.5,86.5,60,0
    .goto Bloodmyst Isle,59.7,85.8,60,0
    .goto Bloodmyst Isle,63.5,83.8,60,0
    .goto Bloodmyst Isle,67.7,87.6,60,0
    .goto Bloodmyst Isle,72.7,80.9,60,0
    .xp 12-2000 >> |cRXP_WARN_练怪直到距离 12 级还有2000 经验 (6800/8800)|r
    >>击杀 |cRXP_ENEMY_秘血幼崽|r
	>>拾取地上的 |cRXP_LOOT_沙梨|r
    >>|cRXP_WARN_满足经验要求后，请继续跟随指南|r
    .complete 9634,1 --Kill Bloodmyst Hatchling (x10)
    .mob 秘血幼崽
    .disablecheckbox
    .complete 9624,1 --Collect Sand Pear (x10)
    .disablecheckbox
step
	#completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    .goto Bloodmyst Isle,55.843,59.807
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托菲尔·罗阿|r 对话
    .target 托菲尔·罗阿
    .accept 9603 >> 接受任务 床铺，绷带，以及更多
step
    .goto Bloodmyst Isle,55.843,59.807
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托菲尔·罗阿|r 对话
    .target 托菲尔·罗阿
    >>|cRXP_BUY_从他那里|r|cRXP_BUY_购买最多 40 条|r |T133918:0|t[长嘴泥鳅] << Warrior
    >>|cRXP_BUY_从他那里购买40杯|r |T132815:0|t[冰镇牛奶] |cRXP_BUY_能买多少买多少|r << Mage/Priest/Hunter
    >>|cRXP_BUY_从他那里|r购买40瓶|cRXP_BUY_ |T132815:0|t[冰镇牛奶] |r和|cRXP_BUY_ |T133918:0|t[新鲜的长嘴泥鳅] |r << Paladin/Shaman
    .collect 1179,35 << !Warrior !Rogue --Ice Cold Milk (35)
    .collect 4592,35 --Longjaw Mud Snapper (35)
    .subzoneskip 3584,1
step
    .goto Bloodmyst Isle,55.843,59.807
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托菲尔·罗阿|r 对话
    .target 托菲尔·罗阿
    .home >> 将你的炉石绑定到秘血岗哨
    .subzoneskip 3584,1
step
    .goto Bloodmyst Isle,56.428,56.817
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_玛特帕尔姆|r 对话
    .target 玛特帕尔姆
    .accept 9648 >> 接受任务 玛特帕尔姆蘑菇展
step
    #completewith next
    .goto Bloodmyst Isle,57.680,53.876
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .target 兰度
    .turnin 9603 >> 交任务 床铺，绷带，以及更多
step
    .goto Bloodmyst Isle,57.680,53.876
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .target 兰度
    .fp Blood Watch>> 获取秘血岗哨的飞行路径
    .subzoneskip 3584,1
step
    #optional
    .goto Bloodmyst Isle,57.680,53.876
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .target 兰度
    .turnin 9603 >> 交任务 床铺，绷带，以及更多
step
    .goto Bloodmyst Isle,52.684,53.214
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_主教埃德门图斯|r 对话
    .accept 9693 >> 接受任务 阿古斯的意义
    .target 主教埃德门图斯
step
    .goto Bloodmyst Isle,52.588,53.207
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先行官米库拉斯|r 对话
    .accept 9581 >> 接受任务 研究水晶
    .target 先行官米库拉斯
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .turnin 9693 >> 交任务 阿古斯的意义
    .accept 9694 >> 接受任务 秘血岗哨
step
    #loop
    .goto Bloodmyst Isle,47.0,51.6,0
    .goto Bloodmyst Isle,50.8,47.0,0
    .goto Bloodmyst Isle,47.4,43.8,0
    .goto Bloodmyst Isle,46.7,48.3,50,0
    .goto Bloodmyst Isle,50.8,47.0,50,0
    .goto Bloodmyst Isle,47.4,43.8,50,0
	>>击杀 |cRXP_ENEMY_炎鹰间谍|r
    >>|cRXP_WARN_小心，|cRXP_ENEMY_炎鹰间谍|r 在该等级非常强大|r
    .complete 9694,1 --Kill Sunhawk Spy (x10)
    .mob 炎鹰间谍
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .turnin 9694 >> 交任务 秘血岗哨
step
    .goto Bloodmyst Isle,53.245,57.741
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫莱|r 对话
    .target 莫莱
    .accept 9629 >> 接受任务 研究鱼人
step
	#completewith next
	>>拾取地上的 |cRXP_LOOT_血蘑菇|r
    >>|cRXP_WARN_这些会在秘血岛各处出现|r
    .complete 9648,2 --Collect Blood Mushroom (x1)
step
    #loop
    .goto Bloodmyst Isle,57.65,74.32,0
    .goto Bloodmyst Isle,56.51,79.24,0
    .goto Bloodmyst Isle,63.74,64.79,0
    .goto Bloodmyst Isle,57.65,74.32,40,0
    .goto Bloodmyst Isle,56.51,79.24,40,0
    .goto Bloodmyst Isle,63.74,64.79,40,0
    >>击杀一只 |cRXP_ENEMY_臭角刺鱼|r，拾取地上的物品以获得 |cRXP_LOOT_水生臭角菇|r
    >>|cRXP_WARN_你也可以在水下拾取 |cRXP_LOOT_水生臭角菇|r|r
	.complete 9648,1 -- Loot an Aquatic Stinkhorn (x1)
    .mob 臭角刺鱼
step
	.goto Bloodmyst Isle,58.175,83.415
	.use 23875 >>|cRXP_WARN_使用|r |T134709:0|t[水晶矿锄] |cRXP_WARN_对|r |cRXP_PICK_坠毁点水晶|r 使用
    .complete 9581,1 --Collect Impact Site Crystal Sample (x1)
step
    #loop
    .goto Bloodmyst Isle,57.5,86.5,0
    .goto Bloodmyst Isle,63.5,83.8,0
    .goto Bloodmyst Isle,72.7,80.9,0
	.goto Bloodmyst Isle,60.1,91.6,60,0
    .goto Bloodmyst Isle,57.5,86.5,60,0
    .goto Bloodmyst Isle,59.7,85.8,60,0
    .goto Bloodmyst Isle,63.5,83.8,60,0
    .goto Bloodmyst Isle,67.7,87.6,60,0
    .goto Bloodmyst Isle,72.7,80.9,60,0
    .xp 12-2000 >> |cRXP_WARN_练怪直到距离 12 级还有2000 经验 (6800/8800)|r
    >>击杀 |cRXP_ENEMY_秘血幼崽|r
	>>拾取地上的 |cRXP_LOOT_沙梨|r
    >>|cRXP_WARN_满足经验要求后，请继续跟随指南|r
    .complete 9634,1 --Kill Bloodmyst Hatchling (x10)
    .mob 秘血幼崽
    .disablecheckbox
    .complete 9624,1 --Collect Sand Pear (x10)
    .disablecheckbox
step
	#completewith grind3800
	>>拾取地上的 |cRXP_LOOT_沙梨|r
    >>|cRXP_WARN_它们不易被发现，查看树周围|r
    .complete 9624,1 --Collect Sand Pear (x10)
step
    #loop
    .goto Bloodmyst Isle,57.5,86.5,0
    .goto Bloodmyst Isle,63.5,83.8,0
    .goto Bloodmyst Isle,72.7,80.9,0
	.goto Bloodmyst Isle,60.1,91.6,60,0
    .goto Bloodmyst Isle,57.5,86.5,60,0
    .goto Bloodmyst Isle,59.7,85.8,60,0
    .goto Bloodmyst Isle,63.5,83.8,60,0
    .goto Bloodmyst Isle,67.7,87.6,60,0
    .goto Bloodmyst Isle,72.7,80.9,60,0
    >>击杀 |cRXP_ENEMY_秘血幼崽|r
    .complete 9634,1 --Kill Bloodmyst Hatchling (x10)
    .mob 秘血幼崽
step
	#label grind3800
    #loop
    .goto Bloodmyst Isle,57.5,86.5,0
    .goto Bloodmyst Isle,63.5,83.8,0
    .goto Bloodmyst Isle,72.7,80.9,0
	.goto Bloodmyst Isle,60.1,91.6,60,0
    .goto Bloodmyst Isle,57.5,86.5,60,0
    .goto Bloodmyst Isle,59.7,85.8,60,0
    .goto Bloodmyst Isle,63.5,83.8,60,0
    .goto Bloodmyst Isle,67.7,87.6,60,0
    .goto Bloodmyst Isle,72.7,80.9,60,0
	.xp 12+3880 >> 一直刷怪 ，直到你积累了 3880经验，在12级 (3880+/9800)
    .mob 秘血幼崽
step
    #loop
    .goto Bloodmyst Isle,57.5,86.5,0
    .goto Bloodmyst Isle,63.5,83.8,0
    .goto Bloodmyst Isle,72.7,80.9,0
	.goto Bloodmyst Isle,60.1,91.6,60,0
    .goto Bloodmyst Isle,57.5,86.5,60,0
    .goto Bloodmyst Isle,59.7,85.8,60,0
    .goto Bloodmyst Isle,63.5,83.8,60,0
    .goto Bloodmyst Isle,67.7,87.6,60,0
    .goto Bloodmyst Isle,72.7,80.9,60,0
	>>拾取地上的 |cRXP_LOOT_沙梨|r
    >>|cRXP_WARN_它们不易被发现，查看树周围|r
    .complete 9624,1 --Collect Sand Pear (x10)
step
    .goto Bloodmyst Isle,63.426,88.787
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_奥纳尔|r 对话
    .target 奥纳尔
    .turnin 9624 >> 交任务 美味的点心
step
    .goto Bloodmyst Isle,63.036,87.905
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_雷象管理者沃克汉|r 对话
    .target 雷象管理者沃克汉
    .turnin 9634 >> 交任务 大战异型掠夺者
step
    .goto Bloodmyst Isle,62.998,87.541
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯希尔|r 对话
    .accept 9663 >> 接受任务 凯希尔的信使
    .target 凯希尔
step
    #completewith next
    .goto Azuremyst Isle,42.18,2.88,20,0
    .goto Azuremyst Isle,43.23,11.58,70,0
    .goto Azuremyst Isle,50.99,13.09,70,0
    .goto Azuremyst Isle,49.40,23.09,80,0
    .goto Azuremyst Isle,46.685,20.617
	.subzone 3572 >> |cRXP_WARN_不要与任何怪物交战、攻击或施放任何法术，否则你会被强制下坐骑！如果被身后攻击触发迷惑，同样也会被强制下坐骑！|r
    *|cRXP_WARN_这也是一个限时任务！你有 15 分钟来完成并提交它|r
    *|cRXP_WARN_沿着道路向南前进，以安全抵达 |cRXP_FRIENDLY_止松老酋长|r|r
step
    .goto Azuremyst Isle,46.685,20.617
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松老酋长|r 对话
    .accept 9622 >> 接受任务 警告你的人民 << !Shaman
    .complete 9663,1 --High Chief Stillpine Warned
    .target 止松老酋长
step
    .goto Azuremyst Isle,44.627,23.481
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古尔弗|r 对话
    .turnin 9564 >> 交任务 古尔弗的尊严
    .turnin 9562 >> 交任务 鱼人……
    .target 古尔弗
step
    .goto Azuremyst Isle,49.25,49.53
    .isOnQuest 9663
    .subzone 3576 >> |cRXP_WARN_继续沿路南行，前往碧蓝岗哨|r
step << Mage
    .goto Azuremyst Isle,49.868,49.949
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塞米德|r 对话
    .trainer >> 训练你的职业技能
    .target 塞米德
    .subzoneskip 3576,1
step << Warrior
    .goto Azuremyst Isle,50.023,50.515
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_鲁安达|r 对话
    .turnin 9582 >> 交任务 一人之力
    .accept 10350 >> 接受任务 贝霍玛特
    .trainer >> 训练你的职业技能
    .target 鲁安达
    .subzoneskip 3576,1
step << Hunter
    .goto Azuremyst Isle,49.780,51.938
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_艾克提恩|r 对话
    .trainer >> 训练你的职业技能
    .target 艾克提恩
    .subzoneskip 3576,1
step << Priest
    .goto Azuremyst Isle,48.603,49.285
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古安|r 对话
    .trainer >> 训练你的职业技能
    .target 古安
    .subzoneskip 3576,1
step << Shaman
    .goto Azuremyst Isle,48.053,50.419
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_图伦|r 对话
    .turnin 9468 >> 交任务 火焰的召唤
    .accept 9461 >> 接受任务 火焰的召唤
    .trainer >> 训练你的职业技能
    .target 图伦
    .subzoneskip 3576,1
step
    #optional
    .use 23910 >> |cRXP_WARN_使用 |r|T133473:0|t[血精灵通讯器] |cRXP_WARN_来开始任务|r
    .accept 9616 >> 接受任务 强盗！
    .itemcount 23910,1
step
    #optional
    .isOnQuest 9616
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9616 >> 交任务 强盗！
    .target 大主教梅内莱厄斯
step
    #optional
    .isOnQuest 9612
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9612 >> 交任务 非常感谢！
    .target 大主教梅内莱厄斯
step
    .goto Azuremyst Isle,47.110,50.603
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大主教梅内莱厄斯|r 对话
    .turnin 9622 >> 交任务 警告你的人民 << !Shaman
    .complete 9663,2 --Exarch Menelaous Warned
    .target 大主教梅内莱厄斯
step
    #completewith next
    .isOnQuest 9663
    .subzone 3573 >> |cRXP_WARN_继续沿路南行，前往奥德修斯营地|r
step
    .goto Azuremyst Isle,47.038,70.206
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_海军上将奥德修斯|r 对话
    .complete 9663,3 --Admiral Odesyus Warned
    .target 海军上将奥德修斯
step
    .goto Azuremyst Isle,47.131,70.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .turnin 9515 >> 交任务 督军斯雷提兹
    .target 女祭司基琳·伊尔蒂娜
step << Paladin
    #completewith next
    .goto Azuremyst Isle,24.6,49.0,20,0
    .goto The Exodar,42.90,67.67,15 >>从后门进入埃索达
step << Paladin
    .goto The Exodar,38.367,82.564
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .target 约尔
    .accept 9598 >>接受任务 救赎
    .turnin 9598 >>交任务救赎
    .accept 9600 >>接受任务救赎
	.trainer >> 训练你的职业技能
step
    .isOnQuest 9581,9663
	.hs >> 炉石到血环堡
    .cooldown item,6948,>2,1
step
	.isOnQuest 9581,9663
    .goto The Exodar,68.351,63.490
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯泰法努斯|r 对话
    .fly Blood Watch >> 飞往血环堡
    .target 斯泰法努斯
    .zoneskip Bloodmyst Isle
step
    .goto Bloodmyst Isle,55.083,57.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官艾蕾希亚|r 对话
    .accept 9567 >> 接受任务 知己知彼
    .target 守备官艾蕾希亚
step
    .goto Bloodmyst Isle,52.588,53.207
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先行官米库拉斯|r 对话
    .turnin 9581 >> 交任务 研究水晶
    .accept 9620 >> 接受任务 失踪的测量小组
    .target 先行官米库拉斯
step
    .goto Bloodmyst Isle,62.998,87.541
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯希尔|r 对话
    .turnin 9663 >> 交任务 凯希尔的信使
    .accept 9666 >> 接受任务 展示力量
    .target 凯希尔
step
    .goto Bloodmyst Isle,68.257,80.999
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松公主|r 对话
    .accept 9667 >> 接受任务 拯救止松公主
    .target 止松公主
step
	#completewith next
	>>拾取地上的 |cRXP_LOOT_致命孢子簇|r
    >>|cRXP_WARN_它看起来像是在娜迦遗迹附近可以找到的小型蓝色蘑菇|r
    .complete 9648,3 --Collect Ruinous Polyspore (x1)
step
    .goto Bloodmyst Isle,67.35,67.99,40,0
    .goto Bloodmyst Isle,68.83,68.09
	>>击杀 |cRXP_ENEMY_克希兹领主|r
    .use 24084 >> |cRXP_WARN_在他的尸体上|r使用 |cRXP_WARN_|T132484:0|t[德莱尼旗帜]|r
    .complete 9666,1 -- Kill Lord Xiz (1)
    .mob 克希兹领主
    .complete 9666,2 --Declaration of Power (x1)
step
    #loop
    .goto Bloodmyst Isle,67.91,66.45,0
    .goto Bloodmyst Isle,66.51,69.90,0
    .goto Bloodmyst Isle,68.58,65.18,0
    .goto Bloodmyst Isle,68.71,71.59,0
    .goto Bloodmyst Isle,67.91,66.45,8,0
    .goto Bloodmyst Isle,66.51,69.90,8,0
    .goto Bloodmyst Isle,68.58,65.18,8,0
    .goto Bloodmyst Isle,68.71,71.59,8,0
	>>拾取地上的 |cRXP_LOOT_致命孢子簇|r
    >>|cRXP_WARN_它看起来像是在娜迦遗迹附近可以找到的小型蓝色蘑菇|r
    .complete 9648,3 --Collect Ruinous Polyspore (x1)
step << Paladin
    #completewith next
    .goto Bloodmyst Isle,65.291,77.547
	.use 6866 >>|cRXP_WARN_对 |r幼年熊怪萨满祭司|cRXP_WARN_ |r使用|cRXP_FRIENDLY_ |T133439:0|t[生命符记]|r
    .complete 9600,1 --Young Furbolg Shaman Resurrected (1)
    .target 年轻的熊怪萨满祭司
step
    .goto Bloodmyst Isle,64.2,76.8
    >>击杀 |cRXP_ENEMY_刺臂战士|r 和 |cRXP_ENEMY_刺臂萨满祭司|r，直到 |cRXP_ENEMY_刺臂酋长|r 刷新
    >>击杀 |cRXP_ENEMY_刺臂酋长|r。拾取他的 |cRXP_LOOT_酋长的钥匙|r
    .collect 24099,1,9667,1 --Collect The High Chief's Key (x1)
    .mob 刺臂战士
    .mob 刺臂萨满祭司
    .unitscan 刺臂酋长
step << Paladin
    .goto Bloodmyst Isle,65.291,77.547
	.use 6866 >>|cRXP_WARN_对 |r幼年熊怪萨满祭司|cRXP_WARN_ |r使用|cRXP_FRIENDLY_ |T133439:0|t[生命符记]|r
    .complete 9600,1 --Young Furbolg Shaman Resurrected (1)
    .target 年轻的熊怪萨满祭司
step
    .goto Bloodmyst Isle,68.257,80.999
    >>点击 |cRXP_PICK_止松公主的牢笼|r
    .complete 9667,1 --Free Saving Princess Stillpine
    .itemcount 24099,1
step
    .goto Bloodmyst Isle,62.998,87.541
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯希尔|r 对话
    .turnin 9666 >> 交任务 展示力量
    .accept 9668 >> 接受任务 向主教埃德门图斯报告
    .target 凯希尔
step
	#completewith next
	.use 23995 >>|cRXP_WARN_使用|r |T135619:0|t[鱼人标记枪]|cRXP_WARN_对|r|cRXP_ENEMY_黑沙斥候|r 使用
    >>|cRXP_WARN_不要击杀|r |cRXP_ENEMY_黑沙斥候|r
    .complete 9629,1 --Blacksilt Scouts Tagged (x6)
    .target 黑沙斥候
step
    #loop
    .goto Bloodmyst Isle,49.26,94.16,0
    .goto Bloodmyst Isle,43.70,94.43,0
    .goto Bloodmyst Isle,36.82,95.03,0
    .goto Bloodmyst Isle,49.26,94.16,70,0
    .goto Bloodmyst Isle,43.70,94.43,70,0
    .goto Bloodmyst Isle,36.82,95.03,70,0
	>>击杀 |cRXP_ENEMY_克鲁芬|r，拾取 |T133339:0|t[|cRXP_LOOT_红色水晶坠饰|r]
    .use 23870 >>|cRXP_WARN_使用|r |T133339:0|t[|cRXP_LOOT_红色水晶坠饰|r] |cRXP_WARN_来开始该任务|r
    >>|cRXP_ENEMY_克鲁芬|r |cRXP_WARN_会沿着海岸线巡逻|r
	.collect 23870,1,9576,1 --Red Crystal Pendant (1)
    .accept 9576 >> 接受任务 克鲁芬的项链
	.unitscan 克鲁芬
step
    #loop
    .goto Bloodmyst Isle,49.26,94.16,0
    .goto Bloodmyst Isle,43.70,94.43,0
    .goto Bloodmyst Isle,36.82,95.03,0
    .goto Bloodmyst Isle,49.26,94.16,70,0
    .goto Bloodmyst Isle,43.70,94.43,70,0
    .goto Bloodmyst Isle,36.82,95.03,70,0
	.use 23995 >>|cRXP_WARN_使用|r |T135619:0|t[鱼人标记枪]|cRXP_WARN_对|r|cRXP_ENEMY_黑沙斥候|r 使用
    >>|cRXP_WARN_不要击杀|r |cRXP_ENEMY_黑沙斥候|r
    .complete 9629,1 --Blacksilt Scouts Tagged (x6)
    .target 黑沙斥候
step
	#completewith FelConeFungus
	>>拾取地上的 |cRXP_LOOT_血蘑菇|r
    >>|cRXP_WARN_这些会在秘血岛各处出现|r
    .complete 9648,2 --Collect Blood Mushroom (x1)
step
    #completewith SatyrFelsworn
	>>拾取地上的 |cRXP_LOOT_邪锥蘑菇|r
    .complete 9648,4 --Collect Fel Cone Fungus (x1)
step
    #completewith next
    >>击杀 |cRXP_ENEMY_瑟拉克|r，拾取 |T134518:0|t[|cRXP_LOOT_瑟拉克的护甲块|r]
    .use 23900 >> |cRXP_WARN_使用|r |T134518:0|t[|cRXP_LOOT_瑟拉克的护甲块|r] |cRXP_WARN_来开始该任务|r
    .collect 23900,1,9594,1 --Tzerak's Armor Plate
    .accept 9594 >> 接受任务 军团的徽记
    .unitscan 瑟拉克
step
    .goto Bloodmyst Isle,36.498,71.338
	>>点击祭坛墙上的 |cRXP_PICK_纳兹维安纪念碑铭文|r，拾取其中的 |cRXP_LOOT_纳兹维安纪念碑铭文|r
    .complete 9567,1 --Collect Nazzivus Monument Glyph (x1)
step
    .goto Bloodmyst Isle,36.498,71.338,30,0
    .goto Bloodmyst Isle,38.416,82.003
    >>击杀 |cRXP_ENEMY_瑟拉克|r，拾取 |T134518:0|t[|cRXP_LOOT_瑟拉克的护甲块|r]
    .use 23900 >> |cRXP_WARN_使用|r |T134518:0|t[|cRXP_LOOT_瑟拉克的护甲块|r] |cRXP_WARN_来开始该任务|r
    >>|cRXP_WARN_如果你没有看到他在营地中巡逻，请在南侧地面上的紫色符文处等待他刷新。他可能需要 3-6 分钟才会出现|r
    .collect 23900,1,9594,1 --Tzerak's Armor Plate
    .accept 9594 >> 接受任务 军团的徽记
    .unitscan 瑟拉克
step
    .isOnQuest 9594
    #label SatyrFelsworn
    #loop
    .goto Bloodmyst Isle,36.23,80.94,0
    .goto Bloodmyst Isle,37.67,76.66,0
    .goto Bloodmyst Isle,40.49,78.92,0
    .goto Bloodmyst Isle,38.72,73.66,0
    .goto Bloodmyst Isle,33.68,72.42,0
    .goto Bloodmyst Isle,36.23,80.94,70,0
    .goto Bloodmyst Isle,37.67,76.66,70,0
    .goto Bloodmyst Isle,40.49,78.92,70,0
    .goto Bloodmyst Isle,38.72,73.66,70,0
    .goto Bloodmyst Isle,33.68,72.42,70,0
	>>击杀 |cRXP_ENEMY_纳兹维安萨特|r 和 |cRXP_ENEMY_纳兹维安魔誓者|r
    >>|cRXP_WARN_如果你没有看到 |cRXP_ENEMY_萨特|r 或 |cRXP_ENEMY_魔誓者|r，你可能需要击杀 |cRXP_ENEMY_纳兹维安盗贼|r 来促使它们重新刷新|r
    .complete 9594,1 --Kill Nazzivus Satyr (x8)
    .mob 纳兹维安萨特
    .complete 9594,2 --Kill Nazzivus Felsworn (x8)
    .mob 纳兹维安魔誓者
step
    #label FelConeFungus
    .goto Bloodmyst Isle,36.9,81.7,0
    .goto Bloodmyst Isle,32.2,81.3,0
    .goto Bloodmyst Isle,37.4,76.8,0
    .goto Bloodmyst Isle,44.5,82.5,0
    .goto Bloodmyst Isle,44.6,86.0,0
    .goto Bloodmyst Isle,36.9,81.7,30,0
    .goto Bloodmyst Isle,32.2,81.3,30,0
    .goto Bloodmyst Isle,37.4,76.8,30,0
    .goto Bloodmyst Isle,44.5,82.5,30,0
    .goto Bloodmyst Isle,44.6,86.0,30,0
	>>拾取地上的 |cRXP_LOOT_邪锥蘑菇|r
    .complete 9648,4 --Collect Fel Cone Fungus (x1)
step
    #loop
    .goto Bloodmyst Isle,38.9,79.4,0
    .goto Bloodmyst Isle,42.1,71.7,0
    .goto Bloodmyst Isle,46.8,77.0,0
    .goto Bloodmyst Isle,45.7,86.9,0
    .goto Bloodmyst Isle,49.7,86.2,0
    .goto Bloodmyst Isle,53.5,75.7,0
    .goto Bloodmyst Isle,48.5,66.7,0
    .goto Bloodmyst Isle,54.1,67.6,0
    .goto Bloodmyst Isle,58.9,61.8,0
    .goto Bloodmyst Isle,38.9,79.4,15,0
    .goto Bloodmyst Isle,42.1,71.7,15,0
    .goto Bloodmyst Isle,46.8,77.0,15,0
    .goto Bloodmyst Isle,45.7,86.9,15,0
    .goto Bloodmyst Isle,49.7,86.2,15,0
    .goto Bloodmyst Isle,53.5,75.7,15,0
    .goto Bloodmyst Isle,48.5,66.7,15,0
    .goto Bloodmyst Isle,54.1,67.6,15,0
    .goto Bloodmyst Isle,58.9,61.8,15,0
	>>拾取地上的 |cRXP_LOOT_血蘑菇|r
    >>|cRXP_WARN_这些会在秘血岛各处出现|r
    .complete 9648,2 --Collect Blood Mushroom (x1)
step
    #optional
    .isOnQuest 9648,9594,9567,9629
	.hs >> 炉石到血环堡
    .cooldown item,6948,>2,1
step
    #completewith next
    .subzone 3584 >> 前往血环堡
step
    .goto Bloodmyst Isle,53.245,57.741
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫莱|r 对话
    .turnin 9576 >> 交任务 克鲁芬的项链
    .turnin 9629 >> 交任务 研究鱼人
    .accept 9574 >> 接受任务 腐蚀的牺牲品
    .target 莫莱
step
--Arrow should point to the small ruins, dynamic spawns therefore
    .goto Bloodmyst Isle,50.6,74.4
    .goto Bloodmyst Isle,43.9,72.1,0
    .goto Bloodmyst Isle,45.2,68.1,0
    .goto Bloodmyst Isle,38.2,92.9,0
    .goto Bloodmyst Isle,52.7,82.7,0
	>>击杀 |cRXP_ENEMY_堕落的树人|r，拾取它们的 |cRXP_LOOT_晶化树皮|r
    .complete 9574,1 --Collect Crystallized Bark (x6)
    .mob 堕落的树人
step
    .goto Bloodmyst Isle,53.245,57.741
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫莱|r 对话
    .turnin 9574 >> 交任务 腐蚀的牺牲品
    .target 莫莱
step
	.goto Bloodmyst Isle,53.319,56.672
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_比迦|r 对话
    .target 比迦
	.vendor >> |cRXP_WARN_出售物品并修理装备|r << !Hunter
	.vendor >> |cRXP_BUY_购买 |T134410:0|t[中型箭袋]|r，并补充|cRXP_WARN_ |T132382:0|t[锋利的箭]|r << Hunter
    .collect 11362,1 << Hunter
    .subzoneskip 3584,1
step
    .goto Bloodmyst Isle,55.252,59.121
    >>点击 |cRXP_PICK_通缉布告|r
    .accept 9646 >> 接受任务 通缉：死爪
step
    .isOnQuest 9594
    .goto Bloodmyst Isle,55.083,57.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官艾蕾希亚|r 对话
    .turnin 9594 >> 交任务 军团的徽记
    .turnin 9567 >> 交任务 知己知彼
    .target 守备官艾蕾希亚
step
    .goto Bloodmyst Isle,55.083,57.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官艾蕾希亚|r 对话
    .turnin 9567 >> 交任务 知己知彼
    .target 守备官艾蕾希亚
step
    .goto Bloodmyst Isle,55.156,55.953
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_止松大使欧罗尔格|r 对话
    .turnin 9667 >> 交任务 拯救止松公主
    .target 止松大使欧罗尔格
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .accept 9641 >> 接受任务 辐射水晶碎片
	.turnin 9641 >> 交任务 辐射水晶碎片
    .accept 9779 >> 接受任务 拦截情报
	.itemcount 23984,10 -- Irradiated Crystal Shard (10)
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .accept 9641 >> 接受任务 辐射水晶碎片
    .accept 9779 >> 接受任务 拦截情报
step << Paladin
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .trainer >> 训练你的职业技能
    .target 守备官伊索姆
    .subzoneskip 3584,1
step
    .goto Bloodmyst Isle,55.862,56.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .accept 9580 >> 接受任务 猎熊
    .accept 9643 >> 接受任务 荆棘巨藤
    .target 追踪者兰塞恩
step
    .goto Bloodmyst Isle,56.428,56.817
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_玛特帕尔姆|r 对话
    .turnin 9648 >> 交任务 玛特帕尔姆蘑菇展
    .target 玛特帕尔姆
step
    #completewith next
    .subzone 3591 >> 前往洛雷萨兰遗址
step
    .goto Bloodmyst Isle,61.249,48.373
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与死去的 |cRXP_FRIENDLY_德莱尼制图师|r 对话
    .turnin 9620 >> 交任务 失踪的测量小组
    .accept 9628 >> 接受任务 夺回数据
    .target 德莱尼制图师
step
    #loop
    .goto Bloodmyst Isle,61.24,48.37,0
    .goto Bloodmyst Isle,61.24,48.37,40,0
    .goto Bloodmyst Isle,61.40,43.51,40,0
    .goto Bloodmyst Isle,63.36,47.93,40,0
	>>击杀 |cRXP_ENEMY_怒鳞掠夺者|r 和 |cRXP_ENEMY_怒鳞巫师|r，拾取他们的 |cRXP_LOOT_测量数据水晶|r
    .complete 9628,1 --Collect Survey Data Crystal (x1)
    .mob 怒鳞掠夺者
    .mob 怒鳞巫师
step
    .goto Bloodmyst Isle,52.588,53.207
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先行官米库拉斯|r 对话
    .turnin 9628 >> 交任务 夺回数据
    .accept 9584 >> 接受任务 第二份样本
    .turnin 9668 >> 交任务 向主教埃德门图斯报告
    .target 先行官米库拉斯
step
	#completewith GrindCheck
	>>击杀 |cRXP_ENEMY_炎鹰间谍|r。拾取他们的 |cRXP_LOOT_炎鹰信函|r
    .complete 9779,1 --Collect Sunhawk Missive (x1)
    .mob 炎鹰间谍
step
    .goto Bloodmyst Isle,45.669,47.827
	.use 23876 >>|cRXP_WARN_使用|r |T134709:0|t[水晶矿锄] |cRXP_WARN_在|r |cRXP_PICK_变异的秘血水晶|r 处使用
    .complete 9584,1 --Collect Altered Crystal Sample (x1)
step
    #label GrindCheck
	.goto Bloodmyst Isle,48.1,47.6
    .xp 15-1200 >> 刷怪练级，直到距离15级还差1200点经验（11100/12300）
    .mob 炎鹰间谍
step
    #loop
    .goto Bloodmyst Isle,47.0,51.6,0
    .goto Bloodmyst Isle,50.8,47.0,0
    .goto Bloodmyst Isle,47.4,43.8,0
    .goto Bloodmyst Isle,46.7,48.3,50,0
    .goto Bloodmyst Isle,50.8,47.0,50,0
    .goto Bloodmyst Isle,47.4,43.8,50,0
	>>击杀 |cRXP_ENEMY_炎鹰间谍|r。拾取他们的 |cRXP_LOOT_炎鹰信函|r
    .complete 9779,1 --Collect Sunhawk Missive (x1)
    .mob 炎鹰间谍
step
	#completewith Audience
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_信使赫米修斯|r 对话
    >>|cRXP_FRIENDLY_信使赫米修斯|r |cRXP_WARN_会在秘血岗哨各处巡逻|r
    .accept 9671 >> 接受任务 紧急信件
    .turnin 9671 >> 交任务 紧急信件
	.target 信使赫米修斯
step
    .goto Bloodmyst Isle,52.588,53.207
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先行官米库拉斯|r 对话
    .turnin 9584 >> 交任务 第二份样本
    .accept 9585 >> 接受任务 最终的样本
    .target 先行官米库拉斯
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .turnin 9779 >> 交任务 拦截情报
    .accept 9696 >> 接受任务 翻译……
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .accept 9641 >> 接受任务 辐射水晶碎片
	.turnin 9641 >> 交任务 辐射水晶碎片
	.itemcount 23984,10 -- Irradiated Crystal Shard (10)
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132775:0|t[洞察水晶] |cRXP_WARN_消耗品增益（智力提高 5 点，持续 30 分钟）|r << !Warrior !Paladin !Shaman !Rogue
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132786:0|t[野性水晶] |cRXP_WARN_消耗品增益（攻击强度提高 10 点，持续 30 分钟）|r << Warrior/Paladin/Shaman/Rogue
    .target 守备官波鲁斯
    .itemcount 23984,>9
step
    #label Audience
    .goto Bloodmyst Isle,54.438,54.450
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_审讯者埃莉西亚|r 对话
    .target 审讯者埃莉西亚
    .turnin 9696 >> 交任务 翻译……
    .accept 9698 >> 接受任务 会见先知
step
    #loop
    .goto Bloodmyst Isle,54.6,59.8,0
    .goto Bloodmyst Isle,53.6,54.4,40,0
    .goto Bloodmyst Isle,54.6,59.8,20,0
    .goto Bloodmyst Isle,55.6,54.4,40,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_信使赫米修斯|r 对话
    >>|cRXP_FRIENDLY_信使赫米修斯|r |cRXP_WARN_会在秘血岗哨各处巡逻|r
    .accept 9671 >> 接受任务 紧急信件
    .turnin 9671 >> 交任务 紧急信件
	.target 信使赫米修斯
step
    .goto Bloodmyst Isle,55.210,59.207
	>>打开你的 |cRXP_PICK_邮箱|r，取出 |T134332:0|t[|cRXP_LOOT_海军上将的来信|r]
    .use 24132 >>|cRXP_WARN_使用|r |T134332:0|t[|cRXP_LOOT_海军上将的来信|r]|cRXP_WARN_开始任务|r
    .collect 24132,1,9672 --Collect A Letter from the Admiral
    .accept 9672 >> 接受任务 血咒的遗产
step
    .goto Bloodmyst Isle,55.843,59.807
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托菲尔·罗阿|r 对话
    .target 托菲尔·罗阿
    >>|cRXP_BUY_从他那里|r|cRXP_BUY_购买最多 40 条|r |T133918:0|t[长嘴泥鳅] << Warrior
    >>|cRXP_BUY_从他那里|r买够40杯|cRXP_BUY_ |T132796:0|t[果汁] |r << Mage/Priest/Hunter
    >>|cRXP_BUY_从他那里|r购买40份|cRXP_BUY_ |T132796:0|t[果汁] |r和|cRXP_BUY_ |T133918:0|t[新鲜的长嘴泥鳅] |r << Paladin/Shaman
    .collect 1205,35 << !Warrior !Rogue --Melon Juice (35)
    .collect 4592,35 --Longjaw Mud Snapper (35)
    .subzoneskip 3584,1
step
    .goto Bloodmyst Isle,55.083,57.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官艾蕾希亚|r 对话
    .accept 9569 >> 接受任务 化解危机
    .target 守备官艾蕾希亚
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .accept 9641 >> 接受任务 辐射水晶碎片
	.turnin 9641 >> 交任务 辐射水晶碎片
	.itemcount 23984,10 -- Irradiated Crystal Shard (10)
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132775:0|t[洞察水晶] |cRXP_WARN_消耗品增益（智力提高 5 点，持续 30 分钟）|r << !Warrior !Paladin !Shaman !Rogue
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132786:0|t[野性水晶] |cRXP_WARN_消耗品增益（攻击强度提高 10 点，持续 30 分钟）|r << Warrior/Paladin/Shaman/Rogue
    .target 守备官波鲁斯
    .itemcount 23984,>9
step
    .goto Bloodmyst Isle,56.428,56.817
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_玛特帕尔姆|r 对话
    .target 玛特帕尔姆
    .accept 9649 >> 接受任务 伊瑟拉之泪
step
    #completewith next
    .subzone 3598 >> 前往弗雷岛
step
    .goto Bloodmyst Isle,74.7,33.7
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    >>|cRXP_FRIENDLY_托雷斯王子|r |cRXP_WARN_会稍微来回走动|r
    .accept 9687 >> 接受任务 找回尊严
    .target 托雷斯王子
step
	#completewith next
	>>拾取地上的 |cRXP_LOOT_伊瑟拉之泪|r
    >>|cRXP_WARN_这些看起来像小型的绿色蘑菇|r
    .complete 9649,1 --Collect Ysera's Tear (x2)
step
    .goto Bloodmyst Isle,79.150,22.656
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    .turnin 9672 >> 交任务 血咒的遗产
    .accept 9674 >> 接受任务 血咒纳迦
    .target 艾德华·汉斯船长
step
    #loop
    .goto Bloodmyst Isle,82.0,21.6,0
    .goto Bloodmyst Isle,81.0,16.2,0
    .goto Bloodmyst Isle,80.8,10.4,0
    .goto Bloodmyst Isle,82.0,21.6,70,0
    .goto Bloodmyst Isle,81.0,16.2,70,0
    .goto Bloodmyst Isle,80.8,10.4,70,0
	>>击杀 |cRXP_ENEMY_血咒纳迦|r
    .complete 9674,1 --Kill Bloodcursed Naga (x10)
    .mob 血咒纳迦
step
    .goto Bloodmyst Isle,79.150,22.656
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    .turnin 9674 >> 交任务 血咒纳迦
    .accept 9682 >> 接受任务 绝望者……
    .target 艾德华·汉斯船长
step
    #loop
    .goto Bloodmyst Isle,83.21,21.40,0
    .goto Bloodmyst Isle,87.3,16.6,0
    .goto Bloodmyst Isle,83.90,12.18,0
    .goto Bloodmyst Isle,83.21,21.40,40,0
    .goto Bloodmyst Isle,87.3,16.6,40,0
    .goto Bloodmyst Isle,83.90,12.18,50,0
    >>击杀 |cRXP_ENEMY_血咒航海者|r，拾取它们掉落的 |cRXP_LOOT_血咒之魂|r
    .complete 9682,1 --Collect Bloodcursed Soul (x4)
    .mob 血咒航海者
step
    .goto Bloodmyst Isle,79.150,22.656
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    .turnin 9682 >> 交任务 绝望者……
    .accept 9683 >> 接受任务 血咒的终结 << !Warrior
    .target 艾德华·汉斯船长
step << !Warrior
    .xp 16-3300 >> 练怪直到距离16 级还有 3300 经验 (10300/13600)
step
    #loop
    .goto Bloodmyst Isle,76.8,21.5,0
    .goto Bloodmyst Isle,75.7,28.5,0
    .goto Bloodmyst Isle,71.5,28.6,0
    .goto Bloodmyst Isle,68.5,21.6,0
    .goto Bloodmyst Isle,70.6,16.5,0
    .goto Bloodmyst Isle,71.5,11.5,0
    .goto Bloodmyst Isle,75.1,8.4,0
    .goto Bloodmyst Isle,74.9,16.3,0
    .goto Bloodmyst Isle,76.8,21.5,35,0
    .goto Bloodmyst Isle,75.7,28.5,35,0
    .goto Bloodmyst Isle,71.5,28.6,35,0
    .goto Bloodmyst Isle,68.5,21.6,35,0
    .goto Bloodmyst Isle,70.6,16.5,35,0
    .goto Bloodmyst Isle,71.5,11.5,35,0
    .goto Bloodmyst Isle,75.1,8.4,35,0
    .goto Bloodmyst Isle,74.9,16.3,35,0
	>>拾取地上的 |cRXP_LOOT_伊瑟拉之泪|r
    >>|cRXP_WARN_这些看起来像小型的绿色蘑菇|r
    .complete 9649,1 --Collect Ysera's Tear (x2)
step << !Warrior
    #completewith Atoph
    .subzone 3612 >> 向南游，前往血咒岛
step << !Warrior
    #completewith Atoph
    .goto Bloodmyst Isle,83.58,55.21,20,0
    .goto Bloodmyst Isle,86.26,57.24,20,0
    .goto Bloodmyst Isle,86.90,52.70,20,0
    .goto Bloodmyst Isle,86.061,54.599
    .cast 8386,6477,6478 >> 点击 |cRXP_PICK_艾萨拉女王雕像|r 以召唤 |cRXP_ENEMY_血咒者埃托弗|r
step << !Warrior
    #label Atoph
    .goto Bloodmyst Isle,85.59,53.42
    >>击杀 |cRXP_ENEMY_血咒者埃托弗|r
    >>|cRXP_ENEMY_血咒者埃托弗|r |cRXP_WARN_为 19 级。|r如果需要，请准备使用治疗药水或|cRXP_WARN_ |T135923:0|t[纳鲁的恩赐]。如果你无法击杀他，可跳过此步骤|r
    .complete 9683,1 --Kill Atoph the Bloodcursed (x1)
    .mob 血咒者埃托弗
step
	#completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    .goto Bloodmyst Isle,56.428,56.817
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_玛特帕尔姆|r 对话
    .target 玛特帕尔姆
    .turnin 9649 >> 交任务 伊瑟拉之泪
step
    .goto Bloodmyst Isle,56.324,54.232
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_勘探者纳克兰|r 对话
    .accept 10063 >> 接受任务 探险者协会要为侏儒服务吗？
    .target 勘探者纳克兰
step
    .goto Bloodmyst Isle,57.680,53.875
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .accept 9604 >> 接受任务 乘坐角鹰兽
    .target 兰度
step
    #completewith WingsofHippogryph
    .goto Bloodmyst Isle,57.680,53.875
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .fly The Exodar>> 飞往埃索达
    .target 兰度
step
    #completewith WingsofHippogryph
    .goto The Exodar,73.682,53.701,15 >> 进入埃索达
step
    #label WingsofHippogryph
	.goto The Exodar,57.011,50.091
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_努古尼|r 对话
    .turnin 9604 >> 交任务 乘坐角鹰兽
    .accept 9605 >> 接受任务 斯泰法努斯
    .target 努古尼
step << Warlock/Priest/Mage
    #ah
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧斯|r 对话
    >>|cRXP_BUY_购买1根|r |T135468:0|t[烟尘魔杖] |cRXP_BUY_从他那里 或者查看拍卖行购买|r |T135144:0|t[强效魔法杖]
    .goto The Exodar,46.386,61.499
    .goto The Exodar,63.363,58.999,0
    .collect 5208,1 --Smoldering Wand (1)
    .target 欧斯
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    --not adding .money tag to this step. user could have less silver than vendor wand but cheaper ones may exist on the AH
step << Warlock/Priest/Mage
    #ssf
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧斯|r 对话
    >>|cRXP_BUY_从他那里|r购买1把|cRXP_BUY_ |T135468:0|t[烟尘魔杖]|r
    .goto The Exodar,46.386,61.499
    .collect 5208,1 --Smoldering Wand (1)
    .target 欧斯
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    .money <0.3173
step << Warlock/Priest/Mage
    #optional
    +|cRXP_WARN_装备|r |T135468:0|t[烟尘魔杖]
    .use 5208
    .itemcount 5208,1
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    .xp <15,1
step << Warlock/Priest/Mage
    #optional
    +|cRXP_WARN_等你达到15级时|r记得装备|cRXP_WARN_ |T135468:0|t[烟尘魔杖] |r
    .use 5208
    .itemcount 5208,1
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    .xp >15,1
step
    .goto The Exodar,53.589,90.839
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_菲拉|r 对话
    .vendor >> |cRXP_BUY_买一个|r |T133024:0|t[青铜管]
    >>|cRXP_WARN_这是限量供应物品，如果他没有出售，请跳过此步骤|r
    .bronzetube
    .target 菲拉
    .zoneskip The Exodar,1
step << Warrior/Shaman/Paladin
    #completewith next
    .goto The Exodar,53.39,85.68,15,0
    .goto The Exodar,50.50,81.28,20 >> 上楼梯前往顶层的 |cRXP_FRIENDLY_贝霍玛特|r << Warrior
    .goto The Exodar,50.50,81.28,20 >> 上楼梯前往顶层的 |cRXP_FRIENDLY_韩迪尔|r << Shaman/Paladin
step << Warrior
    .goto The Exodar,55.580,82.290
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_贝霍玛特|r 对话
    .turnin 10350 >> 交任务 贝霍玛特
    .trainer >> 训练你的职业技能
    .target 贝霍玛特
step << Warrior/Shaman/Paladin
    .goto The Exodar,53.362,85.753
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_韩迪尔|r 对话
    .train 199 >> 学习双手锤 << Warrior/Shaman
    .train 202 >> 学习双手剑 << Paladin
    .target 韩迪尔
step << Paladin
    .goto The Exodar,38.367,82.564
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女祭司基琳·伊尔蒂娜|r 对话
    .turnin 9600 >>交任务 救赎
	.trainer >> 训练你的职业技能
    .target 约尔
step << Warrior/Paladin
    #ah
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_埃尔洛米|r 对话
    >>|cRXP_BUY_从她那里|r购买1把|cRXP_BUY_ |T133046:0|t[巨型石锤]， 或者查看拍卖行寻找更好的|r
    .goto The Exodar,73.625,84.814
    .goto The Exodar,63.363,58.999,0
    .collect 2026,1 --Rock Hammer (1)
    .target 埃尔洛米 <钝器商人>
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    --not adding .money tag to this step. user could have less silver than vendor wep but cheaper ones may exist on the AH
step << Warrior/Paladin
    #ssf
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_埃尔洛米|r 对话
    >>|cRXP_BUY_从她那里|r购买1把|cRXP_BUY_ |T133046:0|t[巨型石锤]|r
    .goto The Exodar,73.625,84.814
    .collect 2026,1 --Rock Hammer (1)
    .target 埃尔洛米 <钝器商人>
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .money <0.5971
step << Warrior/Paladin
    #optional
    +|cRXP_WARN_装备|r |T133046:0|t[巨型石锤]
    .use 2026
    .itemcount 2026,1
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step
    .goto The Exodar,32.844,54.484
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先知维伦|r 对话
    .target 先知维伦
    .turnin 9461 >> 交任务 火焰的召唤 << Shaman
    .accept 9555 >> 接受任务 火焰的召唤 << Shaman
    .turnin 9698 >> 交任务 会见先知
    .accept 9699 >> 接受任务 真相还是谎言
step << Shaman
    #completewith next
    .goto The Exodar,27.90,29.43,10 >> 沿斜坡前去找 |cRXP_FRIENDLY_先知诺布杜|r
step << Shaman
    .goto The Exodar,31.27,27.65,15,0
    .goto The Exodar,29.76,33.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_预言者努波顿|r 对话
    >>|cRXP_FRIENDLY_预言者努波顿|r |cRXP_WARN_偶尔巡逻|r
    .target 预言者努波顿
    .turnin 9555 >> 交任务 火焰的召唤
	.trainer >> 训练你的职业技能
step
    #completewith next
    .goto The Exodar,54.09,32.52,30,0
    .goto The Exodar,64.86,35.03,20,0
    .goto The Exodar,73.68,53.70,20 >> 离开埃索达
step
    .goto The Exodar,68.351,63.490
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯泰法努斯|r 对话
    .target 斯泰法努斯
    .turnin 9605 >> 交任务 斯泰法努斯
    .accept 9606 >> 接受任务 返回看护员谢尔兰身边
step
    .isOnQuest 9606,9699
	.hs >> 炉石到血环堡
    >>|cRXP_BUY_如有需要，购买食物/水|r << !Warrior !Rogue
	>>|cRXP_BUY_需要的话就买点食物|r << Warrior/Rogue
    .cooldown item,6948,>2,1
step
	.isOnQuest 9606,9699
    .goto The Exodar,68.351,63.490
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯泰法努斯|r 对话
    .fly Blood Watch >> 飞往血环堡
    .target 斯泰法努斯
    .zoneskip Bloodmyst Isle
step
    .goto Bloodmyst Isle,55.843,59.807
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯泰法努斯|r 对话
    .turnin -9606 >> 交任务 返回看护员谢尔兰身边
    .target 托菲尔·罗阿
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .turnin 9699 >> 交任务 真相还是谎言
    .accept 9700 >> 接受任务 黑暗中的魔法
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .accept 9641 >> 接受任务 辐射水晶碎片
	.turnin 9641 >> 交任务 辐射水晶碎片
	.itemcount 23984,10 -- Irradiated Crystal Shard (10)
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132775:0|t[洞察水晶] |cRXP_WARN_消耗品增益（智力提高 5 点，持续 30 分钟）|r << !Warrior !Paladin !Shaman !Rogue
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132786:0|t[野性水晶] |cRXP_WARN_消耗品增益（攻击强度提高 10 点，持续 30 分钟）|r << Warrior/Paladin/Shaman/Rogue
    .target 守备官波鲁斯
    .itemcount 23984,>9
step
    #completewith CrystalSample
    .isOnQuest 9569,9585
    .goto Bloodmyst Isle,41.069,30.660
    .subzone 3593 >> 前往阿克萨里恩
    >>击杀 |cRXP_ENEMY_变异的缠绕者|r，拾取它们的 |cRXP_LOOT_荆棘巨藤|r
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_前往阿克萨林的路上看到的都可以击杀|r
    .complete 9643,1 --Collect Thorny Constrictor Vine (x6)
    .mob 变异的缠绕者
    .disablecheckbox
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
    .disablecheckbox
step
    #completewith CrystalSample
    >>拾取地上的 |cRXP_LOOT_被腐蚀的水晶|r
    .complete 9569,4 --Collect Corrupted Crystal (x5)
step
    #completewith CrystalSample
    >>击杀 |cRXP_ENEMY_塞弗拉克斯|r, |cRXP_ENEMY_阿克萨林暗影行者|r 和 |cRXP_ENEMY_阿克萨林唤魔者|r
    .complete 9569,1 --Kill Zevrax (x1)
    .goto Bloodmyst Isle,41.907,29.533
    .mob 塞弗拉克斯
    .complete 9569,2 --Kill Axxarien Shadowstalker (x5)
    .mob 阿克萨林暗影行者
    .complete 9569,3 --Kill Axxarien Hellcaller (x5)
    .mob 阿克萨林唤魔者
step
    #label CrystalSample
    .goto Bloodmyst Isle,41.069,30.660
	.use 23877 >>|cRXP_WARN_使用|r |T134709:0|t[水晶矿锄] |cRXP_WARN_对|r |cRXP_PICK_阿克萨林水晶|r 使用
    .complete 9585,1 --Collect Axxarien Crystal Sample (x1)
step
    #completewith ShadowstalkerHellcaller
    >>拾取地上的 |cRXP_LOOT_被腐蚀的水晶|r
    .complete 9569,4 --Collect Corrupted Crystal (x5)
step
    >>击杀 |cRXP_ENEMY_塞弗拉克斯|r, |cRXP_ENEMY_阿克萨林暗影行者|r 和 |cRXP_ENEMY_阿克萨林唤魔者|r
    .complete 9569,1 --Kill Zevrax (x1)
    .goto Bloodmyst Isle,41.907,29.533
    .mob 塞弗拉克斯
    .complete 9569,2 --Kill Axxarien Shadowstalker (x5)
    .mob 阿克萨林暗影行者
    .disablecheckbox
    .complete 9569,3 --Kill Axxarien Hellcaller (x5)
    .mob 阿克萨林唤魔者
    .disablecheckbox
step
    #label ShadowstalkerHellcaller
    #loop
    .goto Bloodmyst Isle,41.76,32.82,0
    .goto Bloodmyst Isle,39.75,35.55,0
    .goto Bloodmyst Isle,37.73,37.32,0
    .goto Bloodmyst Isle,34.75,36.97,0
    .goto Bloodmyst Isle,41.76,32.82,50,0
    .goto Bloodmyst Isle,39.75,35.55,50,0
    .goto Bloodmyst Isle,37.73,37.32,50,0
    .goto Bloodmyst Isle,34.75,36.97,50,0
    >>击杀 |cRXP_ENEMY_阿克萨林暗影行者|r 和 |cRXP_ENEMY_阿克萨林唤魔者|r
    .complete 9569,2 --Kill Axxarien Shadowstalker (x5)
    .mob 阿克萨林暗影行者
    .complete 9569,3 --Kill Axxarien Hellcaller (x5)
    .mob 阿克萨林唤魔者
step
    #loop
    .goto Bloodmyst Isle,41.76,32.82,0
    .goto Bloodmyst Isle,39.75,35.55,0
    .goto Bloodmyst Isle,37.73,37.32,0
    .goto Bloodmyst Isle,34.75,36.97,0
    .goto Bloodmyst Isle,41.76,32.82,50,0
    .goto Bloodmyst Isle,39.75,35.55,50,0
    .goto Bloodmyst Isle,37.73,37.32,50,0
    .goto Bloodmyst Isle,34.75,36.97,50,0
    >>拾取地上的 |cRXP_LOOT_被腐蚀的水晶|r
    .complete 9569,4 --Collect Corrupted Crystal (x5)
step
    #completewith VoidAnomaly
    >>击杀 |cRXP_ENEMY_变异的缠绕者|r，拾取它们的 |cRXP_LOOT_荆棘巨藤|r
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    .complete 9643,1 --Collect Thorny Constrictor Vine (x6)
    .mob 变异的缠绕者
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
    .goto Bloodmyst Isle,37.45,30.53
    >>击杀 |cRXP_ENEMY_死爪|r，拾取他的 |cRXP_LOOT_死爪的爪子|r
    .complete 9646,1 --Collect Deathclaw's Paw (x1)
    .mob 死爪
step
    .goto Bloodmyst Isle,42.147,21.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_克劳伯·维兹班|r 对话
    .turnin 10063 >> 交任务 探险者协会要为侏儒服务吗？
    .accept 9548 >> 接受任务 被偷走的设备
    .accept 9549 >> 接受任务 黑沙神器
    .target 克劳伯·维兹班
step
    .goto Bloodmyst Isle,42.147,21.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_克劳伯·维兹班|r 对话
    .vendor >> |cRXP_BUY_买一个|r |T133024:0|t[青铜管]
    >>|cRXP_WARN_这是限量供应物品，如果他没有出售，请跳过此步骤|r
    .bronzetube
    .target 克劳伯·维兹班
    .subzoneskip 3906,1
step
    #completewith next
	>>击杀 |cRXP_ENEMY_黑沙先知|r，拾取他们的 |cRXP_LOOT_粗糙的鱼人神像|r
    >>击杀 |cRXP_ENEMY_黑沙战士|r 和 |cRXP_ENEMY_黑沙巡滩者|r，拾取他们的 |cRXP_LOOT_粗糙的鱼人小刀|r
    .complete 9549,1 --Collect Crude Murloc Idol (x3)
    .mob 黑沙先知
    .complete 9549,2 --Collect Crude Murloc Knife (x6)
    .mob 黑沙战士
    .mob 黑沙巡滩者
step
    #loop
    .goto Bloodmyst Isle,40.4,20.4,0
	.goto Bloodmyst Isle,38.5,22.5,0
	.goto Bloodmyst Isle,36.0,25.8,0
    .goto Bloodmyst Isle,40.4,20.4,60,0
	.goto Bloodmyst Isle,38.5,22.5,30,0
	.goto Bloodmyst Isle,36.0,25.8,30,0
	.goto Bloodmyst Isle,40.4,20.4,30,0
	.goto Bloodmyst Isle,43.8,22.4,30,0
	.goto Bloodmyst Isle,46.4,20.5,30,0
	.goto Bloodmyst Isle,40.4,20.4,30,0
    >>拾取地上的 |cRXP_LOOT_克劳伯的设备|r
    >>|cRXP_WARN_它可能会在任意一个鱼人营地刷新|r
    .complete 9548,1 --Collect Clopper's Equipment (x1)
step
    #loop
    .goto Bloodmyst Isle,40.4,20.4,0
	.goto Bloodmyst Isle,38.5,22.5,0
	.goto Bloodmyst Isle,36.0,25.8,0
    .goto Bloodmyst Isle,40.4,20.4,60,0
	.goto Bloodmyst Isle,38.5,22.5,30,0
	.goto Bloodmyst Isle,36.0,25.8,30,0
	.goto Bloodmyst Isle,40.4,20.4,30,0
	.goto Bloodmyst Isle,43.8,22.4,30,0
	.goto Bloodmyst Isle,46.4,20.5,30,0
	.goto Bloodmyst Isle,40.4,20.4,30,0
	>>击杀 |cRXP_ENEMY_黑沙先知|r，拾取他们的 |cRXP_LOOT_粗糙的鱼人神像|r
    >>击杀 |cRXP_ENEMY_黑沙战士|r 和 |cRXP_ENEMY_黑沙巡滩者|r，拾取他们的 |cRXP_LOOT_粗糙的鱼人小刀|r
    .complete 9549,1 --Collect Crude Murloc Idol (x3)
    .mob 黑沙先知
    .complete 9549,2 --Collect Crude Murloc Knife (x6)
    .mob 黑沙战士
    .mob 黑沙巡滩者
step
    .goto Bloodmyst Isle,42.147,21.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_克劳伯·维兹班|r 对话
    .turnin 9548 >> 交任务 被偷走的设备
    .turnin 9549 >> 交任务 黑沙神器
    .target 克劳伯·维兹班
step
    .use 23837 >>|cRXP_WARN_使用|r |T134269:0|t[风蚀的藏宝图] |cRXP_WARN_来开始任务|r
    .accept 9550 >> 接受任务 一张地图？
step
    #label VoidAnomaly
    .goto Bloodmyst Isle,52.741,21.161
	>>击杀 |cRXP_ENEMY_虚空畸能|r 并探索太阳之门遗址
    .complete 9700,2 --Kill Void Anomaly (x5)
    .mob 虚空畸能
    .complete 9700,1 --Sun Portal Site Confirmed (1)
step
    #loop
	.goto Bloodmyst Isle,44.9,26.4,0
	.goto Bloodmyst Isle,45.1,37.4,0
	.goto Bloodmyst Isle,34.0,44.3,0
	.goto Bloodmyst Isle,42.5,49.3,0
    .goto Bloodmyst Isle,47.6,24.9,70,0
	.goto Bloodmyst Isle,44.9,26.4,70,0
	.goto Bloodmyst Isle,48.3,33.4,70,0
	.goto Bloodmyst Isle,45.1,37.4,70,0
	.goto Bloodmyst Isle,40.8,41.9,70,0
	.goto Bloodmyst Isle,34.0,44.3,70,0
	.goto Bloodmyst Isle,39.0,48.1,70,0
	.goto Bloodmyst Isle,42.5,49.3,70,0
    >>击杀 |cRXP_ENEMY_变异的缠绕者|r，拾取它们的 |cRXP_LOOT_荆棘巨藤|r
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_优先击杀 |cRXP_ENEMY_变异的缠绕者|r，之后有时间再完成 |r老年棕熊|cRXP_ENEMY_|r
    .complete 9643,1 --Collect Thorny Constrictor Vine (x6)
    .mob 变异的缠绕者
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
    .disablecheckbox
step
    #loop
    .goto Bloodmyst Isle,54.0,30.9,0
    .goto Bloodmyst Isle,53.9,35.4,0
    .goto Bloodmyst Isle,57.0,34.3,0
    .goto Bloodmyst Isle,56.1,40.2,0
    .goto Bloodmyst Isle,54.0,30.9,25,0
    .goto Bloodmyst Isle,53.9,35.4,25,0
    .goto Bloodmyst Isle,57.0,34.3,25,0
    .goto Bloodmyst Isle,56.1,40.2,25,0
	>>拾取地上的 the |cRXP_LOOT_龙骨|r
    >>|cRXP_WARN_这些目标不太容易发现，通常位于小型营地周围|r
    .complete 9687,1 --Collect Dragon Bone (x8)
step
    .goto Bloodmyst Isle,61.156,41.893
    >>点击地上的 |cRXP_PICK_破旧的古书|r
    .turnin 9550 >> 交任务 一张地图？
    .accept 9557 >> 接受任务 破译书籍
step
	.goto Bloodmyst Isle,54.661,53.951
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_学者菲索斯|r 对话
    .turnin 9557 >> 交任务 破译书籍
    .target 学者菲索斯
step
    .goto Bloodmyst Isle,52.588,53.207
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_先行官米库拉斯|r 对话
    .turnin 9585 >> 交任务 最终的样本
    .accept 10064 >> 接受任务 阿古斯之手
    .turnin 9646 >> 交任务 通缉：死爪
    .target 先行官米库拉斯
step
	.goto Bloodmyst Isle,54.661,53.951
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_学者菲索斯|r 对话
    .accept 9561 >> 接受任务 诺尔凯的日记
    .accept 9632 >> 接受任务 新的盟友
    .target 学者菲索斯
step
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    .target 守备官波鲁斯
    .turnin 9700 >> 交任务 黑暗中的魔法
step
    #optional
    .goto Bloodmyst Isle,55.429,55.266
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官波鲁斯|r 对话
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132775:0|t[洞察水晶] |cRXP_WARN_消耗品增益（智力提高 5 点，持续 30 分钟）|r << !Warrior !Paladin !Shaman !Rogue
    +|cRXP_WARN_记得上交你的|r |T134082:0|t[辐射水晶碎片] |cRXP_WARN_以获得|r |T132786:0|t[野性水晶] |cRXP_WARN_消耗品增益（攻击强度提高 10 点，持续 30 分钟）|r << Warrior/Paladin/Shaman/Rogue
    .target 守备官波鲁斯
    .itemcount 23984,>9
step
    .goto Bloodmyst Isle,55.631,55.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官库卢斯|r 对话
    .accept 9703 >> 接受任务 冷却核心
    .target 守备官库卢斯
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9580 >> 交任务 猎熊
    .turnin 9643 >> 交任务 荆棘巨藤
    .accept 9647 >> 接受任务 消灭巨蛾
    .target 追踪者兰塞恩
step
    .goto Bloodmyst Isle,55.862,56.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9643 >> 交任务 荆棘巨藤
    .accept 9647 >> 接受任务 消灭巨蛾
    .target 追踪者兰塞恩
step
    .goto Bloodmyst Isle,55.083,57.997
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官艾蕾希亚|r 对话
    .turnin 9569 >> 交任务 化解危机
    .target 守备官艾蕾希亚
step
    .goto Bloodmyst Isle,53.245,57.741
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫莱|r 对话
    .accept 9578 >> 接受任务 搜寻加莱恩
    .target 莫莱
step
    .goto Bloodmyst Isle,53.245,57.031
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿彻鲁斯|r 对话
    .accept 9669 >> 接受任务 覆灭的远征队
    .target 阿彻鲁斯
step
	.isOnQuest 9580
	#completewith GCorpse
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_前往冷却核心的途中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
	.isQuestTurnedIn 9580
	#completewith GCorpse
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>|cRXP_WARN_前往冷却核心的途中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    #completewith GCorpse
    .subzone 3588 >> 前往冷却核心
step
    #label GCorpse
    .goto Bloodmyst Isle,37.502,61.239
    >>点击 |cRXP_FRIENDLY_加莱恩的尸体|r
    >>|cRXP_WARN_前往 |cRXP_ENEMY_加莱恩的尸体|r 时，尽量避免击杀过多的 |r炎鹰回收者|cRXP_FRIENDLY_|r
    .turnin 9578 >> 交任务 搜寻加莱恩
    .accept 9579 >> 接受任务 加莱恩的命运
    .accept 9706 >> 接受任务 加莱恩的日记 - 守备官撒鲁安的命运
    .target 加莱恩的尸体
step
    .goto Bloodmyst Isle,37.50,61.23,0
    .goto Bloodmyst Isle,39.69,62.77,60,0
    .goto Bloodmyst Isle,38.59,57.40,60,0
    .goto Bloodmyst Isle,35.61,61.49,60,0
    >>击杀 |cRXP_ENEMY_炎鹰回收者|r，拾取 |cRXP_LOOT_加莱恩的护符|r 和他们的 |cRXP_LOOT_医疗物资|r
    >>你也可以拾取地上的 the |cRXP_LOOT_医疗物资|r
	>>|cRXP_WARN_必要时利用柱子和建筑物卡视角以躲避他们的|r |T135812:0|t[火球术] |cRXP_WARN_施放|r
    .complete 9579,1 --Collect Galaen's Amulet (x1)
    .complete 9703,1 --Collect Medical Supplies (x12)
    .mob 炎鹰回收者
step
	.xp 17+12800 >> 一直刷怪 ，直到你积累了12800经验，在17级 (12800+/16400)
step
	.isOnQuest 9580
	#completewith GFate
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_前往秘血岗哨的途中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
	.isQuestTurnedIn 9580
	#completewith GFate
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>|cRXP_WARN_前往秘血岗哨的途中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    #completewith GFate
    .subzone 3584 >> 前往血环堡
step
    #label GFate
    .goto Bloodmyst Isle,53.245,57.741
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莫莱|r 对话
    .turnin 9579 >> 交任务 加莱恩的命运
    .target 莫莱
step
    .goto Bloodmyst Isle,55.631,55.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官库卢斯|r 对话
    .turnin 9703 >> 交任务 冷却核心
    .turnin 9706 >> 交任务 加莱恩的日记 - 守备官撒鲁安的命运
    .accept 9711 >> 接受任务 残忍的玛提斯
    .target 守备官库卢斯
step
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .accept 9748 >> 接受任务 毒水
    .accept 9753 >> 接受任务 我们所知道的……
    .target 守备官伊索姆
step << Paladin
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .trainer >> 训练你的职业技能
    .target 守备官伊索姆
    .subzoneskip 3584,1
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9580
    .isQuestComplete 9647
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9580 >> 交任务 猎熊
    .turnin 9647 >> 交任务 消灭巨蛾
    .target 追踪者兰塞恩
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9580 >> 交任务 猎熊
    .target 追踪者兰塞恩
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9647
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9647 >> 交任务 消灭巨蛾
    .target 追踪者兰塞恩
step
    .goto Bloodmyst Isle,52.684,53.214
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_主教埃德门图斯|r 对话
    .turnin 9753 >> 交任务 我们所知道的……
    .accept 9756 >> Accept What We Don't Know... (NOT TRANSLATED IN :zhCN YET)
    .target 主教埃德门图斯
step
    .goto Bloodmyst Isle,54.312,54.215
    >>与 |cRXP_ENEMY_临时监狱|r 内的 |cRXP_PICK_被抓住的炎鹰间谍|r 对话
    .complete 9756,1 -- Sunhawk Information Recovered 1/1
    .skipgossip
    .target 被抓住的炎鹰间谍
step
    .goto Bloodmyst Isle,52.684,53.214
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_主教埃德门图斯|r 对话
    .turnin 9756 >> 交任务 我们不知道的……
    .accept 9760 >> 接受任务 守备官营地
    .target 主教埃德门图斯
step
    #optional
	.isOnQuest 9647
	#completewith MatistheCruel
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>|cRXP_WARN_在完成其他目标的过程中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    #optional
	.isOnQuest 9580
	#completewith MatistheCruel
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_在完成其他目标的过程中注意留意这些目标|r
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斥候约莉|r 和 |cRXP_FRIENDLY_斥候洛伊|r 对话
    .turnin 10064 >> 交任务 阿古斯之手
    .accept 10065 >> 接受任务 披荆斩棘
    .target 斥候约莉
    .goto Bloodmyst Isle,30.255,45.916
    .accept 9741 >> 接受任务 虚空幼体
    .target 斥候洛伊
    .goto Bloodmyst Isle,30.239,45.866
step
    .goto Bloodmyst Isle,30.750,46.844
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官考尔琳|r 对话
    .turnin 9760 >> 交任务 守备官营地
    .accept 10066 >> 接受任务 纠结之网
    .accept 10067 >> 接受任务 污秽的水之魂
    .target 守备官考尔琳
step
    #label MatistheCruel
    #loop
    .goto Bloodmyst Isle,43.9,43.7,0
    .goto Bloodmyst Isle,30.1,51.7,0
    .goto Bloodmyst Isle,22.4,54.3,0
    .goto Bloodmyst Isle,27.45,51.36,80,0
    .goto Bloodmyst Isle,22.67,54.20,70,0
    .goto Bloodmyst Isle,27.45,51.36,80,0
    .goto Bloodmyst Isle,32.55,48.08,80,0
    .goto Bloodmyst Isle,42.27,44.12,80,0
	.line Bloodmyst Isle,43.1,43.7,36.5,47.2,33.5,47.1,29.9,51.8,27.7,51.8,25.1,54.1,22.0,54.3
    .use 24278 >>|cRXP_WARN_对 |r残忍的玛提斯|cRXP_WARN_ 使用|r |T134536:0|t[信号枪]|cRXP_ENEMY_|r
    >>|cRXP_WARN_This will summon a |cRXP_FRIENDLY_Tracker of the Hand|r which will capture him once his health reaches 50%. Try not to get aggro as |cRXP_ENEMY_Matis the Cruel|r hits very hard|r (NOT TRANSLATED IN :zhCN YET)
    >>|cRXP_ENEMY_残忍的玛提斯|r |cRXP_WARN_在道路上巡逻很大一段区域。他的巡逻路线已在你的地图上标记|r
    .complete 9711,1 --Capture Matis the Cruel
	.unitscan 残忍的玛提斯
step
    #loop
    .goto Bloodmyst Isle,20.12,62.35,0
    .goto Bloodmyst Isle,19.58,64.62,40,0
    .goto Bloodmyst Isle,18.21,62.93,40,0
    .goto Bloodmyst Isle,20.12,62.35,40,0
    >>击杀 |cRXP_ENEMY_虚空幼体|r
    >>|cRXP_WARN_你必须击杀 |cRXP_ENEMY_虚空畸能|r 才能触发 |cRXP_ENEMY_虚空幼体|r 刷新|r
    .complete 9741,1 --Kill Void Critter (x12)
    .mob 虚空幼体
    .mob 虚空畸能
step
    #optional
	.isOnQuest 9647
	#completewith MutatedTanglers
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    >>|cRXP_WARN_在完成其他目标的过程中注意留意这些目标|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    #optional
	.isOnQuest 9580
	#completewith MutatedTanglers
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
    >>|cRXP_WARN_在完成其他目标的过程中注意留意这些目标|r
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
    #completewith next
	>>击杀 |cRXP_ENEMY_变异的纠结者|r
    .complete 10066,1 --Kill Mutated Tangler (x8)
    .mob 变异的纠结者
step
    #loop
    .goto Bloodmyst Isle,28.8,59.6,0
    .goto Bloodmyst Isle,31.8,53.8,0
    .goto Bloodmyst Isle,26.0,47.8,0
    .goto Bloodmyst Isle,28.8,59.6,70,0
    .goto Bloodmyst Isle,31.8,53.8,70,0
    .goto Bloodmyst Isle,26.0,47.8,70,0
    >>击杀 |cRXP_ENEMY_被激怒的掠食者|r
    .complete 10065,1 --Kill Enraged Ravager (x10)
    .mob 被激怒的掠食者
step
    #label MutatedTanglers
    #loop
    .goto Bloodmyst Isle,28.8,59.6,0
    .goto Bloodmyst Isle,31.8,53.8,0
    .goto Bloodmyst Isle,26.0,47.8,0
    .goto Bloodmyst Isle,28.8,59.6,70,0
    .goto Bloodmyst Isle,31.8,53.8,70,0
    .goto Bloodmyst Isle,26.0,47.8,70,0
	>>击杀 |cRXP_ENEMY_变异的纠结者|r
    .complete 10066,1 --Kill Mutated Tangler (x8)
    .mob 变异的纠结者
step
    #optional
	.isOnQuest 9647
	#completewith next
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    #optional
	.isOnQuest 9580
    #loop
    .goto Bloodmyst Isle,35.6,53.8,0
    .goto Bloodmyst Isle,39.6,51.2,0
    .goto Bloodmyst Isle,43.2,42.6,0
    .goto Bloodmyst Isle,34.8,42.6,0
    .goto Bloodmyst Isle,35.6,53.8,70,0
    .goto Bloodmyst Isle,39.6,51.2,70,0
    .goto Bloodmyst Isle,43.2,42.6,70,0
    .goto Bloodmyst Isle,34.8,42.6,70,0
    >>击杀 |cRXP_ENEMY_老年棕熊|r。拾取他们的 |cRXP_LOOT_老年棕熊的肉|r
	.complete 9580,1 --Elder Brown Bear Flank (8)
    .mob 老年棕熊
step
    #optional
	.isOnQuest 9647
    #loop
    .goto Bloodmyst Isle,35.6,53.8,0
    .goto Bloodmyst Isle,39.6,51.2,0
    .goto Bloodmyst Isle,43.2,42.6,0
    .goto Bloodmyst Isle,34.8,42.6,0
    .goto Bloodmyst Isle,35.6,53.8,70,0
    .goto Bloodmyst Isle,39.6,51.2,70,0
    .goto Bloodmyst Isle,43.2,42.6,70,0
    .goto Bloodmyst Isle,34.8,42.6,70,0
	>>击杀 |cRXP_ENEMY_鲜艳的蓝翼巨蛾|r
    .complete 9647,1 --Kill Royal Blue Flutterer (x10)
    .mob 鲜艳的蓝翼巨蛾
step
    .goto Bloodmyst Isle,30.750,46.844
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官考尔琳|r 对话
    .turnin 10066 >> 交任务 纠结之网
    .target 守备官考尔琳
step
    .goto Bloodmyst Isle,30.255,45.916
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斥候约莉|r 对话
    .turnin 10065 >> 交任务 披荆斩棘
    .target 斥候洛伊
step
    #loop
    .goto Bloodmyst Isle,30.93,39.05,0
	.goto Bloodmyst Isle,27.58,37.09,0
    .goto Bloodmyst Isle,30.18,34.38,0
	.goto Bloodmyst Isle,30.93,39.05,70,0
	.goto Bloodmyst Isle,27.58,37.09,70,0
    .goto Bloodmyst Isle,30.18,34.38,70,0
	>>击杀 |cRXP_ENEMY_污秽的水之魂|r
    .complete 10067,1 --Kill Fouled Water Spirit (x6)
    .mob 污秽的水之魂
step
    .goto Bloodmyst Isle,30.750,46.844
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官考尔琳|r 对话
    .turnin 10067 >> 交任务 污秽的水之魂
    .target 守备官考尔琳
step
    .goto Bloodmyst Isle,24.862,34.375
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_研究员考内留斯|r 对话
    .accept 9670 >> 接受任务 他们还活着！也许……
    .target 研究员考内留斯
step
	#completewith next
	>>击杀 |cRXP_ENEMY_被蛛网缠住的生物|r
    >>|cRXP_WARN_Attack the |cRXP_ENEMY_Webbed Creatures|r from range if possible incase a hostile mob pops out, it won't aggro you|r (NOT TRANSLATED IN :zhCN YET)
    .complete 9670,1 --Expedition Researcher Freed (5)
    .mob 被网住的生物
step
    .goto Bloodmyst Isle,21.4,36.0,60,0
    .goto Bloodmyst Isle,17.2,28.4,40,0
    .goto Bloodmyst Isle,18.2,38.0
	>>在琥珀蛛网小径上击杀 |cRXP_ENEMY_秘网吸血者|r、|cRXP_ENEMY_秘网编织者|r 和 |cRXP_ENEMY_萨拉肯|r
    .complete 9669,1 --Kill Myst Leecher (x8)
    .mob 秘网吸血者
    .complete 9669,2 --Kill Myst Spinner (x8)
    .mob 秘网编织者
    .complete 9669,3 --Kill Zarakh (x1)
    .mob 萨拉肯
step
    .goto Bloodmyst Isle,21.4,36.0,60,0
    .goto Bloodmyst Isle,17.2,28.4,40,0
    .goto Bloodmyst Isle,18.2,38.0
	>>击杀 |cRXP_ENEMY_被蛛网缠住的生物|r
    >>|cRXP_WARN_Attack the |cRXP_ENEMY_Webbed Creatures|r from range if possible incase a hostile mob pops out, it won't aggro you|r (NOT TRANSLATED IN :zhCN YET)
    .complete 9670,1 --Expedition Researcher Freed (5)
    .mob 被网住的生物
step
    .goto Bloodmyst Isle,24.862,34.375
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_研究员考内留斯|r 对话
    .turnin 9670 >> 交任务 他们还活着！也许……
    .target 研究员考内留斯
step
    .goto Bloodmyst Isle,34.373,33.742
	.use 24318 >>|cRXP_WARN_使用|r |T134870:0|t[水样瓶] |cRXP_WARN_在瀑布底部|r
    .complete 9748,1 --Collect Bloodmyst Water Sample (x1)
step
    .isOnQuest 9748,9669,9741,9711
    .hs >> 炉石到血环堡
    >>|cRXP_BUY_如有需要，购买食物/水|r << !Warrior !Rogue
	>>|cRXP_BUY_需要的话就买点食物|r << Warrior/Rogue
    .cooldown item,6948,>2,1
step
    .goto Bloodmyst Isle,53.245,57.031
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿彻鲁斯|r 对话
    .turnin 9669 >> 交任务 覆灭的远征队
    .target 阿彻鲁斯
step
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .turnin 9741 >> 交任务 虚空幼体
    .turnin 9748 >> 交任务 毒水
    .accept 9746 >> 接受任务 精疲力尽 << Hunter/Shaman/Mage
    .target 守备官伊索姆
step
    .isQuestComplete 9711
    .goto Bloodmyst Isle,55.631,55.223
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官库卢斯|r 对话
    .turnin 9711 >> 交任务 残忍的玛提斯
    .target 守备官库卢斯
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9580
    .isQuestComplete 9647
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9580 >> 交任务 猎熊
    .turnin 9647 >> 交任务 消灭巨蛾
    .target 追踪者兰塞恩
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9580 >> 交任务 猎熊
    .target 追踪者兰塞恩
step
    #optional
    .goto Bloodmyst Isle,55.862,56.997
    .isQuestComplete 9647
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_追踪者兰塞恩|r 对话
    .turnin 9647 >> 交任务 消灭巨蛾
    .target 追踪者兰塞恩
step << Hunter/Mage
    #loop
    .goto Bloodmyst Isle,26.2,52.6,0
    .goto Bloodmyst Isle,23.8,56.0,0
    .goto Bloodmyst Isle,23.8,60.8,0
    .goto Bloodmyst Isle,26.2,52.6,70,0
    .goto Bloodmyst Isle,23.8,56.0,70,0
    .goto Bloodmyst Isle,23.8,60.8,70,0
    .goto Bloodmyst Isle,22.0,62.6,70,0
    .goto Bloodmyst Isle,23.5,49.4,70,0
    >>击杀 |cRXP_ENEMY_炎鹰火法师|r 和 |cRXP_ENEMY_炎鹰防御者|r
    .complete 9746,1 --Kill Sunhawk Pyromancer (x10)
    .mob 炎鹰火法师
    .complete 9746,2 --Kill Sunhawk Defender (x10)
    .mob 炎鹰防御者
step << Hunter/Mage
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .turnin 9746 >> 交任务 精疲力尽
    .target 守备官伊索姆
step
    #completewith next
    .subzone 3591 >> 前往洛雷萨兰遗址
step
    .goto Bloodmyst Isle,61.173,49.639
    >>点击地上的 |cRXP_PICK_一堆泥土|r
    .turnin 9561 >> 交任务 诺尔凯的日记
step
    #completewith next
    .subzone 3598 >> 前往弗雷岛
step
    .goto Bloodmyst Isle,74.7,33.7
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    >>|cRXP_FRIENDLY_托雷斯王子|r |cRXP_WARN_会稍微来回走动|r
    .turnin 9687 >> 交任务 找回尊严
    .accept 9688 >> 接受任务 进入梦境
    .target 托雷斯王子
step
	#completewith next
    >>击杀 |cRXP_ENEMY_绿色雏龙|r 和 |cRXP_ENEMY_绿色龙崽|r
    .complete 9688,1 --Kill Veridian Whelp (x5)
    .mob 绿色雏龙
    .complete 9688,2 --Kill Veridian Broodling (x5)
    .mob 绿色龙崽
step
    #optional
    .isQuestComplete 9683
    .goto Bloodmyst Isle,79.150,22.656
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    .turnin 9683 >> 交任务 血咒的终结
    .target 艾德华·汉斯船长
step
    #loop
    .goto Bloodmyst Isle,75.2,29.8,0
    .goto Bloodmyst Isle,69.6,27.6,0
    .goto Bloodmyst Isle,68.6,22.2,0
    .goto Bloodmyst Isle,70.8,16.6,0
    .goto Bloodmyst Isle,76.8,16.6,0
    .goto Bloodmyst Isle,78.0,24.2,70,0
    .goto Bloodmyst Isle,75.2,29.8,70,0
    .goto Bloodmyst Isle,69.6,27.6,70,0
    .goto Bloodmyst Isle,68.6,22.2,70,0
    .goto Bloodmyst Isle,70.8,16.6,70,0
    .goto Bloodmyst Isle,76.8,16.6,70,0
    >>击杀 |cRXP_ENEMY_绿色雏龙|r 和 |cRXP_ENEMY_绿色龙崽|r
    .complete 9688,1 --Kill Veridian Whelp (x5)
    .mob 绿色雏龙
    .complete 9688,2 --Kill Veridian Broodling (x5)
    .mob 绿色龙崽
step
    .goto Bloodmyst Isle,74.7,33.7
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    >>|cRXP_FRIENDLY_托雷斯王子|r |cRXP_WARN_会稍微来回走动|r
    .turnin 9688 >> 交任务 进入梦境
    .accept 9689 >> 接受任务 刺喉
    .target 托雷斯王子
step
    #completewith next
    .goto Bloodmyst Isle,72.650,21.006
    .cast 31268 >>点击山顶地上的 |cRXP_PICK_永燃火堆|r 来召唤 |cRXP_ENEMY_刺喉|r
    .timer 36,刺喉 剧情
step
    .goto Bloodmyst Isle,73.129,20.587
    >>击杀 |cRXP_ENEMY_刺喉|r
    >>|cRXP_ENEMY_刺喉|r |cRXP_WARN_是一名20级精英怪，大约需要35秒才会降落|r
    >>|cRXP_WARN_这个任务非常困难。如有需要请组队完成。如果你找不到队伍或无法单刷，就跳过这一步|r
    >>|cRXP_WARN_记得在需要时对自己或队友施放|r |T135923:0|t[纳鲁的赐福] |cRXP_WARN_|r << Draenei
    .complete 9689,1 --Kill Razormaw (x1)
    .mob 刺喉
step
    .isQuestComplete 9689
    .goto Bloodmyst Isle,74.7,33.7
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_托雷斯王子|r 对话
    >>|cRXP_FRIENDLY_托雷斯王子|r |cRXP_WARN_会稍微来回走动|r
    .turnin 9689 >> 交任务 刺喉
    .target 托雷斯王子
step
    #optional
	.abandon 9711 >> 如果你没有完成 残忍的玛提斯，请放弃该任务
step
    #optional
	.abandon 9689 >> 如果你没有完成 刺喉，请放弃该任务
step << Hunter/Shaman/Mage
    .xp 20 >> 刷怪升级到 20 级
step
	#completewith FlyExo
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step << Paladin
    #completewith FlyExo
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .trainer >> 训练你的职业技能
    .target 守备官伊索姆
step
    #label FlyExo
    .goto Bloodmyst Isle,57.680,53.875
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .fly The Exodar>> 飞往埃索达
    .target 兰度
    .zoneskip Bloodmyst Isle,1
step << Shaman/Hunter/Priest/Mage/Warrior
    #completewith NewfoundAllies
    .goto The Exodar,73.682,53.701,15 >> 前往埃索达内部
step << Shaman
    .goto The Exodar,32.450,23.996
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_苏兰|r 对话
    .accept 9502 >> 接受任务 水之召唤
    .trainer >> 训练你的职业技能
    .target 苏兰
step << Shaman
    #completewith next
    .goto The Exodar,27.90,29.43,10 >> 沿斜坡前去找 |cRXP_FRIENDLY_先知诺布杜|r
step << Shaman
    .goto The Exodar,31.27,27.65,15,0
    .goto The Exodar,29.76,33.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_预言者努波顿|r 对话
    >>|cRXP_FRIENDLY_预言者努波顿|r |cRXP_WARN_偶尔巡逻|r
    .turnin 9502 >> 交任务 水之召唤
    .accept 9501 >> 接受任务 水之召唤
    .target 预言者努波顿
step << Shaman
    #completewith next
    .goto The Exodar,54.09,32.52,30,0
    .goto The Exodar,64.86,35.03,20,0
    .goto The Exodar,73.68,53.70,20 >> 离开埃索达
step << Shaman
    .goto The Exodar,68.351,63.490
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯泰法努斯|r 对话
    .fly Blood Watch >> 飞往血环堡
    .target 斯泰法努斯
    .zoneskip Bloodmyst Isle
step << Shaman
    #completewith next
    .subzone 3596 >> 前往隐秘暗礁
step << Shaman
    .goto Bloodmyst Isle,32.302,16.198
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿奎欧斯|r 对话
    .turnin 9501 >> 交任务 水之召唤
    .accept 9503 >> 接受任务 水之召唤
    .target 阿奎欧斯
step << Shaman
    #loop
    .goto Bloodmyst Isle,26.2,52.6,0
    .goto Bloodmyst Isle,23.8,56.0,0
    .goto Bloodmyst Isle,23.8,60.8,0
    .goto Bloodmyst Isle,26.2,52.6,70,0
    .goto Bloodmyst Isle,23.8,56.0,70,0
    .goto Bloodmyst Isle,23.8,60.8,70,0
    .goto Bloodmyst Isle,22.0,62.6,70,0
    .goto Bloodmyst Isle,23.5,49.4,70,0
    >>击杀 |cRXP_ENEMY_炎鹰火法师|r 和 |cRXP_ENEMY_炎鹰防御者|r
    .complete 9746,1 --Kill Sunhawk Pyromancer (x10)
    .mob 炎鹰火法师
    .complete 9746,2 --Kill Sunhawk Defender (x10)
    .mob 炎鹰防御者
step << Shaman
    #loop
    .goto Bloodmyst Isle,30.93,39.05,0
	.goto Bloodmyst Isle,27.58,37.09,0
    .goto Bloodmyst Isle,30.18,34.38,0
	.goto Bloodmyst Isle,30.93,39.05,70,0
	.goto Bloodmyst Isle,27.58,37.09,70,0
    .goto Bloodmyst Isle,30.18,34.38,70,0
	>>击杀 |cRXP_ENEMY_污秽的水之魂|r。拾取他们的 |cRXP_LOOT_邪恶精华|r
    .complete 9503,1 --Collect Foul Essence (x6)
    .mob 污秽的水之魂
step << Shaman
    .goto Bloodmyst Isle,32.302,16.198
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿奎欧斯|r 对话
    .turnin 9503 >> 交任务 水之召唤
    .accept 9504 >> 接受任务 水之召唤
    .target 阿奎欧斯
step << Shaman
	#completewith ShamFlyExo
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step << Shaman
    .goto Bloodmyst Isle,55.551,55.397
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官伊索姆|r 对话
    .turnin 9746 >> 交任务 精疲力尽
    .target 守备官伊索姆
step << Shaman
    #label ShamFlyExo
    .goto Bloodmyst Isle,57.680,53.875
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰度|r 对话
    .fly The Exodar>> 飞往埃索达
    .target 兰度
    .zoneskip Bloodmyst Isle,1
step << Hunter
	.goto The Exodar,47.573,88.340
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_沃尔德|r 对话
	.trainer >> 训练你的职业技能
    .target 沃尔德
step << Hunter
    .goto The Exodar,44.240,86.612
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_甘纳尔|r 对话
	.trainer >> 训练你的宠物技能
    .target 甘纳尔
step << Priest
    #ah
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧斯|r 对话
    >>|cRXP_BUY_从他那里|r购买1把|cRXP_BUY_ |T135139:0|t[燃烧魔杖]，或者查看拍卖行寻找更好的|r
    .goto The Exodar,46.386,61.499
    .goto The Exodar,63.363,58.999,0
    .collect 5210,1 --Burning Wand (1)
    .target 欧斯
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.5
    --not adding .money tag to this step. user could have less silver than vendor wand but cheaper ones may exist on the AH
step << Priest
    #ssf
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_欧斯|r 对话
    >>|cRXP_BUY_购买1把|r |T135139:0|t[燃烧魔杖]|cRXP_BUY_从他那里|r
    .goto The Exodar,46.386,61.499
    .collect 5210,1 --Burning Wand (1)
    .target 欧斯
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.5
    .money <0.5808
step << Priest
    #optional
    +|cRXP_WARN_装备|r |T135139:0|t[燃烧魔杖]
    .use 5210
    .itemcount 5210,1
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.5
step << Priest
    .goto The Exodar,39.436,51.061
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_伊兹米尔|r 对话
    .trainer >> 训练你的职业技能
    .target 伊兹米尔
step << Mage
    .goto The Exodar,47.228,62.305
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_伊迪拉恩|r 对话
    .trainer >> 训练你的职业技能
    .target 伊迪拉恩
step << Mage
	.goto The Exodar,45.986,62.685
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_鲁纳尔兰|r 对话
    .train 32271 >> 训练 |T135756:0|t[传送：埃索达]
    .target 鲁纳尔兰
step << Mage
    .goto The Exodar,44.765,63.202
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_穆萨尔|r 对话
    >>|cRXP_BUY_从她那里|r购买至少1枚 |cRXP_BUY_|T134419:0|t[传送符文]|r
    .collect 17031,1 --Rune of Teleportation (1)
    .target 穆萨尔
step << Warrior
    #completewith next
    .goto The Exodar,53.39,85.68,15,0
    .goto The Exodar,50.50,81.28,20 >> 上楼梯前往顶层的 |cRXP_FRIENDLY_贝霍玛特|r
step << Warrior
    .goto The Exodar,55.580,82.290
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_贝霍玛特|r 对话
    .trainer >> 训练你的职业技能
    .target 贝霍玛特
step
    #label NewfoundAllies
	.goto The Exodar,33.8,73.7,15,0 << !Shaman
    .goto Azuremyst Isle,24.183,54.341
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_女猎手凯拉·夜弓|r 对话
    >>|cRXP_FRIENDLY_Huntress Kella Nightbow|r |cRXP_WARN_is located outside the back entrance of The Exodar|r (NOT TRANSLATED IN :zhCN YET)
    .turnin 9632 >> 交任务 新的盟友
    .accept 9633 >> 接受任务 前往奥伯丁
    .target 女猎手凯拉·夜弓
step
    .goto Azuremyst Isle,20.405,54.184
    .zone Darkshore >> 乘船前往黑海岸

--Continued below is .dungeon DM only
step
.dungeon DM
    .goto Darkshore,37.04,44.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_旅店老板莎希因|r 对话
    .home >> 将你的炉石设为奥伯丁
    .target 旅店老板莎希因
    .bindlocation 442
step
.dungeon DM
    #completewith next
    .goto 1439,32.432,43.744,15 >> 前往米奈希尔港码头
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Westfall
    .zoneskip Wetlands
step
.dungeon DM
    #optional
    .goto Darkshore,32.29,44.05
    >>|cRXP_WARN_你现在将开始前往死亡矿井|r
    .zone Wetlands >> 乘船前往米奈希尔港
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Westfall
step << Paladin/Warrior
.dungeon DM
    #ah
    .goto 1437,11.579,59.540,6,0
    .goto 1437,11.435,59.696
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_布拉克·唐纳德|r 对话，NPC在里面
    .vendor 1441 >>|cRXP_BUY_向他购买|r |T135329:0|t[刽子手之剑] |cRXP_BUY_（如果有货且你买得起）|r
    >>|cRXP_WARN_或者你也可以稍后去拍卖行看看是否有更好或更便宜的替代品|r
    .collect 4818,1 --Collect Executioner's Sword (1)
    .target 掘泥打击者
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
step << Paladin/Warrior
.dungeon DM
    #ssf
    .goto 1437,11.579,59.540,6,0
    .goto 1437,11.435,59.696
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_布拉克·唐纳德|r 对话，NPC在里面
    .vendor 1441 >>|cRXP_BUY_向他购买|r |T135329:0|t[刽子手之剑] |cRXP_BUY_（如果有货且你买得起）|r
    .collect 4818,1 --Collect Executioner's Sword (1)
    .target +掠沙蜘蛛
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
    .money <1.3559
step << Paladin/Warrior
.dungeon DM
    #optional
    #completewith DeeprunDM
    +|cRXP_WARN_装备|r |T135329:0|t[刽子手之剑]
    .use 4818
    .itemcount 4818,1
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
step
.dungeon DM
    .goto Wetlands,9.490,59.694
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_谢尔雷·布隆迪尔|r 对话
    .fp Menethil Harbor >> 获取米奈希尔港的飞行路径
    .target 谢尔雷·布隆迪尔
step
.dungeon DM
    #optional
    #completewith next
    .goto Wetlands,5.485,64.156,40 >> 从码头尽头跳下水，游向指示点
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Ironforge
    .zoneskip Westfall
step
.dungeon DM
    .goto Wetlands,2.433,78.689,-1
    .goto Ironforge,17.089,83.373,-1
    .zone Ironforge >>使用角色脱困自助功能直接跳转到铁炉堡。你需要先在指定位置下线，然后用另一个角色进入帮助菜单 (或者把下面的脱困链接粘贴到浏览器中)，向下滚动找到自助服务。选择你的角色并点击移动。如果无法成功脱困，请跳过此步骤，沿着山脉游泳前往西部荒野
    .link https://www.youtube.com/watch?v=oVoxsr4zcg4 >> |cRXP_WARN_点击此处查看视频参考|r
    .link https://us.battle.net/support/en/help/product/wow/197/834/solution >> |cRXP_WARN_点击此处查看美服角色卡住（脱困）链接|r
    .link https://eu.battle.net/support/en/article/32275 >> |cRXP_WARN_点击此处查看欧服角色卡住（脱困）链接|r
    .subzoneskip 809 --IF Gates
    .subzoneskip 2257 --Deeprun Tram
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Ironforge
    .zoneskip Westfall
step << Mage
.dungeon DM
    .goto Ironforge,25.50,7.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_贝尔斯塔弗·风暴之眼|r 对话
    .train 3562 >> 学习 |T135757:0|t[传送：铁炉堡]
    .target 贝尔斯塔弗·风暴之眼
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Westfall
    .zoneskip Wetlands
step
.dungeon DM
    #optional
    .goto 1415/0,258.6045,-4078.9674,60,0 -- Wetlands to Westfall swim
    .goto 1415/0,807.0190,-4254.0282,60,0
    .goto 1415/0,1017.5144,-4474.1449,20,0
    .goto 1415/0,1088.2662,-4457.2490,20,0
    .goto 1415/0,1327.9775,-4321.1427,20,0
    .goto 1415/0,1582.4728,-4300.0228,20,0
    .goto 1415/0,1984.1037,-4519.6701,20,0
    .goto 1415/0,1998.1836,-4645.6858,30,0
    .goto 1415/0,2094.2794,-4885.2798,30,0
    .goto 1415/0,1863.7200,-5311.1986,20,0
    .goto 1415/0,1742.2803,-5324.3399,20,0
    .goto 1415/0,1437.8012,-5938.9302,40,0
    .goto 1415/0,1220.2658,-6480.5393,30,0
    .goto 1415/0,1447.6572,-6898.2448,30,0
    .goto 1415/0,1459.2731,-7068.1430,20,0
    .goto 1415/0,1728.2004,-7578.0722,30,0
    .goto 1415/0,1544.8089,-7992.7270,20,0
    .goto 1415/0,1445.1932,-8083.5428,30,0
    .goto 1415/0,1440.2652,-8254.8490,30,0
    .goto 1415/0,1348.0415,-8417.7072,30,0
    .goto StormwindClassic,4.493,29.157,20,0
    .goto StormwindClassic,10.336,40.166,10,0
    .goto StormwindClassic,7,45.471,10,0
    .goto StormwindClassic,5.560,50.125,10,0
    .goto StormwindClassic,13.669,74.499,20,0
    .goto Westfall,42.024,70.980
    .zone Westfall >> 如果网站卡死不可用，请游泳前往西部荒野
    .zoneskip Ironforge
    .subzoneskip 809--IF Gates
    .subzoneskip 2257--Deeprun Tram
    .zoneskip Stormwind City
step
.dungeon DM
    #optional
    #completewith next
    .goto Westfall,54.28,9.26,100,0
    .goto Westfall,56.55,52.64,100 >> 沿着海岸跑上去，前往哨兵岭
    .zoneskip Ironforge
    .subzoneskip 809
    .subzoneskip 2257
    .zoneskip Stormwind City
step
.dungeon DM
    #optional
    .goto Westfall,56.55,52.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_索尔|r 对话
    .fp Sentinel Hill >> 获取哨兵岭的飞行路径
    .target 索尔
    .zoneskip Ironforge --Skips if you didn't swim from Wetlands
    .subzoneskip 809
    .subzoneskip 2257
    .zoneskip Stormwind City
step
.dungeon DM
    #optional
    .goto Ironforge,55.491,47.751
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_格莱斯·瑟登|r 对话
    .fp Ironforge >> 获取铁炉堡的飞行路径
    .target 格莱斯·瑟登
    .zoneskip Wetlands
    .zoneskip Elwynn Forest
    .zoneskip Westfall
    .zoneskip Stormwind City
step
.dungeon DM
    #optional
    .goto Ironforge,78.00,51.40
    .subzone 2257 >>进入矿道地铁
    .zoneskip Wetlands << NightElf/Draenei
    .zoneskip Elwynn Forest
    .zoneskip Stormwind City
    .zoneskip Westfall
step
.dungeon DM
    #optional
    .goto Elwynn Forest,36.809,72.429,100,0
    .goto StormwindClassic,69.961,86.583
    .zone Stormwind City >> 跑到暴风城
    .zoneskip Ironforge
    .subzoneskip 809
    .subzoneskip 2257
step
.dungeon DM
    #optional << NightElf/Draenei
    #completewith CollectingMemories
    .zone Stormwind City >> 乘坐地铁前往暴风城
    .zoneskip Wetlands << NightElf/Draenei
    .zoneskip Elwynn Forest
    .zoneskip Westfall
step
.dungeon DM
    .goto StormwindClassic,55.510,12.504
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_沉默的舒尼|r 对话
    .accept 2040 >> 接受任务 地底突袭
    .target 沉默的舒尼
step
.dungeon DM
    #label CollectingMemories
    .goto StormwindClassic,65.438,21.175
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_维尔德·蓟草|r 对话
    .accept 167 >> 接受任务 我的兄弟……
    .accept 168 >> 接受任务 收集记忆
    .target 维尔德·蓟草
step
.dungeon DM
    .isQuestAvailable 1275
    .goto StormwindClassic,21.40,55.80
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_阿古斯·夜语|r 对话
    .accept 3765 >> 接受任务 遥远的旅途
    .target 阿古斯·夜语
step
.dungeon DM
    .goto StormwindClassic,57.12,57.69
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_吴平|r 对话
    .train 201 >> 学习单手剑 << Mage/Rogue/Warlock
    .train 1180 >> 学习 匕首 << Mage/Druid/Priest
    .train 202 >> 学习双手剑 << Warrior/Paladin/Hunter
    .target 吴平
step << Mage
.dungeon DM
    .goto StormwindClassic,39.68,79.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_拉瑞曼|r 对话
    .train 3561 >> 学习 |T135763:0|t[传送：暴风城]
	.xp <20,1
    .target 拉瑞麦尼·普尔度
step
.dungeon DM
    #completewith GryanAll
    .goto StormwindClassic,57.816,58.331,30,0
    .goto StormwindClassic,63.301,62.103,30,0
    .goto StormwindClassic,63.047,65.744,15,0
    .goto StormwindClassic,66.276,62.135
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_杜加尔·朗德瑞克|r 对话
    .fp Stormwind >> 获取暴风城的飞行路径 << !Human
    .fly Westfall >> 如果你刚从西部荒野来，就飞回去，否则就跑过去
    .disablecheckbox
    .target 杜加尔·朗德瑞克
    .zoneskip Westfall
step << !Human
.dungeon DM
    #optional
    #completewith next
    .zone Westfall >> 前往西部荒野
step << !Human
.dungeon DM
    #optional
    .goto Westfall,56.55,52.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_索尔|r 对话
    .fp Sentinel Hill >> 获取哨兵岭的飞行路径
    .target 索尔
step
.dungeon DM
    .goto 1436,56.454,69.982,0
    .goto 1436,56.434,74.339,0
    .goto 1436,59.384,74.184,0
    .goto 1436,60.871,74.362,0
    .goto 1436,60.902,77.640,0
    .goto 1436,63.442,77.339,0
    .goto 1436,65.203,75.286,0
    .goto 1436,63.594,72.862,0
    .goto 1436,63.825,70.125,0
    .goto 1436,42.649,71.376
    >>|cRXP_WARN_在哨兵岭南侧刷 |cRXP_ENEMY_豺狼人|r，同时组建一个死亡矿井队伍|r
    .subzone 20 >>当你的小队集结完毕后，前往月溪镇
step
.dungeon DM
    .goto Westfall,42.55,71.69
    .subzone 1581 >> 与小队一起进入迪菲亚斯藏身处
step
.dungeon DM
    #completewith EnterDM
    >>击杀 |cRXP_ENEMY_迪菲亚|r。拾取他们身上的 |cRXP_LOOT_红色丝质头巾|r
    >>|cRXP_WARN_你也可以在死亡矿井副本内完成这个|r
    .complete 214,1 -- Red Silk Bandana (10)
    .isOnQuest 214
step
.dungeon DM
    #completewith next
    >>击杀 |cRXP_ENEMY_骷髅矿工|r、|cRXP_ENEMY_亡灵爆破者|r 和 |cRXP_ENEMY_亡灵挖掘者|r，拾取他们的 |cRXP_LOOT_卡片|r
    >>|cRXP_WARN_该任务需要在副本外完成|r
    .complete 168,1 -- Miners' Union Card (4)
    .mob 骷髅矿工
    .mob 亡灵爆破者
    .mob 亡灵挖掘者
step
.dungeon DM
    .goto 1415/0,1504.6810,-11259.7472,25,0
    .goto 1415/0,1557.4809,-11297.2937,25,0
    .goto 1415/0,1596.2008,-11318.4137,25,0
    .goto 1415/0,1539.8809,-11332.4936
    >>击杀 |cRXP_ENEMY_工头希斯耐特|r，拾取他的 |cRXP_LOOT_徽章|r
    >>|cRXP_WARN_该任务需要在副本外完成|r
    .complete 167,1 -- Thistlenettle's Badge (1)
    .unitscan 工头希斯耐特
step
.dungeon DM
    .goto 1415/0,1504.6810,-11259.7472,25,0
    .goto 1415/0,1557.4809,-11297.2937,25,0
    .goto 1415/0,1596.2008,-11318.4137,25,0
    .goto 1415/0,1539.8809,-11332.4936
    >>击杀 |cRXP_ENEMY_骷髅矿工|r、|cRXP_ENEMY_亡灵爆破者|r 和 |cRXP_ENEMY_亡灵挖掘者|r，拾取他们的 |cRXP_LOOT_卡片|r
    >>|cRXP_WARN_该任务需要在副本外完成|r
    .complete 168,1 -- Miners' Union Card (4)
    .mob 骷髅矿工
    .mob 亡灵爆破者
    .mob 亡灵挖掘者
step
.dungeon DM
    #label EnterDM
    .goto 1415/0,1589.1608,-11250.3605,25,0
    .goto 1415/0,1617.3207,-11217.5073,20,0
    .goto 1415/0,1681.3845,-11207.6513
    .subzone 1581,2 >> 进入死亡矿井副本
step
.dungeon DM
    #softcore
    #optional
    #completewith VanCleef
    >>击杀死亡矿井内的 |cRXP_ENEMY_迪菲亚|r，拾取他们的 |cRXP_LOOT_红色丝质面罩|r
    .complete 214,1 -- Red Silk Bandana (10)
    .isOnQuest 214
step
.dungeon DM
    >>击杀 |cRXP_ENEMY_斯尼德|r，拾取他的 |cRXP_LOOT_小型高能发动机|r
    .complete 2040,1 -- Gnoam Sprecklesprocket (1)
step
.dungeon DM
    >>击杀 |cRXP_ENEMY_艾德温·范克里夫|r，拾取他的 |cRXP_LOOT_头颅|r 以及 |T133471:0|t[|cRXP_LOOT_未寄出的信|r]
    .collect 2874,1,373,1 -- An Unsent Letter (1)
    .complete 166,1 -- Head of VanCleef (1)
    .isOnQuest 166
step
.dungeon DM
    #label VanCleef
    >>击杀 |cRXP_ENEMY_艾德温·范克里夫|r。拾取 |T133471:0|t[|cRXP_LOOT_未寄出的信|r]
    .collect 2874,1,373,1 -- An Unsent Letter (1)
step
.dungeon DM
    #optional
    #completewith DeadminesEnd
    .goto 1436,38.909,84.014
    .subzone 920 >>从 |cRXP_ENEMY_艾德温·范克里夫|r 东侧的后门离开死亡矿井
    .zoneskip Stormwind City
    .zoneskip Westfall
    .zoneskip 1415
step
.dungeon DM
    .isQuestComplete 166
    .goto Westfall,56.33,47.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_格里安·斯托曼|r 对话
    .turnin 166 >> 交任务 迪菲亚兄弟会
    .target 格里安·斯托曼
step
.dungeon DM
    .isQuestComplete 214
    .goto Westfall,56.67,47.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与塔顶的 |cRXP_FRIENDLY_哨兵瑞尔|r 对话
    .turnin 214 >> 交任务 红色丝质面罩
    .target 哨兵瑞尔
step << Mage
.dungeon DM
    #optional
    .cast 3561 >>|cRXP_WARN_施放|r |T135763:0|t[传送：暴风城]
    .zoneskip Stormwind City
step << Mage
.dungeon DM
    #optional
    .goto 1453,36.863,81.132
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与塔顶的 |cRXP_FRIENDLY_艾尔莎林|r 对话
    .train 2138 >> 训练你的职业技能
    .target 艾尔莎林
    .xp <22,1
step << !Mage
.dungeon DM
    #completewith ShoniEnd
    #label DeadminesEnd
    .goto Westfall,56.55,52.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_索尔|r 对话
    .fly Stormwind >> 飞往暴风城
    .zoneskip Stormwind City
    .target 索尔
step << Warlock
.dungeon DM
    #optional
    #completewith next
    .goto StormwindClassic,29.2,74.0,20,0
    .goto StormwindClassic,27.2,78.1,15 >> 进入屠宰场。下楼
    .xp <22,1
step << Warlock
.dungeon DM
    #optional
    .goto StormwindClassic,26.117,77.225
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_厄苏拉·德林|r 对话
    .train 6202 >> 训练你的职业技能
    .target 厄苏拉·德林
    .xp <22,1
step << Paladin
.dungeon DM
    #optional
    #completewith next
    .goto 1453,42.917,34.221,15,0
    .goto 1453,41.385,31.547,15,0
    .goto 1453,39.810,29.788,15
    .goto StormwindClassic,42.51,33.51,20 >> 前往暴风城大教堂内，与 |cRXP_FRIENDLY_达索瑞恩·拉尔|r 对话
    .xp <22,1
step << Paladin
.dungeon DM
    #optional
    .goto StormwindClassic,38.58,32.00,12,0
    .goto StormwindClassic,38.67,32.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_虔诚的亚瑟|r 对话
    .train 19835 >> 训练你的职业技能
    .target 虔诚的亚瑟
    .xp <22,1
step << Priest
.dungeon DM
    #optional
    #completewith next
    .goto StormwindClassic,42.51,33.51,20,0
    .goto StormwindClassic,38.54,26.86,20 >> 前往暴风城大教堂内的 |cRXP_FRIENDLY_高阶牧师劳瑞娜|r 附近
    .xp <22,1
step << Priest
.dungeon DM
    #optional
    .goto StormwindClassic,38.54,26.86
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与里面的 |cRXP_FRIENDLY_高阶牧师劳瑞娜|r 对话
    .train 8103 >> 训练你的职业技能
    .target 高阶牧师劳瑞娜
    .xp <22,1
step << Warrior
.dungeon DM
    #optional
    #completewith next
    .goto 1453,74.592,51.567,15,0
    .goto 1453,78.011,47.797,15,0
    .goto 1453,80.030,45.591,12 >> 前往指挥中心内的 |cRXP_FRIENDLY_武神|r 附近
    .xp <22,1
step << Warrior
.dungeon DM
    #optional
    .goto 1453,78.673,45.791
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_武神|r 对话
    .train 6192 >> 训练你的职业技能
    .target 武神
    .xp <22,1
step
.dungeon DM
    .goto StormwindClassic,48.079,30.913,10,0
    .goto StormwindClassic,49.193,30.285
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_巴隆斯·阿历克斯顿|r 对话
    .use 2874 >>|cRXP_WARN_使用 |T133471:0|t[|cRXP_LOOT_未寄出的信|r] 来开始任务|r
    .accept 373 >> 接受任务 未寄出的信
    .turnin 373 >> 交任务 未寄出的信
    .accept 389 >> 接受任务 巴基尔·斯瑞德
    .target 巴隆斯·阿历克斯顿
step
.dungeon DM
    .isQuestTurnedIn 373 -- DM Unsent Letter
    .goto StormwindClassic,42.435,59.236,10,0
    .goto StormwindClassic,41.102,58.091
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_典狱官塞尔沃特|r 对话
    .turnin 389 >> 交任务 巴基尔·斯瑞德
    .target 典狱官塞尔沃特
step
.dungeon DM
    .goto StormwindClassic,65.438,21.175
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与里面的 |cRXP_FRIENDLY_维尔德·蓟草|r 对话
    .turnin 167 >> 交任务 我的兄弟……
    .turnin 168 >> 交任务 收集记忆
    .target 维尔德·蓟草
step << skip --Hunter - nothing good to train at 22
.dungeon DM
    .goto StormwindClassic,61.609,15.269
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与里面的 |cRXP_FRIENDLY_恩瑞斯·锐矛|r 对话
    .trainer >> 训练你的职业技能
    .target 恩瑞斯·锐矛
    .xp <22,1
step
.dungeon DM
    #label ShoniEnd
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_沉默的舒尼|r 对话
    .turnin 2040 >> 交任务 地底突袭
    .goto StormwindClassic,55.510,12.504
    .target 沉默的舒尼
step
.dungeon DM
    .goto StormwindClassic,55.21,7.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_比利巴布·旋轮|r 对话
    .vendor 5519 >> |cRXP_BUY_从他这里|r|T133024:0|t|cRXP_BUY_买一个|r [青铜管] (如果有)
--    >>You will need 2 bronze tubes for a quest later << Rogue
    .bronzetube
    .target 比利巴布·旋轮
step << Druid
.dungeon DM
	#completewith next
	.cast 18960 >> |cRXP_WARN_施放|r |T135758:0|t[传送：月光林地]
    .usespell 18960
	.zoneskip Moonglade
step << Druid
.dungeon DM
    #optional
    #completewith next
    .goto Moonglade,52.53,40.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_洛甘纳尔|r 对话
    .trainer >> 训练你的职业技能
    .target 洛甘纳尔
    .xp <22,1
step
.dungeon DM
    .hs >> 炉石回黑海岸
    >>|cRXP_BUY_如有需要，购买食物/水|r << !Warrior !Rogue
    >>|cRXP_BUY_需要的话就买点食物|r << Warrior/Rogue
    .zoneskip Darkshore
]])

RXPGuides.RegisterGuide([[
#tbc
#wotlk
#version 7
#group RestedXP 燃烧的远征 练级指南 (联盟)
<< Alliance
#xprate <1.5
#name 20-21 黑海岸 (德莱尼)
#subgroup RestedXP 联盟 20-32 级
#defaultfor Draenei
#next 21-23 灰谷 (德莱尼)

step
    .goto Darkshore,36.097,44.932
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古博·布拉普|r 对话
    .accept 1138 >> 接受任务 海中的水果
    .target 古博·布拉普
step
    .goto Darkshore,36.336,45.574
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯莱斯·月羽|r 对话
    .fp Auberdine >> 开启奥伯丁飞行点
    .target 凯莱斯·月羽
    .zoneskip Darkshore,1
step
    .goto Darkshore,37.219,44.227
    >>点击 |cRXP_PICK_通缉布告|r
    .accept 4740 >> 接受任务 通缉：莫克迪普！
step
    .goto Darkshore,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_巴瑞萨斯·月影|r 对话
    .accept 947 >> 接受任务 洞中的蘑菇
    .target 巴瑞萨斯·月影
step
    .goto Darkshore,39.043,43.555
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与楼上的 |cRXP_FRIENDLY_哨兵艾莉萨·星风|r 对话
    .accept 965 >> 接受任务 奥萨拉克斯之塔
    .target 哨兵艾莉萨·星风
step
    .goto Darkshore,38.107,41.165
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_高尔博德·钢手|r 对话
    .accept 982 >> 接受任务 深不可测的海洋
    .target 高尔博德·钢手
step
    .isOnQuest 9633
    .goto Darkshore,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_桑迪斯·织风|r 对话
	.turnin 9633 >> 交任务 前往奥伯丁
    .accept 10752 >> 接受任务 前往灰谷
    .target 桑迪斯·织风
step
    .goto Darkshore,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_桑迪斯·织风|r 对话
    .accept 10752 >> 接受任务 前往灰谷
    .target 桑迪斯·织风
step
    .goto Darkshore,38.83,29.37,10,0
    .goto Darkshore,38.236,28.800
    >>|cRXP_WARN_从破损船底进入 “银色清晨号”。潜入前确保你的呼吸条已满|r
    >>拾取地上的 |cRXP_LOOT_银色黎明的锁箱|r
    .complete 982,1 --Collect Silver Dawning's Lockbox (x1)
step
    .goto Darkshore,40.30,27.56,10,0
    .goto Darkshore,39.633,27.459
    >>|cRXP_WARN_从破损船底进入 “迷雾之纱号”。潜入前确保你的呼吸条已满|r
    >>拾取地上的 |cRXP_LOOT_迷雾面纱的锁箱|r
    .complete 982,2 --Collect Mist Veil's Lockbox (x1)
step
    #completewith GelkakGyromast
    >>击杀 |cRXP_ENEMY_暗礁蟹|r 和 |cRXP_ENEMY_硬壳潮行蟹|r，拾取他们的 |cRXP_LOOT_优质蟹肉|r
    .complete 1138,1 -- Fine Crab Chunks (6)
    .mob 硬壳潮行蟹
    .mob 暗礁蟹
step
    .goto Darkshore,56.655,13.485
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_基尔卡克·旋杆|r 对话
    .accept 2098 >> 接受任务 基尔卡克的钥匙
    .target 基尔卡克·旋杆
step
    #completewith next
    .goto Darkshore,56.10,16.88,0
    >>击杀 |cRXP_ENEMY_狂暴暗礁蟹|r 和 |cRXP_ENEMY_硬壳潮行蟹|r，拾取他们的 |cRXP_LOOT_基尔卡克钥匙的尾部|r
    >>注意 狂暴暗礁蟹|cRXP_WARN_ 的|cRXP_ENEMY_ |T132152:0|t[痛击] |r技能。它们的近战攻击可能会瞬间造成200点伤害|r
    .complete 2098,3 -- Bottom of Gelkak's Key
    .mob 狂暴暗礁蟹
    .mob 硬壳潮行蟹
step
    .goto Darkshore,54.93,12.19
    >>击杀 |cRXP_ENEMY_灰雾智者|r 和 |cRXP_ENEMY_灰雾潮行者|r，拾取他们的 |cRXP_LOOT_基尔卡克钥匙的中部|r
    >>注意 灰雾智者 的|cRXP_WARN_ |T136048:0|t[闪电箭] |cRXP_ENEMY_伤害，他们还会使用|r |T136052:0|t[治疗波]|r
    .complete 2098,2 -- Middle of Gelkak's Key (1)
    .mob 灰雾智者
    .mob 灰雾潮行者
step
    .goto Darkshore,55.59,16.98,45,0
    .goto Darkshore,53.76,18.96,45,0
    .goto Darkshore,51.34,22.00,45,0
    .goto Darkshore,56.63,12.08
    >>击杀 |cRXP_ENEMY_狂暴暗礁蟹|r 和 |cRXP_ENEMY_硬壳潮行蟹|r，拾取他们的 |cRXP_LOOT_基尔卡克钥匙的尾部|r
    >>注意 狂暴暗礁蟹|cRXP_WARN_ 的|cRXP_ENEMY_ |T132152:0|t[痛击] |r技能。它们的近战攻击可能会瞬间造成200点伤害|r
    .complete 2098,3 -- Bottom of Gelkak's Key
    .mob 狂暴暗礁蟹
    .mob 硬壳潮行蟹
step
    .goto Darkshore,59.29,13.22,55,0
    .goto Darkshore,61.40,9.40,50,0
    .goto Darkshore,61.51,12.66,50,0
    .goto Darkshore,61.24,15.38,50,0
    .goto Darkshore,61.40,9.40
    >>击杀 |cRXP_ENEMY_凶猛的森林陆行鸟|r，拾取它们的 |cRXP_LOOT_基尔卡克钥匙的头部|r
    .complete 2098,1 -- Top of Gelkak's Key (1)
    .mob 凶猛的森林陆行鸟
step
    .goto Darkshore,56.655,13.485
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_基尔卡克·旋杆|r 对话
    .turnin 2098 >> 交任务 基尔卡克的钥匙
    .accept 2078 >> 接受任务 基尔卡克的报复
    .target 基尔卡克·旋杆
step
    .goto Darkshore,55.803,18.291,10,0
    .goto Darkshore,56.655,13.485
    >>与 |cRXP_FRIENDLY_机械打手4100型|r 对话以开始护送任务
    >>护送 |cRXP_FRIENDLY_机械打手4100型|r 前往 |cRXP_FRIENDLY_基尔卡克·旋杆|r
    >>在其变为敌对后击杀 |cRXP_ENEMY_机械打手4100型|r
    .skipgossip
    .complete 2078,1
    .mob 机械打手4100型
step
    #label GelkakGyromast
    .goto Darkshore,56.655,13.485
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_基尔卡克·旋杆|r 对话
    .turnin 2078 >> 交任务 基尔卡克的报复
    .target 基尔卡克·旋杆
step
    #sticky
    #optional
    .destroy 7442 >> 删除 |T134459:0|t[基尔卡克的钥匙]，因为它已不再需要(不在你的钥匙链中)
step
    #loop
    .goto Darkshore,53.51,18.65,0
    .goto Darkshore,51.42,22.04,0
    .goto Darkshore,48.52,20.65,0
    .goto Darkshore,45.50,20.45,0
    .goto Darkshore,53.51,18.65,70,0
    .goto Darkshore,51.42,22.04,70,0
    .goto Darkshore,48.52,20.65,70,0
    .goto Darkshore,45.50,20.45,70,0
    >>击杀 |cRXP_ENEMY_暗礁蟹|r 和 |cRXP_ENEMY_硬壳潮行蟹|r，拾取他们的 |cRXP_LOOT_优质蟹肉|r
    .complete 1138,1 -- Fine Crab Chunks (6)
    .mob 硬壳潮行蟹
    .mob 暗礁蟹
step
    .goto Darkshore,54.973,24.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_巴苏尔·影击|r 对话
    .turnin 965 >> 交任务 奥萨拉克斯之塔
    .accept 966 >> 接受任务 奥萨拉克斯之塔
    .target 巴苏尔·影击
step
    #loop
    .goto Darkshore,55.231,26.508,0
    .goto Darkshore,56.194,27.071,0
    .goto Darkshore,56.047,26.586,0
    .goto Darkshore,55.231,26.508,50,0
    .goto Darkshore,55.369,27.025,50,0
    .goto Darkshore,55.763,26.695,50,0
    .goto Darkshore,55.815,26.972,50,0
    .goto Darkshore,56.194,27.071,50,0
    .goto Darkshore,56.790,27.621,50,0
    .goto Darkshore,57.278,26.311,50,0
    .goto Darkshore,57.046,26.234,50,0
    .goto Darkshore,56.544,26.598,50,0
    .goto Darkshore,56.047,26.586,50,0
    .goto Darkshore,55.743,25.915,50,0
    >>击杀 |cRXP_ENEMY_暗滩狂热者|r，拾取他们的 |cRXP_LOOT_破旧的羊皮纸|r
    .complete 966,1 --Worn Parchment (4)
    .mob 暗滩狂热者
step
    .goto Darkshore,54.973,24.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_巴苏尔·影击|r 对话
    .turnin 966 >> 交任务 奥萨拉克斯之塔
    .accept 967 >> 接受任务 奥萨拉克斯之塔
    .target 巴苏尔·影击
step
    #completewith next
    .goto 1439,54.934,32.721,20,0
    .goto 1439,55.108,33.600,40 >> 前往壁泉河洞穴
step
    >>拾取地上的 |cRXP_LOOT_粗柄蘑菇|r 和 |cRXP_LOOT_毒帽蘑菇|r
    >>|cRXP_WARN_待在上层区域。如果上侧尽头没有 |cRXP_LOOT_毒帽蘑菇|r，就跳下去到下方南侧的房间获取一个|r
    >>|cRXP_WARN_小心 |cRXP_ENEMY_雷鳞御浪者|r 会施放|r |T135836:0|t[水流喷射] |cRXP_WARN_（远程瞬发：对附近敌人造成伤害并将其击退）——确保你站在不会被击退到洞穴下层的位置|r
    .complete 947,1 --Scaber Stalk (5)
    .goto Darkshore,55.04,33.34,8,0
    .goto Darkshore,55.28,34.00,8,0
    .goto Darkshore,55.09,34.67,8,0
    .goto Darkshore,55.30,35.58,8,0
    .goto Darkshore,55.04,33.34,8,0
    .goto Darkshore,55.28,34.00,8,0
    .goto Darkshore,55.09,34.67,8,0
    .goto Darkshore,55.30,35.58,8,0
    .goto Darkshore,55.04,33.34
    .complete 947,2 --Death Cap (1)
    .goto Darkshore,55.38,36.34
step
	.goto Darkshore,55.3,34.0
    .xp 20-3900 >> 练怪直到距离20级还有3900 经验 (16900/20800)
step << Hunter
	#completewith next
    .deathskip >> 死亡并在 |cRXP_FRIENDLY_灵魂医者|r 处重生
step
    .goto Darkshore,38.107,41.165
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_高尔博德·钢手|r 对话
    .turnin 982 >> 交任务 深不可测的海洋
    .target 高尔博德·钢手
step
    #optional
    .isOnQuest 3765
    .goto Darkshore,38.327,43.039
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_戈沙拉·夜语|r 对话
    .turnin 3765 >> 交任务 遥远的旅途
    .target 戈沙拉·夜语
step
.dungeon BFD
    .goto Darkshore,38.327,43.039
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_戈沙拉·夜语|r 对话
    >>|cRXP_WARN_如果你无法接取该任务，请跳过此步骤|r
    .accept 1275 >> 接受任务 研究堕落
    .target 戈沙拉·夜语
step
    .goto Darkshore,37.439,41.839
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_考古学家霍莉|r 对话
    .accept 729 >> 接受任务 健忘的勘察员
    .target 考古学家霍莉
step
    .goto Darkshore,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_巴瑞萨斯·月影|r 对话
    .turnin 947 >> 交任务 洞中的蘑菇
    .accept 948 >> 接受任务 安努
    .target 巴瑞萨斯·月影
step
    .goto Darkshore,36.097,44.932
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_古博·布拉普|r 对话
    .turnin 1138 >> 交任务 海中的水果
    .target 古博·布拉普
step << Hunter
.dungeon !BFD
    .goto Darkshore,33.189,40.111
    .zone Teldrassil >> 乘船前往泰达希尔
    .zoneskip Darnassus
step << Hunter
.dungeon !BFD
    #optional
    #completewith TrainWeps
    .goto Teldrassil,55.95,89.88
    .zone Darnassus >> 进入通往达纳苏斯的紫色传送门
step
.dungeon BFD
    .goto Darkshore,33.189,40.111
    .zone Teldrassil >> 乘船前往泰达希尔
    .zoneskip Darnassus
step
.dungeon BFD
    #completewith BFDAccept
    .goto Teldrassil,55.95,89.88
    .zone Darnassus >> 进入通往达纳苏斯的紫色传送门
step
.dungeon BFD
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t在楼上与 |cRXP_FRIENDLY_银月守卫玛纳杜斯|r 和 |cRXP_FRIENDLY_哨兵山德拉斯|r 对话
    .accept 1199 >> 接受任务 暮光之锤的末日
    .target 银月守卫玛纳杜斯
    .goto Darnassus,55.239,23.996 -- Argent Guard Manados
    .accept 1198 >> 接受任务 寻找塞尔瑞德
    .target 哨兵山德拉斯
    .goto Darnassus,55.360,25.024 -- Dawnwatcher Shaedlass
step << Hunter
#ah
    .goto Darnassus,63.27,66.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰德瑞亚|r 对话
    >>|cRXP_WARN_如果你负担得起，|r购买 |cRXP_WARN_|T135489:0|t[重型弯弓]，或者在拍卖行寻找更好的弓|r
    >>|cRXP_WARN_补充 |T132382:0|t[锋利的箭] 库存|r
    .collect 3027,1
    .target 兰德瑞亚
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.71
step << Hunter
#ssf
    .goto Darnassus,63.27,66.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_兰德瑞亚|r 对话
    >>|cRXP_WARN_购买1把|r |T135489:0|t[重型弯弓]
    >>|cRXP_WARN_补充 |T132382:0|t[锋利的箭] 库存|r
    .collect 3027,1
    .target 兰德瑞亚
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.71
    .money <0.5643
step << Hunter
    +|cRXP_WARN_装备|r |T135489:0|t[重型弯弓]
    .use 3027
    .itemcount 3027,1
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.71
step << Hunter
    #label TrainWeps
    .goto Darnassus,57.56,46.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_伊琳尼雅·月火|r 对话
    .skipgossip 11866,1
    .train 264 >> 学习 弩
    .train 227 >> 学习法杖
    .target 伊琳尼雅·月火
step
    #label BFDAccept
    .goto Darnassus,39.799,92.286,10,0
    .goto Darnassus,38.716,81.330
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与楼上的 |cRXP_FRIENDLY_瓦鲁丝塔大使|r 对话
    .accept 9432 >> 接受任务 前往阿斯特兰纳
    .target 瓦鲁丝塔大使
    .zoneskip Darnassus,1
step
.dungeon BFD
    .goto Darnassus,29.466,41.405
    .zone Teldrassil >> 通过紫色传送门前往鲁瑟兰村
    .zoneskip Darkshore
step
.dungeon BFD
    .goto Teldrassil,58.39,94.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_维斯派塔斯|r 对话
    .fly Darkshore >> 飞往黑海岸
    .target 维斯派塔斯
    .zoneskip Darkshore
step << Hunter
.dungeon !BFD
    .goto Darnassus,29.466,41.405
    .zone Teldrassil >> 通过紫色传送门前往鲁瑟兰村
    .zoneskip Darkshore
step << Hunter
.dungeon !BFD
    .goto Teldrassil,58.39,94.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_维斯派塔斯|r 对话
    .fly Darkshore >> 飞往黑海岸
    .target 维斯派塔斯
    .zoneskip Darkshore
step
    .goto Darkshore,35.429,76.566,0
    .goto Darkshore,35.429,76.566,60,0
    .goto Darkshore,36.526,76.603
    >>|cRXP_WARN_请务必检查 |cRXP_ENEMY_莫克迪普|r 是否已经在水中刷新(可能是之前有人战斗失败，或在他刷新时那一波里的 |cRXP_ENEMY_灰雾猎人|r 没有被击杀)|r
    >>击杀营地内的 |cRXP_ENEMY_灰雾战士|r 和 |cRXP_ENEMY_灰雾猎人|r
    >>|cRXP_WARN_移动到营地中央的篝火处以触发 |cRXP_ENEMY_莫克迪普|r 的战斗：|r
    >>|cRXP_WARN_将从水中刷新 3 波敌人，每击杀上一波才会出现下一波：第 1 波为 3 个 12–13 级 |cRXP_ENEMY_灰雾滩行者|r；第 2 波为 2 个 15–16 级 |cRXP_ENEMY_灰雾战士|r；第 3 波为 1 个 19 级 |cRXP_ENEMY_莫克迪普|r 和 1 个 16–17 级 |cRXP_ENEMY_灰雾猎人|r。你可以离开篝火以避免拉到下一波仇恨|r
    .complete 4740,1 -- Murkdeep (1)
    .unitscan 莫克迪普
    .mob 灰雾战士
    .mob 灰雾猎人
    .mob 灰雾滩行者
step
    .goto Darkshore,43.555,76.293
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_安努|r 对话
    .turnin 948 >> 交任务 安努
    .accept 944 >> 接受任务 主宰之剑
    .target 安努
step
    .goto Darkshore,35.724,83.696
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_勘察员雷塔维|r 对话
    >>|cRXP_WARN_这将开始一个护送任务。你可能需要等待他重新刷新，或等其他玩家完成护送|r
    .turnin 729 >> 交任务 健忘的勘察员
    .accept 731,1 >> 接受任务 健忘的勘察员
    .target 勘察员雷塔维
step
    #requires prospector
    >>|cRXP_WARN_护送 |cRXP_FRIENDLY_勘察员雷塔维|r 穿过挖掘场|r
    .complete 731,1
    .isOnQuest 731
    .target 勘察员雷塔维
step
    #optional
    #completewith next
    .cast 5809 >> |cRXP_WARN_使用|r |T134715:0|t[占卜之水] |cRXP_WARN_并将其放置在地面上|r
    .use 5251
step
    .goto Darkshore,38.537,86.050
    >>|cRXP_WARN_点击地上的 |cRXP_PICK_占卜之碗|r|r
    .turnin 944 >> 交任务 主宰之剑
    .accept 949 >> 接受任务 暮光之锤的营地
    .use 5251
step
    .goto Darkshore,38.537,86.050
    >>点击北侧基座上的 |cRXP_PICK_暮光典籍|r
    .turnin 949 >> 交任务 暮光之锤的营地
step
    #optional
    #sticky
    .destroy 5251 >> 删除 |T134715:0|t[占卜之水]，你已不再需要
step
    .goto Darkshore,38.660,87.305
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_瑟瑞露尼|r 对话，这将开始一次护送任务
    >>|cRXP_WARN_如果他不在，就跳过这一步|r
    .accept 945 >> 接受任务 护送瑟瑞露尼
    .target 瑟瑞露尼
step
    .goto Darkshore,40.51,87.09
    >>|cRXP_WARN_护送 |cRXP_FRIENDLY_瑟瑞露尼|r 离开主宰之剑|r
    .complete 945,1 --Escort Therylune away from the Master's Glaive (1)
    .isOnQuest 945
    .target 瑟瑞露尼
]])

RXPGuides.RegisterGuide([[
#tbc
#wotlk
#version 7
#group RestedXP 燃烧的远征 练级指南 (联盟)
<< Alliance
#name 21-23 灰谷 (德莱尼)
#subgroup RestedXP 联盟 20-32 级
#defaultfor Draenei
#next 23-24级 湿地;24-27级 赤脊山/暮色森林

step
#xprate >1.49
    .isOnQuest 9633
    .goto Darkshore,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_桑迪斯·织风|r 对话
	.turnin 9633 >> 交任务 前往奥伯丁
    .accept 10752 >> 接受任务 前往灰谷
    .target 桑迪斯·织风
    .zoneskip Darkshore,1
step
#xprate >1.49
    .goto Darkshore,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_桑迪斯·织风|r 对话
    .accept 10752 >> 接受任务 前往灰谷
    .target 桑迪斯·织风
    .zoneskip Darkshore,1
step
#xprate >1.49
.dungeon BFD
    .goto Darkshore,38.327,43.039
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_戈沙拉·夜语|r 对话
    >>|cRXP_WARN_如果你无法接取该任务，请跳过此步骤|r
    .accept 1275 >> 接受任务 研究堕落
    .target 戈沙拉·夜语
    .zoneskip Darkshore,1
step
#xprate >1.49
    .goto Darkshore,36.336,45.574
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯莱斯·月羽|r 对话
    .fp Auberdine >> 开启奥伯丁飞行点
    .target 凯莱斯·月羽
    .zoneskip Darkshore,1
step
    .goto Ashenvale,28.929,14.485
    .zone Ashenvale >> 向南前往灰谷
step
#xprate <1.5
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_净化者德尔格伦|r 对话
	.target 净化者德尔格伦
    .goto Ashenvale,26.19,38.69
    .turnin 967 >> 交任务 奥萨拉克斯之塔
    .accept 970 >> 接受任务 奥萨拉克斯之塔
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_奥雷迪尔·阔叶|r 对话
	.target 奥雷迪尔·阔叶
    .goto Ashenvale,26.43,38.59
    .accept 1010 >> 接受任务 巴斯兰的头发
step
#xprate <1.5
    .goto Ashenvale,31.25,30.70
    >>击杀 |cRXP_ENEMY_暗滩祭司|r, |cRXP_ENEMY_暗滩精兵|r, |cRXP_ENEMY_暗滩执行者|r 和 |cRXP_ENEMY_暗滩挖掘者|r。拾取他们的 |cRXP_LOOT_发光的灵魂宝石|r
    .complete 970,1
    .mob 暗滩祭司
    .mob 暗滩精兵
    .mob 暗滩执行者
    .mob 暗滩挖掘者
step
    .goto Ashenvale,33.01,21.41,50,0
    .goto Ashenvale,29.53,24.33,40,0
    .goto Ashenvale,31.89,22.53
    >>打开地上的 |cRXP_PICK_植物捆|r，拾取其中的 |cRXP_LOOT_巴斯兰的毛发|r
    >>|cRXP_WARN_它们看起来像小棕色袋子，不容易看见|r
    .complete 1010,1
    .isOnQuest 1010
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_奥雷迪尔·阔叶|r 对话
	.target 奥雷迪尔·阔叶
    .goto Ashenvale,26.43,38.59
    .turnin 1010 >> 交任务 巴斯兰的头发
    .accept 1020 >> 接受任务 奥雷迪尔的药剂
step
#xprate <1.5
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_净化者德尔格伦|r 对话
    .goto Ashenvale,26.19,38.69
    .turnin 970 >> 交任务 奥萨拉克斯之塔
    .accept 973 >> 接受任务 奥萨拉克斯之塔
    .target 净化者德尔格伦
step
    #completewith next
    .goto Ashenvale,25.49,39.59,25,0
    .goto Ashenvale,25.98,41.72,25,0
    .goto Ashenvale,26.88,44.47,30,0
    .goto Ashenvale,28.16,47.68,60,0
    .goto Ashenvale,34.67,48.83
    .subzone 415 >> 前往阿斯特兰纳
step
    .goto Ashenvale,34.67,48.83
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_辛德瑞尔·速火|r 对话
    .accept 1008 >> 接受任务 佐拉姆海岸
    .target 辛德瑞尔·速火
step
    #optional
    .isOnQuest 9432
    .goto Ashenvale,34.894,49.706
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_守备官帕兰纳尔|r 对话
    .turnin 9432 >> 交任务 前往阿斯特兰纳
    .target 守备官帕兰纳尔
step << Warrior/Paladin
	.goto Ashenvale,35.785,52.048
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塞安德尔|r 对话
    >>|cRXP_BUY_从他那里|r购买1把|cRXP_BUY_ |T135280:0|t[微光重剑] |r
	.collect 922,1
    .target 塞安德尔
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.0
step << Warrior/Paladin
    #optional
    #sticky
    +|cRXP_WARN_装备|r |T135280:0|t[微光重剑]
    .use 922
    .itemcount 922,1
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<16.0
step
    .goto Ashenvale,36.61,49.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莱恩·狼行者|r 对话
    .turnin 10752 >> 交任务 前往灰谷
    .accept 1054 >> 接受任务 解除威胁
    .accept 991 >> 接受任务 莱恩的净化
    .target 莱恩·狼行者
step
    .goto Ashenvale,36.99,49.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_旅店老板基姆利雅|r 对话
    .home >> 将你的炉石绑定到 阿斯特兰纳
    .target 旅店老板基姆利雅
    .subzoneskip 415,1
step
    .goto Ashenvale,37.36,51.79
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_皮尔图拉斯·怀特姆恩|r 对话
    .turnin 1020 >> 交任务 奥雷迪尔的药剂
    .timer 24,奥雷迪尔的药剂 剧情
    .accept 1033 >> 接受任务 月神之泪
    .target 皮尔图拉斯·怀特姆恩
step
.dungeon WC
    #completewith TravelRatchet
    +在完成接下来的两个步骤时开始寻找哀嚎洞穴的小队。很快你就会前往贫瘠之地刷哀嚎洞穴
    .zoneskip The Barrens
step
.dungeon WC
    .goto Ashenvale,36.06,36.59,0
    .goto Ashenvale,37.00,33.77,0
    .goto Ashenvale,35.88,31.90,0
    .goto Ashenvale,38.73,36.32,0
    .goto Ashenvale,39.59,36.30,60,0
    .goto Ashenvale,36.06,36.59,60,0
    .goto Ashenvale,37.00,33.77,60,0
    .goto Ashenvale,35.88,31.90,60,0
    .goto Ashenvale,38.73,36.32,60,0
    .goto Ashenvale,39.595,36.309
    >>击杀 |cRXP_ENEMY_达尔·血爪|r，拾取他的 |cRXP_LOOT_颅骨|r
    >>|cRXP_ENEMY_达尔·血爪|r |cRXP_WARN_在蓟皮村巡逻|r
    .complete 1054,1
    .unitscan 达尔·血爪
    .zoneskip The Barrens
step
.dungeon WC
    .goto Ashenvale,46.37,46.38
    >>拾取地上的 |cRXP_LOOT_月神之泪|r
    .complete 1033,1
    .zoneskip The Barrens
step
.dungeon WC
    #label TravelRatchet
    .goto Ashenvale,69.71,86.87,50,0
    .goto The Barrens,48.98,5.42,35,0
    .goto The Barrens,49.07,12.80,50,0
    .goto The Barrens,53.87,21.52,120,0
    .goto The Barrens,59.15,25.48,120,0
    .goto The Barrens,63.087,37.607
    .subzone 392 >> 前往贫瘠之地的棘齿城。跟随箭头行进以避开 |cRXP_ENEMY_贫瘠之地卫兵|r
step
.dungeon WC
    .goto The Barrens,63.084,37.163
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_布拉高克|r 对话
    .fp Ratchet >> 获取棘齿城飞行路径
    .target 布拉高克
step
.dungeon WC
    .goto The Barrens,63.087,37.607
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_起重机操作员比戈弗兹|r 对话
    .accept 959 >> 接受任务 港口的麻烦
    .target 起重机操作员比戈弗兹
step
.dungeon WC
    #completewith next
    .goto The Barrens,46.95,35.44,0
    .goto The Barrens,46.95,35.44,20,0
    .goto The Barrens,47.01,34.67,15,0
    .goto 1414/1,-2039.8620,-759.5994
    .goto 1414/1,-2003.0622,-830.7456,20 >> 前往哀嚎洞穴。登上山顶后跳下，进入哀嚎洞穴入口上方的隐藏洞穴。跟随箭头前往 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r
step
.dungeon WC
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r 对话
    .accept 1486 >> 接受任务 变异皮革
    .goto 1414/1,-2036.9180,-796.8898 -- Nalpak
    .accept 1487 >> 接受任务 清除变异者
    .goto 1414/1,-2039.1260,-802.2871 -- Ebru
    .target 纳尔帕克
    .target 厄布鲁
step
.dungeon WC
    #completewith EnterWC
    >>击杀所有类型的 |cRXP_ENEMY_变异兽|r，拾取它们掉落的 |cRXP_LOOT_变异兽皮|r
    >>|cRXP_WARN_此任务可以在哀嚎洞穴副本内或副本外完成|r
    .complete 1486,1 -- Deviate Hide (20)
    .isOnQuest 1486
step
.dungeon WC
    .goto 1414/1,-2084.0218,-784.1326,20,0
    .goto 1414/1,-2120.8216,-727.7062,20,0
    .goto 1414/1,-2003.0622,-656.5599,20,0
    .goto 1414/1,-2084.0218,-784.1326,20,0
    .goto 1414/1,-2120.8216,-727.7062,20,0
    .goto 1414/1,-2003.0622,-656.5599,20,0
    .goto 1414/1,-2084.0218,-784.1326,20,0
    .goto 1414/1,-2120.8216,-727.7062,20,0
    .goto 1414/1,-2003.0622,-656.5599
    >>击杀 |cRXP_ENEMY_疯狂的马格利什|r。拾取他的 |cRXP_LOOT_99年波尔多陈酿|r
    >>|cRXP_ENEMY_疯狂的马格利什|r |cRXP_WARN_可能会在几个地点刷新|r
    >>|cRXP_WARN_此任务需要在哀嚎洞穴副本外完成|r
    .complete 959,1 -- 99-Year-Old Port (1)
    .isOnQuest 959
    .mob 疯狂的马格利什
step
.dungeon WC
    #label EnterWC
    .goto 1414/1,-2205.4612,-742.4261
    +进入哀嚎洞穴
    .zoneskip 1414,1 -- similar to stockades, no subzone for WC
step
.dungeon WC
    >>击杀所有类型的 |cRXP_ENEMY_变异兽|r，拾取它们掉落的 |cRXP_LOOT_变异兽皮|r
    .complete 1487,1 -- Deviate Ravager slain (7)
    .complete 1487,2 -- Deviate Viper slain (7)
    .complete 1487,3 -- Deviate Shambler slain (7)
    .complete 1487,4 -- Deviate Dreadfang slain (7)
    .complete 1486,1 -- Deviate Hide (20)
    .disablecheckbox
    .isOnQuest 1487
    .isOnQuest 1486
step
.dungeon WC
    >>击杀所有类型的 |cRXP_ENEMY_变异兽|r
    .complete 1487,1 -- Deviate Ravager slain (7)
    .complete 1487,2 -- Deviate Viper slain (7)
    .complete 1487,3 -- Deviate Shambler slain (7)
    .complete 1487,4 -- Deviate Dreadfang slain (7)
    .isOnQuest 1487
step
.dungeon WC
    #completewith next
    >>击杀所有类型的 |cRXP_ENEMY_变异兽|r，拾取它们掉落的 |cRXP_LOOT_变异兽皮|r
    .complete 1486,1 -- Deviate Hide (20)
    .isOnQuest 1486
step
.dungeon WC
    >>击杀 |cRXP_ENEMY_考布莱恩|r、|cRXP_ENEMY_皮萨斯|r、|cRXP_ENEMY_瑟芬迪斯|r 和 |cRXP_ENEMY_安娜科德拉|r，然后与副本入口的 |cRXP_FRIENDLY_纳拉雷克斯的弟子|r 对话以开始护送任务
    >>护送 |cRXP_FRIENDLY_纳拉雷克斯的弟子|r 穿过哀嚎洞穴，并完成唤醒仪式
    >>击杀 |cRXP_ENEMY_吞噬者穆坦努斯|r，拾取掉落的 |T135229:0|t[|cRXP_LOOT_发光碎片|r]
    >>|cRXP_WARN_使用 |T135229:0|t[|cRXP_LOOT_发光的碎片|r] 来开始该任务|r
    .collect 10441,1,6981,1 -- Glowing Shard (1)
    .accept 6981 >> 接受任务 发光的碎片
    .use 10441 -- Glowing Shard
    .skipgossip
    .target 纳拉雷克斯的信徒
    .mob 吞噬者穆坦努斯
step
.dungeon WC
    >>击杀所有类型的 |cRXP_ENEMY_变异兽|r，拾取它们掉落的 |cRXP_LOOT_变异兽皮|r
    >>|cRXP_WARN_此任务可以在哀嚎洞穴副本内或副本外完成|r
    .complete 1486,1 -- Deviate Hide (20)
    .isOnQuest 1486
step
.dungeon WC
    #completewith RatchetTurnin
    .goto The Barrens,62.984,37.218
    .subzone 392 >> 前往棘齿城。你很快将在西部荒野交付上面的任务
    .isOnQuest 6981,959
step
.dungeon WC
    .goto The Barrens,62.984,37.218
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斯布特瓦夫|r 对话
    .complete 6981,1 -- Speak with someone in Ratchet about the Glowing Shard
    .skipgossip 1
    .target 斯布特瓦夫
    .isOnQuest 6981
step
.dungeon WC
    #label RatchetTurnin
    .goto The Barrens,63.087,37.607
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_起重机操作员比戈弗兹|r 对话
    .turnin 959 >> 交任务 港口的麻烦
    .target 起重机操作员比戈弗兹
    .isQuestComplete 959
step
.dungeon WC
    #completewith next
    .goto The Barrens,50.11,35.21,35,0
    .goto The Barrens,48.60,33.34,35,0
    .goto The Barrens,48.184,32.781,15 >> 沿着哀嚎洞穴上方的陡峭山坡向上攀爬，跟随箭头前进
    .isQuestComplete 6981
step
.dungeon WC
    .goto The Barrens,48.184,32.781
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_菲拉·古风|r 对话
    .turnin 6981 >> 交任务 发光的碎片
    .target 菲拉·古风
    .isQuestComplete 6981
step
.dungeon WC
    #completewith NalpakEbru
    .goto 1414/1,-2039.8620,-759.5994,45,0
    .goto 1414/1,-2003.0622,-830.7456,20 >> 从哀嚎洞穴入口上方的隐藏洞穴跳下，沿箭头指引前往 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r
step
.dungeon WC
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r 对话
    .turnin 1486 >> 交任务 变异皮革
    .goto 1414/1,-2036.9180,-796.8898 -- Nalpak
    .turnin 1487 >> 交任务 清除变异者
    .goto 1414/1,-2039.1260,-802.2871 -- Ebru
    .target 纳尔帕克
    .target 厄布鲁
    .isQuestComplete 1486
    .isQuestComplete 1487
step
.dungeon WC
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r 对话
    .turnin 1487 >> 交任务 清除变异者
    .goto 1414/1,-2039.1260,-802.2871 -- Ebru
    .target 厄布鲁
    .isQuestComplete 1487
step
.dungeon WC
    #label NalpakEbru
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_纳尔帕克|r 和 |cRXP_FRIENDLY_厄布鲁|r 对话
    .turnin 1486 >> 交任务 变异皮革
    .goto 1414/1,-2036.9180,-796.8898 -- Nalpak
    .target 纳尔帕克
    .isQuestComplete 1486
step
.dungeon WC
    .hs >> 炉石返回阿斯特兰纳，灰谷
    >>|cRXP_BUY_如有需要，购买食物/水|r << !Warrior !Rogue
	>>|cRXP_BUY_需要的话就买点食物|r << Warrior/Rogue
    .zoneskip Ashenvale
step
    .goto Ashenvale,46.37,46.38
    >>拾取地上的 |cRXP_LOOT_月神之泪|r
    .complete 1033,1
step
    .goto Ashenvale,36.06,36.59,0
    .goto Ashenvale,37.00,33.77,0
    .goto Ashenvale,35.88,31.90,0
    .goto Ashenvale,38.73,36.32,0
    .goto Ashenvale,39.59,36.30,60,0
    .goto Ashenvale,36.06,36.59,60,0
    .goto Ashenvale,37.00,33.77,60,0
    .goto Ashenvale,35.88,31.90,60,0
    .goto Ashenvale,38.73,36.32,60,0
    .goto Ashenvale,39.595,36.309
    >>击杀 |cRXP_ENEMY_达尔·血爪|r，拾取他的 |cRXP_LOOT_颅骨|r
    >>|cRXP_ENEMY_达尔·血爪|r |cRXP_WARN_在蓟皮村巡逻|r
    .complete 1054,1
    .unitscan 达尔·血爪
step
    #completewith next
    .subzone 415 >> 前往阿斯特兰纳
step
    .goto Ashenvale,36.61,49.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莱恩·狼行者|r 对话
    .turnin 1054 >> 交任务 解除威胁
    .target 莱恩·狼行者
step
    .goto Ashenvale,37.36,51.79
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_皮尔图拉斯·怀特姆恩|r 对话
	.target 皮尔图拉斯·怀特姆恩
    .turnin 1033 >> 交任务 月神之泪
    .timer 17,月神之泪 剧情
    .accept 1034 >> 接受任务 星尘废墟
step << Shaman
    #completewith next
    >>拾取 |cRXP_PICK_星尘覆盖的灌木|r，获取 |cRXP_LOOT_一把星尘|r
    >>|cRXP_WARN_它们的刷新点分布在整个岛屿各处|r
    .complete 1034,1
step << Shaman
    .goto Ashenvale,33.547,67.474
    .use 23749 >> |cRXP_WARN_在星尘废墟的小喷泉处|r|cRXP_WARN_使用|r |T132825:0|t[空的波涛之袋]
    .complete 9504,1 --Collect Filled Bota Bag (x1)
step
    .goto Ashenvale,33.30,67.79
    >>拾取 |cRXP_PICK_星尘覆盖的灌木|r，获取 |cRXP_LOOT_一把星尘|r
    >>|cRXP_WARN_它们的刷新点分布在整个岛屿各处|r
    .complete 1034,1
step
#xprate <1.5
    #completewith next
    .goto Ashenvale,31.67,64.24,15 >> 前往山脚下
    .goto Ashenvale,31.21,61.60,15 >>在攀爬山体时径直向北跑
step
#xprate <1.5
    .goto Ashenvale,27.40,63.03,70,0
    .goto Ashenvale,25.27,60.68
    >>击杀 |cRXP_ENEMY_伊克鲁德·玛格苏尔|r，拾取他的 |cRXP_LOOT_典籍|r
    >>伊克鲁德·玛格苏尔|cRXP_ENEMY_ 会施放 |r|T136221:0|t[伊克鲁德的守护者]，|cRXP_WARN_施法时间为 5 秒，并会召唤 2 个 |r虚空行者|cRXP_WARN_。如果可以的话，请中断此施法|r
    .complete 973,1
    .mob 伊克鲁德·玛格苏尔
step
#xprate <1.5
    #optional
    .isQuestComplete 945
	.goto Ashenvale,27.4,61.7,80,0
	.goto Ashenvale,28.1,55.1,80,0
    .goto Ashenvale,22.64,51.91
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_瑟瑞希尔|r 对话
    .turnin 945 >> 交任务 护送瑟瑞露尼
	.target 瑟瑞希尔
step
#xprate <1.5
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_净化者德尔格伦|r 对话
    .goto Ashenvale,26.19,38.69
    .turnin 973 >> 交任务 奥萨拉克斯之塔
    .target 净化者德尔格伦
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_泰洛尼斯的尸体|r 对话
	.target 泰洛尼斯的尸体
    .goto Ashenvale,20.31,42.33
    .turnin 991 >> 交任务 莱恩的净化
    .accept 1023 >> 接受任务 莱恩的净化
step
    .goto Ashenvale,20.41,43.82,50,0
    .goto Ashenvale,19.43,42.09,50,0
    .goto Ashenvale,21.01,41.61,50,0
    .goto Ashenvale,20.31,42.33
    >>击杀 |cRXP_ENEMY_盐沫鱼人|r，拾取它们掉落的 |cRXP_LOOT_发光宝石|r
	.mob 盐沫战士
	.mob 盐沫泥浆鱼人
	.mob 盐沫智者
	.mob 盐沫污水鱼人
    .complete 1023,1
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塔尔伦|r 对话
    .goto Ashenvale,14.79,31.29
    .accept 1007 >> 接受任务 远古雕像
    .target 塔尔伦
step
    #completewith AncientStatuette
    >>击杀 |cRXP_ENEMY_佐拉姆海岸的纳迦|r。拾取他们的 |cRXP_LOOT_头颅|r
    >>|cRXP_WARN_暂时不要特意绕路去完成这个|r
	.mob 怒尾御浪者
	.mob 怒尾巫师
    .complete 1008,1
step
    .goto Ashenvale,14.20,20.64
    >>拾取地上的 |cRXP_LOOT_古代小雕像|r
    .complete 1007,1
step
    #label AncientStatuette
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塔尔伦|r 对话
	.target 塔尔伦
    .goto Ashenvale,14.79,31.29
    .turnin 1007 >> 交任务远古雕像
    .accept 1009 >> 接受任务 卢泽尔
step
    #completewith next
    >>击杀 |cRXP_ENEMY_佐拉姆海岸的纳迦|r。拾取他们的 |cRXP_LOOT_头颅|r
	.mob 怒尾御浪者
	.mob 怒尾巫师
    .mob 怒尾侍从
    .mob 怒尾女祭司
    .mob 怒尾纳迦
    .mob 怒尾海巫
    .complete 1008,1
step
    .goto Ashenvale,6.528,13.361
    >>击杀 |cRXP_ENEMY_卢泽尔|r。拾取她的 |cRXP_LOOT_佐拉姆之戒|r
    >>|cRXP_ENEMY_卢泽尔|r 会与 |cRXP_WARN_怒尾侍从|cRXP_ENEMY_ 和 |r怒尾海巫|cRXP_ENEMY_ |r在岛上巡逻。先击杀其中一名，如果需要可重置它们|r
    >>|cRXP_ENEMY_薇丝比娅|r |cRXP_WARN_是一只稀有刷新怪，如果遇到她，也有可能掉落 |cRXP_LOOT_佐拉姆之戒|r|r
	.unitscan 薇丝比娅
	.mob 卢泽尔
    .complete 1009,1
step
.dungeon BFD
    #completewith RuuzelTurnin
    +在完成接下来的步骤时开始寻找黑暗深渊的小队。很快你就会去刷黑暗深渊
step
    .goto Ashenvale,7.00,15.20,0
    .goto Ashenvale,14.46,17.15,0
    .goto Ashenvale,14.86,21.06,0
    .goto Ashenvale,13.13,25.03,0
    .goto Ashenvale,10.89,30.03,0
    .goto Ashenvale,7.00,15.20,70,0
    .goto Ashenvale,14.46,17.15,70,0
    .goto Ashenvale,14.86,21.06,70,0
    .goto Ashenvale,13.13,25.03,70,0
    .goto Ashenvale,10.89,30.03,70,0
    .goto Ashenvale,13.13,25.03,70,0
    .goto Ashenvale,14.86,21.06,70,0
    .goto Ashenvale,14.46,17.15,70,0
    >>击杀 |cRXP_ENEMY_佐拉姆海岸的纳迦|r。拾取他们的 |cRXP_LOOT_头颅|r
	.mob 怒尾御浪者
	.mob 怒尾巫师
    .mob 怒尾侍从
    .mob 怒尾女祭司
    .mob 怒尾纳迦
    .mob 怒尾海巫
    .complete 1008,1
step
    #label RuuzelTurnin
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_塔尔伦|r 对话
    .goto Ashenvale,14.79,31.29
    .turnin 1009 >> 交任务 卢泽尔
	.target 塔尔伦
step
.dungeon BFD
    .goto Ashenvale,15.5,19.0,0
    .goto Ashenvale,14.230,14.618
    +在组建黑暗深渊小队的同时刷 |cRXP_ENEMY_娜迦|r，组好队伍后前往黑暗深渊
    .subzoneskip 2797--BFD
step
.dungeon BFD
    #completewith EnterBFD
    .goto Ashenvale,14.230,14.618,0
    .goto 1414/1,885.7229,4139.6807,50 >> 前往黑暗深渊
    .subzoneskip 2797--BFD
step
.dungeon BFD
    #completewith next
    >>击杀 |cRXP_ENEMY_腐根游荡者|r, |cRXP_ENEMY_腐根萨特|r, |cRXP_ENEMY_黑暗深渊智者|r 和 |cRXP_ENEMY_黑暗深渊海潮祭司|r。拾取他们的 |cRXP_LOOT_堕落者的脑干|r
    >>|cRXP_WARN_进入副本后，你也可以拾取 |cRXP_LOOT_腐化的脑茎|r|r
    .complete 1275,1 -- Corrupted Brain Stem (8)
    .mob 黑暗深渊海潮祭司
    .mob 黑暗深渊智者
    .mob 腐根游荡者
    .mob 腐根萨特
    .isOnQuest 1275
step
.dungeon BFD
    #label EnterBFD
    .goto 1414/1,937.2426,4186.2938,25,0
    .goto 1414/1,904.1228,4321.2264,25,0
    .goto 1414/1,867.3230,4318.7731,25,0
    .goto 1414/1,749.5636,4252.5334
    .subzone 2797,2 >> 前往黑暗深渊副本入口并进入副本
    >>|cRXP_WARN_看看你的小队中是否有人可以从铁炉堡与你共享任务"深渊中的知识"|r
step
.dungeon BFD
    #completewith Kelris
    >>击杀 |cRXP_ENEMY_娜迦|r 和 |cRXP_ENEMY_萨特|r，拾取它们掉落的 |cRXP_LOOT_腐化的脑茎|r
    .complete 1275,1 -- Corrupted Brain Stem (8)
    .isOnQuest 1275
step
.dungeon BFD
    #label manuscript
    #sticky
    >>在靠近海龟区域的水下打开 |cRXP_PICK_坑坑洼洼的铁箱|r，拾取其中的 |cRXP_LOOT_洛加利斯手稿|r
    .complete 971,1 -- Lorgalis Manuscript (1)
    .isOnQuest 971
step
.dungeon BFD
    #label Thaelrid
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_斥候塞尔瑞德|r 对话
    .turnin -1198 >> 交任务 寻找塞尔瑞德
    .accept 1200 >> 接受任务 黑暗深渊中的恶魔
step
#requires manuscript
.dungeon BFD
    #completewith Kelris
    >>击杀所有 |cRXP_ENEMY_暮光之锤|r，拾取它们掉落的 |cRXP_LOOT_暮光护符|r
    .complete 1199,1 -- Twilight Pendant (10)
    .isOnQuest 1199
step
#requires manuscript
.dungeon BFD
    #label Kelris
    >>击杀 |cRXP_ENEMY_暮光领主凯尔里斯|r，并拾取他的 |cRXP_LOOT_头颅|r
    .complete 1200,1 -- Head of Kelris (1)
    .isOnQuest 1200
step
.dungeon BFD
    >>击杀所有 |cRXP_ENEMY_暮光之锤|r，拾取它们掉落的 |cRXP_LOOT_暮光护符|r
    .complete 1199,1 -- Twilight Pendant (10)
    .isOnQuest 1199
step
.dungeon BFD
    #label FinalStem
    >>击杀 |cRXP_ENEMY_娜迦|r 和 |cRXP_ENEMY_萨特|r，拾取它们掉落的 |cRXP_LOOT_腐化的脑茎|r
    >>如果你还没有完成该任务，请点击副本尽头的祭坛将你传送回入口。副本外的怪物也有几率掉落该任务物品。
    .complete 1275,1 -- Corrupted Brain Stem (8)
    .isOnQuest 1275
step
    .isOnQuest 1008,1023,1034
    .hs >> 炉石返回阿斯特兰纳，灰谷
    >>|cRXP_BUY_如有需要，购买食物/水|r << !Warrior !Rogue
	>>|cRXP_BUY_需要的话就买点食物|r << Warrior/Rogue
    .cooldown item,6948,>2,1
step
    #completewith ZoramStrandTurnin
    .subzone 415 >> 前往阿斯特兰纳
step
    .goto Ashenvale,36.61,49.58
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_莱恩·狼行者|r 对话
	.target 莱恩·狼行者
    .turnin 1023 >> 交任务 莱恩的净化
step
    #optional
    #sticky
    .destroy 5505 >> 摧毁 |T133741:0|t[泰洛尼斯的日记]。你已经不再需要它了
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_皮尔图拉斯·怀特姆恩|r 对话
	.target 皮尔图拉斯·怀特姆恩
    .goto Ashenvale,37.36,51.79
    .turnin 1034 >> 交任务 星尘废墟
step
    #label ZoramStrandTurnin
    .goto Ashenvale,34.67,48.83
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_辛德瑞尔·速火|r 对话
	.target 辛德瑞尔·速火
    .turnin 1008 >> 交任务 佐拉姆海岸
step
    .goto Ashenvale,34.41,47.99
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_黛琳希亚|r 对话
    .fly Auberdine >> 飞往黑海岸
    .target 黛琳希亚
    .zoneskip Ashenvale,1
step
#xprate <1.5
    .goto Darkshore,37.70,43.39
    .target 哨兵戈琳达·纳希恩
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_哨兵戈琳达·纳希恩|r 对话
    .turnin 4740 >> 交任务 通缉：莫克迪普！
    .isQuestComplete 4740
step
.dungeon BFD
#xprate <1.5
    #label AbsentMinded
    .goto Darkshore,37.44,41.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_考古学家霍莉|r 对话
    .turnin 731 >> 交任务 健忘的勘察员
    .accept 741 >> 接受任务 健忘的勘察员
    .target 考古学家霍莉
step
.dungeon !BFD
#xprate <1.5
    #label AbsentMinded
    .goto Darkshore,37.44,41.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_考古学家霍莉|r 对话
    .turnin 731 >> 交任务 健忘的勘察员
    .accept 741 >> 接受任务 健忘的勘察员 << !Hunter
    .target 考古学家霍莉
step
.dungeon BFD
    .isQuestComplete 1275
    .goto Darkshore,38.327,43.039
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_戈沙拉·夜语|r 对话
    .turnin 1275 >> 交任务 研究堕落
    .target 戈沙拉·夜语
step
.dungeon BFD << !Hunter
    .isOnQuest 1199,1200 << !Hunter
    .goto Darkshore,36.336,45.574
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_凯莱斯·月羽|r 对话
    .fly Teldrassil >> 飞往泰达希尔
    .target 凯莱斯·月羽
step << !Hunter
.dungeon !BFD
    .goto Darkshore,33.189,40.111
    .zone Teldrassil >> 乘船前往泰达希尔
    .zoneskip Darnassus
step
.dungeon BFD << !Hunter
    #optional
    #completewith ExitDarn
    .goto Teldrassil,55.95,89.88
    .zone Darnassus >> 进入通往达纳苏斯的紫色传送门
step << !Hunter
.dungeon !BFD
    #optional
    #completewith ExitDarn
    .goto Teldrassil,55.95,89.88
    .zone Darnassus >> 进入通往达纳苏斯的紫色传送门
step
#xprate <1.5
    .isOnQuest 741
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_首席考古学家杜瑟·灰胡|r 对话
	.target 首席考古学家杜瑟·灰胡
    .goto Teldrassil,23.70,64.51
    .turnin 741 >> 交任务 健忘的勘察员
    .accept 942 >> 接受任务 健忘的勘察员
step
#xprate <1.5
    .isQuestTurnedIn 741
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_首席考古学家杜瑟·灰胡|r 对话
	.target 首席考古学家杜瑟·灰胡
    .goto Teldrassil,23.70,64.51
    .accept 942 >> 接受任务 健忘的勘察员
step << Priest
    .goto 1457,37.903,82.753
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_贾德莉亚|r 对话
    .trainer >> 训练你的职业技能
    .target 贾德莉亚
step << Warrior
    .goto Darnassus,58.945,35.336
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_达纳斯·刃歌|r 对话
    .trainer >> 训练你的职业技能
    .target 达纳斯·刃歌
    .zoneskip Darnassus,1
step << Mage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_伊琳尼雅·月火|r 对话
    .skipgossip 11866,1
    .goto Darnassus,57.56,46.72
    .train 227 >> 学习法杖
    .target 伊琳尼雅·月火
    .zoneskip Darnassus,1
step
.dungeon BFD
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t在楼上与 |cRXP_FRIENDLY_银月守卫玛纳杜斯|r 对话
    .turnin 1199 >> 交任务 暮光之锤的末日
    .goto Darnassus,55.239,23.996 -- Argent Guard Manados
    .target 银月守卫玛纳杜斯
    .isQuestComplete 1199
step
.dungeon BFD
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t在楼上与 |cRXP_FRIENDLY_哨兵塞尔高姆|r 对话
    .turnin 1200 >> 交任务 黑暗深渊中的恶魔
    .goto Darnassus,56.167,24.395 -- Dawnwatcher Selgorm
    .target 哨兵塞尔高姆
    .isQuestComplete 1200
step << Hunter
    .goto Darnassus,40.38,8.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_祖卡斯特|r 对话
    .trainer >> 训练你的职业技能
    .target 祖卡斯特
    .zoneskip Darnassus,1
step
    #label ExitDarn
    .goto Darnassus,29.466,41.405
    .zone Teldrassil >> 通过紫色传送门前往鲁瑟兰村
    .zoneskip Darnassus,1
step
    .goto Teldrassil,58.39,94.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_维斯派塔斯|r 对话
    .fly Darkshore >> 飞往黑海岸
    .target 维斯派塔斯
    .zoneskip Darkshore
    .zoneskip Wetlands
step
    .goto Darkshore,32.44,43.71
    .zone Wetlands >> 乘船前往米奈希尔港
--
step
#xprate >1.49
.dungeon SFK
    #completewith BTcheck
    +|cRXP_WARN_开始寻找影牙城堡队伍。你很快将前往银松森林去打影牙城堡|r
step
#xprate >1.49
    .goto Wetlands,7.95,56.38
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_德温·晨光|r对话
    .vendor >> |cRXP_BUY_尽可能多购买|r |T134831:0|t[治疗药水] |cRXP_BUY_有库存的话|r
    >>|cRXP_WARN_这是限量供应物品。如果 |cRXP_FRIENDLY_德温·晨光|r 没有库存，请跳过此步骤|r
    .target 德温·晨光
    .zoneskip Wetlands,1
step << Draenei
#xprate >1.49
    .goto Wetlands,9.490,59.693
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_谢尔雷·布隆迪尔|r 对话
    .fp Menethil Harbor >> 获取米奈希尔港的飞行路径
    .target 谢尔雷·布隆迪尔
    .zoneskip Wetlands,1
step
#xprate >1.49
    .goto Wetlands,10.89,59.66
    .target 大副菲兹莫斯
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大副菲兹莫斯|r 对话
    .accept 288 >> 接受任务第三舰队
step
#xprate >1.49
    .goto Wetlands,10.69,60.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_旅店老板赫布瑞克|r 对话
    .home >> 将你的炉石设置为米奈希尔港
    .target 旅店老板赫布瑞克
    .bindlocation 2104
step
#xprate >1.49
    .goto Wetlands,10.69,60.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_旅店老板赫布瑞克|r 对话
    >>|cRXP_BUY_购买一壶|r |T132792:0|t[壶装矮人蜜酒]
    .complete 288,1 -- Flagon of Dwarven Honeymead (1)
    .target 旅店老板赫布瑞克
step
#xprate >1.49
    .isQuestComplete 942
    #completewith next
    .goto Wetlands,10.368,61.016,8 >> 前往楼上，朝 |cRXP_FRIENDLY_考古学家弗拉冈特|r 方向移动
step
#xprate >1.49
    .isQuestComplete 942
    .goto Wetlands,10.843,60.435
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 在楼上与 |cRXP_FRIENDLY_考古学家弗拉冈特|r 对话
    .target 考古学家弗拉冈特
    .turnin 942 >> 交任务 健忘的勘察员
step
#xprate >1.49
    .goto Wetlands,10.89,59.66
    .target 大副菲兹莫斯
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_大副菲兹莫斯|r 对话
    .turnin 288 >> 交任务 第三舰队
step
#xprate >1.49
    #label BTcheck
    .goto Wetlands,10.4,56.0,25,0
    .goto Wetlands,10.1,56.9,25,0
    .goto Wetlands,10.6,57.2,25,0
    .goto Wetlands,10.761,56.737
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_尼尔·奥雷|r 对话
    .vendor >> |cRXP_BUY_买一个|r |T133024:0|t[青铜管]
    >>|cRXP_WARN_这是限量供应物品。如果 |cRXP_FRIENDLY_尼尔·奥雷|r 没有库存，请跳过此步骤|r
	.target 尼尔·奥雷
    .bronzetube
step
#xprate >1.49
.dungeon SFK
    #completewith next
    .goto Wetlands,30.8,31.0,0
    .goto Wetlands,37.8,29.6,0
    .goto Wetlands,43.0,33.2,0
    .zone Arathi Highlands >> 击杀 |cRXP_ENEMY_苔皮豺狼人|r，同时寻找影牙城堡队伍
step
#xprate >1.49
.dungeon SFK
    .goto Arathi Highlands,43.01,55.00,90,0
    .goto Arathi Highlands,25.45,46.95,90,0
    .goto Arathi Highlands,21.29,30.24,70,0
    .goto Hillsbrad Foothills,49.338,52.272
    >>影牙城堡没有可接任务。你需要从湿地跑到银松森林。穿越阿拉希高地时务必沿着道路前进，并注意 |cRXP_ENEMY_被遗忘者信使|r
    >>|cRXP_WARN_你暂时不需要获取阿拉希高地的飞行路线|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_达尔拉·哈瑞斯|r 对话
    .fp Southshore >> 获取南海镇的飞行路径
    .target 瑟迪克·普罗斯
    .target 达尔拉·哈瑞斯
    .unitscan 被遗忘者信使
step
#xprate >1.49
.dungeon SFK
    .goto Hillsbrad Foothills,14.77,46.72,0
    .goto Silverpine Forest,44.96,67.92,0
    .goto Hillsbrad Foothills,14.77,46.72,100,0
    .goto Silverpine Forest,47.19,69.78,100,0
    .goto Silverpine Forest,44.712,67.769
    .subzone 209,2 >> 进入影牙城堡
step
#xprate >1.49
.dungeon SFK
    +影牙城堡没有可接的任务
    >>清理影牙城堡。完成后离开
    .zoneskip 209,1
step
#xprate >1.49
.dungeon SFK
	.goto Wetlands,63.9,78.6
	.hs >> 将炉石使用回米奈希尔港
    >>|cRXP_BUY_按需购买食物/水|r << !Warrior !Rogue
	>>|cRXP_BUY_如有需要，购买食物|r << Warrior/Rogue
    .subzoneskip 150
    .subzoneskip 2103
    .subzoneskip 2104
    .zoneskip Loch Modan
step << !Draenei
#xprate >1.49
    .goto Wetlands,9.490,59.693
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_谢尔雷·布隆迪尔|r 对话
    .fly Stormwind >> 飞往暴风城
    .target 谢尔雷·布隆迪尔
    .zoneskip Stormwind City
    .zoneskip Redridge Mountains
    .zoneskip Duskwood
step << Draenei
#xprate >1.49
    .goto Wetlands,53.74,70.33,30,0
    .goto Wetlands,48.17,67.49,30,0
    .goto Loch Modan,25.11,8.99,20 >>|cRXP_WARN_Travel through the Dun Algaz tunnel to Loch Modan|r (NOT TRANSLATED IN :zhCN YET)
    .zoneskip Loch Modan --Completes if you run to Loch
step << skip --logout skip Draenei
#xprate >1.49
	#completewith next
	.goto Wetlands,63.9,78.6
    >>前往湿地东部水坝底部的洞穴
	.zone Loch Modan >> 在洞穴最里面的蘑菇顶部下线。
    >>重新上线后，你会被传送到塞尔萨玛
	.link https://www.youtube.com/watch?v=21CuGto26Mk >> |cRXP_WARN_点击此处查看参考视频|r
step << Draenei
#xprate >1.49
    .goto Loch Modan,33.938,50.954
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_索格拉姆·伯雷森|r 对话
    .fp Thelsamar >> 获取塞尔萨玛的飞行路径
    .target 索格拉姆·伯雷森
step << Draenei
#xprate >1.49
	.goto Loch Modan,22.6,70.2,80,0
	.goto Loch Modan,19.85,63.04,40,0
	.goto Dun Morogh,86.2,47.0
    >>|cRXP_WARN_Begin taking off your gear as you run to Dun Morogh|r (NOT TRANSLATED IN :zhCN YET)
    .deathskip >> aggro the |cRXP_ENEMY_Scarred Crag Boars|r to die and respawn at the |cRXP_FRIENDLY_Spirit Healer|r once you are in Dun Morogh (NOT TRANSLATED IN :zhCN YET)
    .mob 有伤疤的峭壁野猪
step << skip --logout skip Draenei
#xprate >1.49
	>>进东南边的穴居人洞穴。然后用一次下线跳过
    .goto Dun Morogh,70.63,56.70,60,0
    .goto Dun Morogh,70.60,54.86
	.link https://www.youtube.com/watch?v=yQBW3KyguCM >> |cRXP_WARN_点击此处查看参考视频|r
	.zone Ironforge >> 下线跳过，或直接前往铁炉堡
step << Draenei
#xprate >1.49
    .goto Dun Morogh,50.084,49.420
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t 与 |cRXP_FRIENDLY_罗斯洛·鲁治|r 对话
    .vendor >> |cRXP_BUY_买一个|r |T133024:0|t[青铜管]
    >>|cRXP_WARN_This is a limited supply item. Skip this step if |cRXP_FRIENDLY_Loslor Rudge|r doesn't have one|r (NOT TRANSLATED IN :zhCN YET)
	.target 罗斯洛·鲁治
    .bronzetube
step << Draenei
#xprate >1.49
    .goto Dun Morogh,52.94,35.22,0
    .goto Dun Morogh,52.94,35.22,50,0
    .goto Ironforge,19.24,80.76
    .zone Ironforge >> 前往铁炉堡
step << Draenei
#xprate >1.49
    .goto Ironforge,55.491,47.751
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t与 |cRXP_FRIENDLY_格莱斯·瑟登|r 对话
    .fp Ironforge >> 获取铁炉堡的飞行路径
    .target 格莱斯·瑟登
step << Draenei
#xprate >1.49
    .goto Ironforge,76.61,51.28,0
    .goto Ironforge,76.61,51.28,10,0
    .zone Stormwind City >> 乘坐地铁前往暴风城
]])
